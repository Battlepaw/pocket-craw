"""python3 build_update.py 1.0.1 — build the one-file game update."""
from pathlib import Path
import json,sys,re
root=Path(__file__).resolve().parent
version=re.search(r"const GAME_VERSION='([^']+)'",(root/'game.js').read_text()).group(1)
if len(sys.argv)>1 and sys.argv[1]!=version:raise SystemExit('Version argument must match GAME_VERSION in game.js')
if not re.fullmatch(r'\d+\.\d+\.\d+',version):raise SystemExit('Use a version such as 1.0.1')
for name in ['host.html','host.js','manifest.webmanifest','sw.js']:
    if version not in (root/name).read_text():raise SystemExit('Version metadata mismatch in '+name)
html=(root/'game.html').read_text()
html=html.replace('<link rel="stylesheet" href="style.css">','<style>'+(root/'style.css').read_text()+'</style>')
for name in ['game.js','mobile.js','audio.js']:
    html=html.replace(f'<script src="{name}"></script>','<script>'+(root/name).read_text().replace('</script','<\\/script')+'</script>')
payload={'format':'PocketCrawUpdate','schema':1,'hostVersion':1,'saveVersion':1,'version':version,'html':html}
out=root/'pocket-craw-update.json';out.write_text(json.dumps(payload,separators=(',',':')))
print(f'{out.name}: {out.stat().st_size} bytes')
