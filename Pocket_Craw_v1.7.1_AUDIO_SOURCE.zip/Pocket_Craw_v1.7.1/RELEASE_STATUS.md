# Release status

v1.7.0 tested as a JSON import; hosted production remains unchanged. No deployment performed. Physical Android testing pending.
