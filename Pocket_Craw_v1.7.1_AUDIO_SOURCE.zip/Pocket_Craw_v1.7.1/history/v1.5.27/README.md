# Current playtest: v1.5.27

Install pocket-craw-update.json through the permanent site’s App → Import update. Production remains v1.5.25. Read BALANCE_NOTES.md for mechanics, migration, test results and limitations. The complete archive includes runnable browser tests; set NODE_PATH to your Playwright installation and PC_CHROMIUM to an available Chromium executable. tests/compare-baseline.cjs expects a v1.5.26 archive extracted to /tmp/pc-baseline26; tests/import-existing-host.cjs uses PC_HOST_BASELINE or /tmp/pc-host25.

# v1.5.26 import playtest

Use App → Import update with pocket-craw-update.json. More → Settings → Auto-eat rations defaults on; one ration restores 40 hunger when an action takes hunger below 10% of maximum. Manual eating remains unchanged. Hosted production remains v1.5.25 until a separately authorized publication.

# Pocket Craw v1.5.25

Play: https://flying-poplar-97ino7z-paw20.vercel.app

## Install an update
Open the permanent site, choose App → Import update, and select the v1.5.25 IMPORT_READY.json file. Updates are game code; Export save is a separate backup. This package preserves the existing browser storage keys and adds complete modern Legacy ranks to new backups.

The consolidated hosted distribution also contains v1.5.25. Check RELEASE_STATUS.md for verified publication status. After publication, close old game tabs and reopen the permanent link. A prior imported version is retained for rollback. No new site or login is needed for the import workflow.

## Development testing
More → Developer test mode → Start test run. The Monster density slider spans 50–250%; choose Regenerate current test floor to apply it. 100% is eight base enemies plus biome additions. Only test floors regenerate; legitimate saved floors are preserved. Exit test mode reloads normal storage; press Continue to resume.

## Build and verification
All runtime files are at the ZIP root. Serve locally with Python's http.server or another static server. Run python3 build_update.py to rebuild pocket-craw-update.json. Its version is checked against game.js, host.js, host.html, manifest and service worker. The complete source archive includes tests/stability.cjs and TEST_RESULTS.json.

For the browser regression suite, install the pinned Playwright dev dependency and its Chromium browser, then run npm test. PC_CHROMIUM may point to an existing compatible Chromium executable. The suite uses isolated browser contexts and local test fixtures; it does not access real player saves.

Publish the static files to the existing Vercel project with no framework/build/install command or output subdirectory. Do not use a build script that retrieves source from old URLs. Preserve the production origin.

## Scope and limitations
This release repairs stability/UI/data issues and adds spawn controls. It does not complete the broader class, boss, crafting and Legacy design overhaul. See governance and changelog. Existing pre-v1.5.25 exports lack modern Legacy ranks; importing them retains destination ranks rather than erasing purchases.

---

## Historical notes (superseded where conflicting with current governance)

# Pocket Craw

This project is a standalone browser roguelike prototype.

## Running
Open `index.html` in a modern browser (mobile or desktop). No server or dependencies required.

The game opens on the Pocket Craw splash screen. Select **Enter the Labyrinth** to generate your hero and begin.

## Controls
W/S forward/back, A/D turn, Q/E strafe, or use the on-screen controls. Combat, traps, merchants, class choices, and Legacy Hall are controlled with buttons.

## Features
- Randomly generated first-person raycast maze
- Harder enemy rosters from Floor 2 and a Minotaur Warden boss
- Combat, XP, classes, skills, equipment, gold, merchants, traps and special events
- Death-based Legacy Points and unlocks
- Browser localStorage saving for Legacy Points and unlocks (same browser/device)

This is a prototype, not a full 3D engine. The view is raycast pseudo-3D. Active runs now auto-save after every action.

## Class improvement tree
- First class at level 5: Warrior, Rogue or Mage; Knight, Ranger and Alchemist require their existing Legacy unlocks.
- At level 20, choose one of two specializations. At level 35, choose one of that specialization's two advanced classes.
- At level 50 and every 15 levels afterward, choose repeatable Offensive, Defensive or Arcane Mastery.
- Every choice grants the displayed permanent run bonuses, restores HP/MP, and adds 0.25 to class-skill damage multiplier after the first class. Specializations replace the named class skill; Rogue descendants keep their utility bonuses.
- Expand Class Progression to inspect all branches and view your chosen path and next milestone.
- Class choices reset with each new hero; Legacy unlocks persist. Excess XP resumes processing after each mandatory class choice.

## Passive skill tree
An original connected passive tree inspired by Path of Exile's build planning. Earn one point per level, starting at level 2; class milestones remain separate. Open Passive Skill Tree, select a node, inspect its effect, then press Learn. Every node costs one point and requires an owned neighbor (or Origin). Cross-links on the third row enable hybrid paths.

24 passives across Might (attack/crit), Resolve (HP/defense/kill recovery), Arcana (mana/skill power/cost), and Cunning (combat gold/disarm/evasion/escape). Four keystones have explicit benefits and penalties. Critical hits deal 1.5x damage; evasion applies to enemy attacks, not traps. Maximum HP/MP passives increase capacity without restoring current resources. Class-skill effects require a class; Power Strike benefits from Efficiency. Nodes may be inspected anytime but learned only in exploration or class selection. No refunds; each new hero resets the tree. Active runs persist through the save system.

## Legacy skill enhancements
When a hero dies, every passive and class skill chosen during that life is recorded permanently. Open Legacy Hall to enhance recorded skills up to rank 5, costing 5/10/15/20/25 Legacy Points. All purchases apply to newly created heroes; choose the corresponding skill again to activate them. Class skills gain 10% damage per rank. Ordinary passives gain 20% of their base bonus per rank (integer stats round each rank's gain upward); Efficiency gains 1 extra MP reduction per rank, with a minimum skill cost of 1. Keystone enhancements grant +2 ATK and +5 maximum HP per rank without changing their original effects or drawbacks. Crit/flee cap at 95%, evasion at 75%, disarm at 90%. Maximum capacity increases do not heal or restore mana.

Existing Legacy points and unlocks are retained. Past lives played before skill tracking was introduced cannot be reconstructed; their skills must be chosen in a new life. Enhancements and completed-life skill history use the existing browser-local Legacy save; active heroes can now be resumed after refresh.

## Save files
- Progress auto-saves after each game action to one browser save slot. Use Continue saved game on the splash screen after reopening or refreshing.
- Save writes immediately; Load restores that slot. Starting a new hero replaces the active slot after confirmation while preserving Legacy progress.
- Export save downloads a versioned JSON file containing your complete hero, exact maze and explored map, remaining events, current encounter/enemy HP, merchant stock, class and passive choices, journal, and all Legacy progress.
- Import save validates the file, then asks before replacing both the run and Legacy profile. Export a backup first if you want to keep both. Unsupported or malformed saves are rejected.
- Saves work during combat, class selection, merchant visits, and death. Restoring a death screen does not award Legacy points again.
- Browser storage is device/browser-specific and may be blocked or cleared. Exported JSON files are portable backups; keep your latest file for another device. Older builds did not save active runs, so they cannot be recovered.

## Biomes and monster visuals
Eight dungeon themes: Forgotten Keep, Sunken Sewers, Hollow Crypt, Deepstone Caverns, Overgrown Ruins, Frozen Catacombs, Volcanic Forge, and Abyssal Sanctum. Floor 1 starts in the Keep; later floors randomly select from a depth-appropriate pool, avoiding the previous biome. Each generates a fresh connected layout with chambers, cavern openings, or extra tunnel connections. Stairs are placed at a far reachable cell. Biomes change palette, enemies and extra encounters. Enemy health, attack and XP increase with floor depth; armor also grows gradually.

Monsters now use original procedural Canvas models instead of the shared combat emoji. Name-derived silhouettes distinguish rats, goblins, skeletons, spiders, slimes, golems, crystal creatures, wraiths, reavers, acolytes, trolls, root guardians, imps, shadow stalkers and the Minotaur Warden. Frost/ember variants receive their own colors. These are illustrated 2.5D models within the existing raycast renderer, not imported 3D meshes. The Floor 2 Warden remains.

Save files retain generated layouts, biome IDs and current monsters; pre-biome saves load with the Keep palette until the next floor. Natural biome events may include fountains or hidden chambers; Legacy room unlocks add further opportunities.

## Wall materials
Walls now use cached procedural textures mapped to the actual ray/wall intersection, so surface details stay fixed while moving or turning. Each biome has three deterministic variations: dressed stone blocks (Keep), damp mossy brick (Sewers), burial masonry with engraved plaques (Crypt), fractured natural rock (Caverns), cracked masonry with moss and roots (Ruins), translucent-looking ice fissures (Frozen Catacombs), scorched furnace blocks with ember cracks (Forge), and faceted dark stone with violet veins and runes (Abyss). Distance shading and darker wall sides preserve depth. Textures are generated locally once and reused; no image downloads are required. Old saves use Keep materials until entering a themed floor.

## Gear and survival balance (current rules)
Nine slots: weapon, offhand, head, armor, gloves, boots, ring and trinket. Procedural loot has Common/Magic/Rare/Epic rarities, randomized affixes and depth-scaled tiers. Compare stats, equip/unequip outside combat, sell inventory at merchants, or salvage spares into scrap. Merchants upgrade equipped items to +3 using escalating gold and scrap costs. Gear can improve attack, defense, maximum HP/MP, critical chance, evasion, skill damage and disarming. Capacity increases never heal, preventing equipment-swap recovery. All slots and resources persist in saves; older three-slot saves migrate.

New heroes begin with one potion and one ration. Potions restore 24 HP. Camping consumes a ration for 10 HP and 8 MP; unlimited mana recovery has been removed. Level-ups grant smaller stat growth and only 6 HP/3 MP recovery; class advancement remains a full recovery. Floor transitions restore only 5 HP/4 MP. First-floor monsters are stronger; cautious retreat and trap avoidance matter. Merchants have finite potion/ration stock.

Chests guarantee gear and grant 7 XP; monsters have a 28% gear-drop chance, and bosses guarantee Rare gear. Disarmed traps give 8 XP and 2 scrap in addition to gold. Secret rooms retain their XP/gold rewards. Death awards Legacy for combat, traps, treasure and depth; affordable Hardy Bloodline (6 LP), Provisioner (8 LP), and Guard Training (10 LP) help subsequent heroes. Existing Starter Sword and Extra Potion upgrades remain available. These apply to newly created heroes. A first-life class is possible, but not guaranteed: progression is intended to reward resource management and a mix of activities rather than mandatory deaths.

### Balance validation
A simplified encounter simulation (300 trials per profile, without map navigation) reached level 5 in 87/300 fresh runs, 179/300 with Hardy Bloodline and Provisioner, and 296/300 with a larger starter-upgrade bundle. This is a tuning check, not a measured player win rate; navigation, merchants, retreat, and event selection change outcomes. Fresh heroes start at 34 HP, 12 MP and 6 base ATK. Playtesting remains necessary for long-term progression balance.

## Mobile host and file updates — version 1.0.0
Open **host.html** as the app entry point. The game has five touch-friendly screens: Explore, Gear, Skills, Journal, and Menu. Gear and skill screens hide dungeon controls; Explore keeps encounters together. The host's App menu stays available even if a game update fails.

### First setup
1. Extract the complete ZIP. Keep all files together.
2. Serve the folder on a dedicated HTTPS static host and open `host.html` on your phone. This package is not yet deployed and is not an APK. A desktop development server can use `python3 -m http.server 8000`; localhost is suitable for desktop testing, but a phone needs HTTPS for installation/offline support.
3. Install through the browser's install option when offered. The app caches its bundled files after the first successful online load. Installation and file-picker behavior depend on the host browser/WebView. Opening local HTML from Android's file manager is not the supported installation method.

### Load an update directly
1. Download the new `pocket-craw-update.json` produced from this project.
2. Open **App menu → Import update**, choose that file, and confirm its version.
3. Wait for the Installed message. Press Back to game, then Continue saved game.

This changes only the current device/browser installation. It does not require re-uploading the hosted game for each content update. Updates are executable HTML/CSS/JavaScript: import only your own trusted project builds. The format/version checks validate compatibility, not publisher identity or code safety. Use a dedicated origin for this app rather than sharing it with unrelated sensitive applications.

The host keeps the previous game package and a pre-update save backup. An update must report successful initialization within 12 seconds before being committed; otherwise the prior build and save are restored. App menu also offers Roll back previous update, Use bundled game, Download save backup, and Restore pre-update save. Rollback normally retains current progress; restoring the backup explicitly replaces it. Initialization checks do not prove every gameplay feature is correct.

### Build the next update
Edit `game.js`, `index.html`, `style.css`, or `mobile.js`, then run:

```sh
python3 build_update.py 1.0.1
```

The builder embeds those files into one JSON package. No npm install, game engine, image downloads, or external libraries are needed. Current update size is about 68 KB. Limit: 2 MB per imported update. Save schema 1 remains supported. Keep the `PocketCrawReady` initialization flag and the mobile script's `pocket-craw-ready` host notification in future builds.

Host features (`host.html`, `host.js`, manifest, service worker) are separate from game updates. Changing the host itself requires rehosting it and incrementing its service-worker cache version; game-package imports cannot upgrade the outer host. Existing browser saves are available only on the same origin; use Export/Import save when moving from a different origin. Browser storage can be cleared; retain exported backups.

### Validation and limitations
Game regression tests and host state-machine tests passed, including rejected packages, update readiness, preserved saves, failed-start recovery and manual rollback. A real mobile browser/install/offline end-to-end test was not available in this environment. Before relying on a long run, test installation, offline reopen, export/import and an update on your phone.

## Navigation update 1.1.0
Doors are opaque textured surfaces on adjacent wall faces, not floating icons. Touch the dungeon-view zones to walk, turn, or sidestep; blocked forward/back zones are disabled. Compass text and a north-up 400px map with a triangular facing marker clarify orientation. Encounters appear before the enlarged map. Close old app tabs and reopen after a deployment to release the previous offline cache. An imported package overrides the hosted bundled game: use App menu → Use bundled game to return to the latest hosted version.

## Equipment and encounter visuals 1.1.1
Gear screen has an auto-equip toggle (default on). Newly looted or purchased gear fills eligible empty slots; occupied slots are never replaced. It does not heal or equip items retroactively. The choice is saved in the run and retained as a device preference for new heroes; older saves default to the device preference. Existing gear is unrestricted by class; optional requiredLevel is honored for auto-equipping. Chest and vault encounters use wood-and-metal chest illustrations with locks and bands; traps, stairs, merchants, shrines, altars, fountains, hidden treasure and death also use procedural illustrations instead of emoji. These remain 2.5D scene illustrations.

## Compact phone layout 1.1.2
Explore fits the viewport with a compact HUD, expandable stats, dungeon-view controls, inset live map, and encounter actions. Tap Enlarge map to fill the dungeon viewport, then Close map to return. The map and dungeon remain on the same screen. Long gear, skill and merchant lists scroll within their own bounded panel rather than scrolling the whole app. Landscape and short displays use a more compact layout.

Version 1.1.3: traps are recessed floor mechanisms, with perspective frames, pressure plates, and grounded spikes.

Version 1.2.0 — grounded encounters and biome hazards
- Floor textures follow biome and world position; floor encounters use a lowered view and contact shadows.
- Floors 1–3: 20% chance of one trap, no locked doors. Doors begin on floor 4.
- Traps are subtle floor seams, hidden from maps without detection. Mechanist passive and Rogue classes highlight them; Inspect floor ahead reveals one manually. Stepping onto an undetected trap triggers it.
- Biome hazards include spikes/darts, poison drains, grave seals, shale, spores, ice, steam and void seals. Failures inflict typed damage and three-action effects. Movement and combat advance effects; turns and menus do not. Camping clears them.
- Picking/disarming or forcing a locked door reveals a treasure cache. Opening it grants gold and gear.
- Common encounters remain; biome pools and localized encounters add mineral pockets, medicinal roots, tool caches and regional merchants.
- Saves retain effects and inspected traps. Older early-floor maps remove locked doors and cap remaining traps at one.

Version 1.2.1: restored the level, forward-facing exploration camera. Floor examination angles apply only during encounters.

Version 1.2.2: a persistent activity feed above navigation shows journal messages immediately, newest first. Scroll within it for recent history; the Journal retains the same messages.

Version 1.2.3: borderless translucent movement hints, larger turn regions below the always-visible minimap, and a Menu toggle to hide hints while keeping touch navigation active. Preference is stored on this device.

Version 1.3.0 — food and hunger
- Start at 100 hunger. Each successful walking or sideways step consumes 1; turning, wall bumps, menus and combat do not.
- Above 50 hunger, carrying at least one ration restores 1 HP per step, up to maximum HP. No ration is consumed by this slow healing.
- At zero hunger, every step costs 10% of maximum HP, rounded up, and can kill. Food is eaten manually.
- Eat a ration for +40 hunger. Camp consumes a ration for +30 hunger, +10 HP, +8 MP and clears lingering effects.
- Enemy victories have a 25% chance of a ration; chests 40%. Three searchable rubbish/belongings encounters per new floor each have a 50% chance. Each can be searched once.
- HUD shows food and hunger; discoveries, healing and starvation appear in the activity feed and Journal.
- Hunger persists in saves. Older saves start at 100; existing floors gain searchable piles on the next floor generation.

Version 1.4.0 — provisions, durability and repair
- Deep Reserves I/II/III cost 8/16/28 Legacy Points; each adds 25 hunger capacity to future heroes (maximum 175). Healing requires more than 50% of that hero's capacity.
- Food chance: enemy victory 80%, chest 90%, searchable supplies 85%, successful trap salvage 65%. One ration per successful food roll.
- Hunger cost per step: Keep/Ruins 1, Crypt 1.1, Sewers 1.15, Caverns 1.2, Abyss 1.3, Ice/Forge 1.5.
- Sustaining loot affix reduces drain 10%. Add one permanent Sustaining modifier per item in Gear for 3 scrap (another 10%). Working equipped items stack to a maximum 60% reduction.
- All equipment has durability. Attacks wear weapons according to damage and skill cost; powered strikes wear more. Spell skills wear contributing focuses and spell rings. Incoming damage wears armor, headwear, gloves, boots and defensive offhands; acid/heat cause extra wear. Walking wears boots by 0.05.
- Any working ring can be channeled in combat for 3 MP to heal 8 + level/3 rounded down, then the enemy retaliates. It loses durability according to healing performed.
- Zero-durability gear stays in inventory/equipment but grants no bonuses until repaired. Breaking HP/MP gear clamps current resources to the reduced cap.
- Each repair spends 1 scrap for up to 20 durability, plus 2 per five character levels (level bonus capped at 20), plus Mechanist's 20, Alchemist's 15 or Warrior/Knight's 10. Repairing does not refill HP/MP. Repair and modification are allowed wherever normal gear changes are allowed.
- Salvaging unused equipment supplies scrap for repairs. Gear and inventory show durability bars, repair and modifier controls.
- Old saves retain their existing 100 hunger capacity and receive full durability on old equipment. New fields persist in subsequent saves.

Version 1.4.1 — merchant provisions
- Separate collapsible Food, Consumables and Equipment sections. Food and consumables start open; gear starts collapsed.
- Each merchant generates 2–6 rations sold together in one transaction at 12 gold each. Buying the bundle sells out that merchant’s food.
- Limited random stock: 1–4 healing potions (18g each), 1–3 mana tonics (20g), 0–3 antidotes (12g), 1–4 bandages (10g).
- Mana tonics restore 12 MP; antidotes remove Poison; bandages heal 10 HP and remove Bleeding.
- Use purchased consumables in Gear or from combat actions. Combat use takes a turn and allows enemy retaliation. Unneeded items cannot be wasted.
- Stock and consumable inventory persist in saves; reloading does not restock. Older saves preserve existing food/potion stock and initialize new consumables to zero.


Version 1.4.4 — merchant bulk provisions
- Merchants stock 10–200 rations on floors 1–3, in multiples of ten. Maximum stock increases by 40 per floor thereafter, capped at 1,000 on floor 23 and beyond.
- Buy 10 rations per transaction for 120 gold; purchases can repeat while stock and gold last. Remaining stock persists in saves.

## Version 1.5.3 — salvage and hybrid crafting
- Merchants on floors 1–3 offer only Common/Magic gear; floors 4–7 may offer Rare, and Epic gear begins on floor 8. Standard loot rarity is unchanged.
- Salvaging unequipped inventory gear now recovers type-specific materials in a persistent Materials Pouch, alongside legacy scrap. Physical yield depends on rarity and remaining durability; Rare and Epic items may yield a bonus rare material.
- One workbench encounter is added to newly generated floors. At a workbench choose one of six recipes and Basic, Refined or Masterwork material quality. Recipes consume pouch materials, guarantee the chosen equipment type and roll quality-dependent rarity and affixes. Crafting never destroys ingredients on a failure roll.
- Existing saves load with an empty Materials Pouch and preserve their current floor; new workbench encounters appear on subsequent newly generated floors.
- Merchant food purchases display and buy 10 rations per transaction (120 gold) rather than the merchant's entire stock.


## v1.5.5 Chest and Mimic update
Chests roll Common/Magic/Rare/Epic rarity, with rarity-based food bundles. Higher rarity chests are more often locked; pick locks or spend 5 MP on an unlocking spell. Failed attempts can trigger floor-scaled mimics. Mimics can also appear on opening any chest. Mimics drop guaranteed Rare-or-better Mimic-Touched gear, extra food and additional food when scavenged.
\n\n## v1.5.5 Mimic monster art\nMimics remain visually closed treasure chests until triggered by opening or a failed lock attempt. They then enter combat and render as distinct procedurally varied chest monsters, with teeth, eyes, tongue, limbs and chest hardware. Visual variants remain stable during the encounter.\n

## v1.5.5 compatibility
Dungeon doors initialize Epic vaults; old active chest/vault saves migrate to current chest mechanics; all chest rewards report added and total rations; the running version is visible on-screen.


## v1.5.5 Legacy transparency and activation
Legacy purchases are disabled while dead. Create a new hero, then use Legacy Hall to buy permanent unlocks, with relevant starting bonuses applied to that hero immediately. Skill enhancements update the current hero snapshot, activating only when the associated skill is learned. The Character Benefits & Legacy menu displays unlocks, current stats, passive skills, class path, buffs, and skill ranks.


## v1.5.5 Camping overhaul
Dedicated camping gear slot; starting Basic Bedroll; tiered camp equipment can be found, equipped, salvaged, repaired and crafted. Camping uses one ration and kit durability per rest cycle. Preview shows HP/MP recovery and ambush risk. Ambushes interrupt recovery. Old saves receive a basic bedroll if no camp gear exists.
\n\n## v1.5.6 Distance-based encounters\nVisible encounter objects and monsters are projected into the first-person corridor at up to five tiles away. Procedural sprites are scaled with perspective and clipped against wall-ray depth. Inspect scans ahead until a wall, while hidden traps and secret locations remain concealed. Existing saves unchanged.\n
## v1.5.8 Mobile playtesting
The embedded map uses left-side +/- zoom buttons (7, 9, 11, 15, 19 tiles) and a separated right-side expand button. Open More for an isolated developer test run. Game saves use the existing `pocketCrawSaveV1` and `labyrinthLegacyV1` keys. Save export/import is available under More; host App menu provides a backup download. The stable Vercel production URL is https://flying-poplar-97ino7z-paw20.vercel.app.


## v1.5.17 playtest update
Use **App menu → Import update** on the existing hosted Pocket Craw shell to load `pocket-craw-update.json`. This installs the game code in this browser's storage only, not on Vercel. Existing run and Legacy save keys are unchanged. The updater maintains a previous version and a pre-update save snapshot for recovery; preserve a separate full source ZIP as well.

Inspection costs 2 hunger. Traps and mimics on chests are hidden until inspection reveals clues. Magical unlock is class-gated. Scavenging is skill/class/equipment-gated. Rare universal chest keys open locks without disarming traps. Feeding an identified mimic uses a ration and may pacify or enrage it. Pet ownership and weight-based inventory limits are deferred design work.
\n## v1.5.21 playtest\nImport pocket-craw-update.json through the existing App menu. The production site is unchanged.\n
v1.5.24 importer candidate: App → Import update → `Pocket_Craw_v1.5.24_IMPORT_READY.json`. Existing production host unchanged. See CHANGELOG.md. Back up browser saves before testing.
