# v1.5.27 — Combat, equipment and crafting playtest overhaul

## Changes
- Enemies scale with floor using curved HP/attack growth, plus physical armor and magic ward. Enemy quantity remains separate from individual strength.
- Percentage mitigation replaces flat damage subtraction. Gear/passive attack and spell bonus pools have diminishing returns; critical chance caps at 40%, evade at 30%, resistance at 60%.
- Mage/Alchemist skills use arcane power instead of multiplying the entire physical ATK stack. Class skill Legacy ranks are preserved, with a smaller bonus. Power Strike costs at least 3 MP; class skills at least 4 MP. Overchannel trades 3 extra MP for an additive 25% bonus.
- Well-fed movement above 50% hunger regenerates 1 HP and 1 MP, even with no spare ration. Turns and UI actions do not regenerate. All camping tiers now restore MP, including the basic bedroll. Auto-eat below 10% remains enabled by default and independent of manual top-ups.
- Class-labelled weapons, armor and accessories. Specializations inherit their root class restrictions. Camping equipment and unidentified old starter equipment are Universal. Unclassed heroes can use class equipment until their first class selection.
- Warrior greatswords/warhammers, Mage staffs, Rogue chain whips/kusarigama, Knight halberds, Ranger longbows and Alchemist sprayers occupy both hands. Only Rogues may equip a second dagger/dirk. Conflicting equipment returns to inventory.
- One-time first-class weapon/armor kit prevents a class choice from leaving a new hero unequipped. Existing incompatible equipment moves to inventory without being deleted.
- Crafting offers matching class equipment and universal supplies at the current floor tier. Basic/Refined/Masterwork guarantee Common/Magic/Rare quality with fixed modifiers and item previews. Scrap converts into basic materials; dust refines into essence. Salvaging unwanted drops funds crafting and repairs.

## Preservation and scope
Import JSON only. No Vercel deployment. Hosted base remains v1.5.25; browser-imported game becomes v1.5.27.
Existing floor enemy profiles and active encounters retain their original stats; new enemy scaling applies to newly generated enemies/floors. The new combat formulas apply immediately. For a clean balance comparison, use a new test run. Existing saves, gold, inventory, Legacy ranks and storage keys are retained. Pre-migration saves are backed up before normal Continue/import migration. Old clients cannot interpret every new equipment arrangement (notably dual daggers); use App → Restore pre-update save if rolling back to an older engine.
This is a tested balance pass, not a claim that every human strategy is perfectly balanced. No hunger-economy overhaul, new boss-per-floor system, enemy intent system, or new skill trees in this release.

## Verification
- JavaScript syntax, complete source/JSON correspondence and ZIP integrity.
- Browser stability suite: save states, Legacy continuity, developer isolation, four mobile viewport sizes, navigation, JSON installation and reload, and rollback.
- All six classes tested against all equipment bases; two-handed displacement, dual-wield save round trip, old-save migration, mana recovery, deterministic crafting, salvage and conversions.
- Actual mobile inventory controls tested for main-hand, offhand dagger and two-handed slot label.
- 10,800 seeded single-combat simulations in the actual browser engine: six classes × three levels × two equipment/Legacy profiles × two floor depths × 150 encounters. Combat starts with full resources and uses a simple skill-first policy; these are combat benchmarks, not whole runs.
- 120 seeded automated exploration runs using actual generated mazes, movement, fights, recovery, equipment, crafting and salvage. Full map knowledge, no fleeing, and bounded action/rest budgets are test-policy limitations. See CAMPAIGN_RESULTS.json.
- Actual JSON installation in a local copy of the unchanged v1.5.25 host, including existing-save Continue and reload, is recorded in IMPORT_RESULTS.json.
- Physical Android testing remains for the user. No production or user browser data was modified by tests.

## Results

| Level-9 mage | Floor | One-shot rate | Mean turns | Mean HP lost |
|---|---:|---:|---:|---:|
| common | 9 | 0% | 2.82 | 29% |
| common | 13 | 0% | 4.21 | 77% |
| strong | 9 | 1% | 2.33 | 13% |
| strong | 13 | 0% | 3.65 | 37% |

Exploration: 72 deaths; 48 cleared floor 13; 0 action-limit exits. High-Legacy builds remained meaningfully stronger. Campaign characters gained levels along the route; these were not fixed level-9 tests.
