# v1.5.27 — import-only playtest

Built and tested locally. No Vercel deployment. Existing production dpl_2Nn7Ab2Yu3JX8awFM4T2jZHebMaD remains READY at https://flying-poplar-97ino7z-paw20.vercel.app, serving v1.5.25. The user imports the JSON to run v1.5.27. See TEST_RESULTS.json, BALANCE_RESULTS.json, CAMPAIGN_RESULTS.json, IMPORT_RESULTS.json and BALANCE_NOTES.md for evidence and limitations. Physical Android check pending.
