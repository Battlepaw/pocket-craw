// Bounded automated explorer: actual maze movement, encounters, combat, inventory and crafting.
globalThis.__campaign=(rush=false)=>{
 const original={render,saveGame,say};render=()=>{};saveGame=()=>true;say=()=>{};devMode=true;
 const random=Math.random;let seed=0;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296};
 const results=[];
 try{for(const cls of ['Warrior','Rogue','Mage','Knight','Ranger','Alchemist'])for(const legacyTier of ['none','high'])for(let run=0;run<3;run++){
  seed=1000+run;unlocks=new Set(['Knight','Ranger','Alchemist']);legacyModernRanks=legacyTier==='high'?Object.fromEntries(legacyModern.map(i=>[i.id,i.cap])):{};for(const k of Object.keys(skillEnhancements))delete skillEnhancements[k];
  newRun();let visitedMerchants=new Set(),visitedFloor=1;let actions=0,camps=0,crafts=0,fights=0,steps=0;const score=i=>!i?0:(i.atk||0)*2+(i.def||0)*1.8+(i.life||0)*.25+(i.mana||0)*.25+(i.spell||0)*30+(i.crit||0)*20+(i.evade||0)*20;
  const click=prefix=>{renderActions();const b=[...$('actions').querySelectorAll('button')].find(x=>x.textContent.startsWith(prefix)&&!x.disabled);if(b)b.click();else mode='explore'};
  while(g.hp>0&&g.floor<=16&&actions++<4000){
   if(g.floor!==visitedFloor){visitedFloor=g.floor;visitedMerchants.clear()}
   if(mode==='class'){classPick(!g.cls?cls:classOptions()[0]);continue;}
   if(g.pendingRewards?.length&&gearAllowed()){chooseReward(2);continue;}
   if(mode==='combat'){fights++;if(enemy.exitGuardian&&g.hp<healthCap()*.25&&!g.potions){fight('flee');continue;}if(g.hp<Math.min(healthCap()*.4,enemy.atk*2)&&g.potions)fight('potion');else if(g.cls&&g.mp>=skillCost())fight('skill');else if(g.mp>=powerCost())fight('power');else fight('attack');continue;}
   if(mode==='corpse'){mode='explore';continue;}
   if(mode==='chest'||mode==='vault'){if(g.chestLocked){if(ensurePicks().basic)chestPick('basic');else mode='explore'}else openChest();continue;}
   if(mode==='resource'){collectBiomeResource();continue;}if(mode==='supplies'){searchSupplies();continue;}
   if(mode==='fountain'){click('Drink');continue;}
   if(mode==='secret'){click('Search');continue;}
   if(mode==='shrine'){click('Pray');continue;}
   if(mode==='merchant'){visitedMerchants.add(K(g.x,g.y));tradeCart.clear();const offers=tradeOffers();for(const o of offers)if(o.side==='sell'&&(o.kind==='cargo'||o.kind==='gear'))setBasket(o.id,o.max);if(supplyAmount('rations')>25)setBasket('sell:rations',Math.min(10,supplyAmount('rations')-25));if(currentTrader()?.kind==='general'){setBasket('buy:potions',Math.min(2,Math.max(0,3-g.potions)));setBasket('buy:manaTonics',Math.min(2,Math.max(0,3-g.manaTonics)));}if(basketQuote().ok)checkoutTrade();if(g.rations>=30)foodCommission();closeMerchant();continue;}
   if(mode==='elite'){mode='explore';continue;}
   if(mode==='stairs'){const remaining=[...events.values()].filter(x=>['enemy','chest','supplies'].includes(x)).length;if(!rush&&remaining>1)mode='explore';else{descend();continue;}}
   if(mode!=='explore'){mode='explore';continue;}
   const lanes=['Mage','Alchemist'].includes(cls)?[2,1,4,6]:cls==='Rogue'?[3,0,6,1]:[0,1,6,7];const picks=lanes.flatMap(i=>['route'+i,...Array.from({length:8},(_,j)=>'w'+i+'_'+j),'w'+i+'_8','w'+i+'_11']);for(const id of picks)if(!passiveLockReason(id))allocatePassive(id);
   for(const cargo of [...g.cargo])if(cargo.kind==='treasure'||canScavenge())processCargo(cargo.id);
   for(const item of [...g.inventory]){if(!equipReason(item)&&score(item)>score(g.equipment[item.slot])+(item.hands===2?score(g.equipment.offhand):item.slot==='offhand'&&g.equipment.weapon?.hands===2?score(g.equipment.weapon):0))equipGear(item);else if(g.baseClass==='Rogue'&&item.dagger&&score(item)>score(g.equipment.offhand)&&g.equipment.weapon?.hands!==2)equipGear(item,'offhand');}
   for(const item of [...g.inventory])salvageGear(item);
   for(const item of Object.values(g.equipment))if(item&&item.durability<item.maxDurability*.35&&g.scrap>0)repairGear(item);
   if(g.hunger<55&&g.rations)eat();
   if(g.hp<healthCap()*.65&&g.bandages)useConsumable('bandages');
   if(g.mp<skillCost()&&g.manaTonics)useConsumable('manaTonics');
   if(g.baseClass&&g.scrap>=2){mode='camp';for(const recipe of craftRecipes){const rule=gearRules[recipe.base];if(!rule||rule[0]!==g.baseClass)continue;const candidate=makeGear(recipe.base,g.floor,0,true);if(score(candidate)<=score(g.equipment[candidate.slot])+(candidate.hands===2?score(g.equipment.offhand):candidate.slot==='offhand'&&g.equipment.weapon?.hands===2?score(g.equipment.weapon):0))continue;for(const [k,n]of Object.entries(recipe.cost))while(['metal','wood','leather','cloth'].includes(k)&&materialBag()[k]<n&&g.scrap)convertScrap(k);if(canCraft(recipe,'basic')){craftGear(recipe,'basic');crafts++;break}}mode='explore';}
   if(g.hp<healthCap()*.55&&g.rations&&campData()&&camps<80){mode='camp';if(g.rations>=3)campMeal();else rest();camps++;if(mode!=='combat')mode='explore';continue;}
   // BFS chooses nearest remaining encounter, then stairs. Full map knowledge is a testing advantage.
   const targets=new Set([...events].filter(([,t])=>['enemy','chest','supplies','fountain','secret','shrine','merchant','resource'].includes(t)).map(([k])=>k));
   // Do not revisit persistent merchants.
   for(const key of visitedMerchants)targets.delete(key);
   if(rush)targets.clear();if(targets.size<2)targets.add(K(...m.exit));
   const queue=[[g.x,g.y,[]]],visited=new Set([K(g.x,g.y)]);let route=null;
   for(let i=0;i<queue.length;i++){const [x,y,path]=queue[i];if(path.length&&targets.has(K(x,y))){route=path;break}for(let d=0;d<4;d++){const nx=x+D[d][0],ny=y+D[d][1],k=K(nx,ny);if(!wall(nx,ny)&&!visited.has(k)){visited.add(k);queue.push([nx,ny,[...path,d]])}}}
   if(!route){if(K(g.x,g.y)===K(...m.exit)){mode='stairs';descend();continue;}throw Error('No reachable exit');}g.dir=route[0];move(1);steps++;
  }
  results.push({cls,legacyTier,seed:1000+run,floor:g.floor,level:g.level,alive:g.hp>0,kills:g.kills,actions,steps,camps,crafts,reason:g.hp<=0?'death':g.floor>16?'cleared floor 16':'action limit'});
 }
 return {runs:results.length,policy:(rush?'Rush exits. ':'Clear encounters. ')+'Full-map BFS, guardian retreat permitted; spend connected points, compare/equip/salvage, basic crafting, repair, potions/bandages/tonics, manual food above 50%, camp meal or rest under 55%, food orders only with at least 30 rations. Limited to 4000 actions and 80 rests. No player data or real storage.',results};
 }finally{Math.random=random;render=original.render;saveGame=original.saveGame;say=original.say;}
};
