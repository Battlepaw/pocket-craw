// Injected only in test browser; never included in update JSON.
globalThis.__lab={makeGear,gearBases,gearRules,equipGear,equipReason,acquireGear,reconcileEquipment,gearStat,healthCap,manaCap,tagGear,rest,hungerStep,craftGear,craftRecipes,materialBag,convertScrap,refineMaterials,salvageGear,makeEnemy,classPick,skillCost,powerCost,snapshot,restoreSave,validateSave,loadAndMigrate,render,
 get hero(){return g},get mode(){return mode},set mode(v){mode=v},get notes(){return notes},get maze(){return m},get stock(){return stock},set enemy(v){enemy=v},get enemy(){return enemy},
 simulate(){
  const saved={render,saveGame,say,levelCheck,receiveGear,monsterFoodDrop};render=()=>{};saveGame=()=>true;say=()=>{};levelCheck=()=>{};receiveGear=()=>{};monsterFoodDrop=()=>{};devMode=true;
  let seed=27;const random=Math.random;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296};
  const profiles=[],rows=[];
  try{
   const kits={Warrior:['Greatsword','Helm','Mail','Gauntlets','Boots','Ring','War Badge'],Rogue:['Dagger','Cowl','Leathers','Grips','Softsteps','Shadow Ring','Charm'],Mage:['Staff','Hood','Robes','Spellweave','Slippers','Signet','Rune Pendant'],Knight:['Mace','Aegis','Greathelm','Plate','Vambraces','Sabatons','Oath Ring','Medallion'],Ranger:['Longbow','Cap','Jerkin','Bracers','Trailboots','Trail Ring','Trail Token'],Alchemist:['Sprayer','Goggles','Coat','Labgloves','Waders','Reagent Ring','Formula Seal']};
   for(const cls of Object.keys(kits))for(const level of [5,9,15])for(const tier of ['common','strong']){
    newRun();g.level=level;g.atk=6+level-1;g.def=2+Math.floor(level/2);g.maxhp=34+6*(level-1);g.maxmp=12+3*(level-1);g.points=level-1;g.cls=cls;g.baseClass=cls;g.skill=classNodes[cls].skill;g.classPath=[{name:cls,level:5}];const b=bonuses[classNodes[cls].style];g.atk+=b.atk;g.def+=b.def;g.maxhp+=b.hp;g.maxmp+=b.mp;
    g.enhancements=tier==='strong'?Object.fromEntries([...Object.keys(passiveNodes).filter(id=>id!=='origin').map(id=>['passive:'+id,5]),['class:'+cls,5]]):{};
    const picks=['Mage','Alchemist'].includes(cls)?['p2_0','p2_1','p2_2','p2_3','p2_4','p2_5','p0_0','p0_1','p0_2','p1_0','p1_1','p1_2','p1_3','p1_4']:['p0_0','p0_1','p0_2','p0_3','p0_4','p0_5','p1_0','p1_1','p1_2','p1_3','p1_4','p3_0','p3_1','p3_2'];
    g.passives=picks.slice(0,level-1);for(const id of g.passives){const e=passiveEffect(id);for(const k of ['atk','def','maxhp','maxmp'])g[k]+=e[k]||0;}
    if(tier==='strong'){g.maxhp+=30;g.maxmp+=12;}
    g.equipment=Object.fromEntries(gearSlots.map(k=>[k,null]));for(const name of kits[cls]){const item=makeGear(name,level,tier==='strong'?2:0,true);g.equipment[item.slot]=item;}if(cls==='Rogue')g.equipment.offhand=makeGear('Dagger',level,tier==='strong'?2:0,true);
    g.hp=healthCap();g.mp=manaCap();g.potions=0;g.xp=0;g.need=1e9;g.inventory=[];const profile=JSON.parse(JSON.stringify(g));profiles.push({cls,level,tier,hero:profile});
    for(const floor of [level,level+4]){let wins=0,turns=0,loss=0,ones=0,spent=0;
     for(let run=0;run<150;run++){g=structuredClone(profile);g.floor=floor;m.biome=Object.keys(biomes)[run%8];enemy=makeEnemy();mode='combat';const hp=g.hp,mp=g.mp;let n=0;while(mode==='combat'&&n++<60){fight(g.mp>=skillCost()?'skill':g.mp>=powerCost()?'power':'attack');}if(g.hp>0&&mode!=='combat')wins++;if(n===1)ones++;turns+=n;loss+=(hp-g.hp)/hp;spent+=mp-g.mp;}
     rows.push({cls,level,tier,floor,battles:150,winPct:Math.round(wins/1.5),oneShotPct:Math.round(ones/1.5),turns:+(turns/150).toFixed(2),hpLossPct:Math.round(loss/1.5),mpSpent:+(spent/150).toFixed(1)});
    }
   }
   return {seed:27,profiles,rows,battles:rows.length*150};
  }finally{Math.random=random;Object.assign(globalThis,{});render=saved.render;saveGame=saved.saveGame;say=saved.say;levelCheck=saved.levelCheck;receiveGear=saved.receiveGear;monsterFoodDrop=saved.monsterFoodDrop;}
 }
};
