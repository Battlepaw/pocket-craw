(()=>{
 if(!globalThis.PocketCrawReady)throw Error('Game did not initialize');
 const $=id=>document.getElementById(id),game=$('game'),section=id=>$(id).closest('section');
 const hud=section('hp');hud.classList.add('compact-hud');game.querySelector('header').classList.add('compact-header');
 const extra=document.createElement('div');extra.className='hero-extra';extra.hidden=true;extra.appendChild($('stats'));extra.appendChild($('role'));hud.appendChild(extra);
 const statsButton=document.createElement('button');statsButton.textContent='Stats';statsButton.className='stats-toggle';statsButton.setAttribute('aria-expanded','false');statsButton.onclick=()=>{extra.hidden=!extra.hidden;statsButton.setAttribute('aria-expanded',String(!extra.hidden))};hud.querySelector('.flex').appendChild(statsButton);
 // Floating playfield quick use. No modification to movement or minimap controls.
 const quick=document.createElement('div');quick.className='pc-quick';
 const toggleQuick=document.createElement('button');toggleQuick.type='button';toggleQuick.textContent='🧪';toggleQuick.setAttribute('aria-label','Quick use');toggleQuick.setAttribute('aria-expanded','false');toggleQuick.title='Quick use';
 const quickChoices=document.createElement('div');quickChoices.className='pc-quick-choices';quickChoices.hidden=true;
 quick.append(toggleQuick,quickChoices);
 const renderQuick=()=>{quickChoices.replaceChildren();const s=globalThis.PocketCrawQuickState?.();if(!s)return;for(const [kind,label,count,allowed] of [['hp','🧪 Health',s.hp,s.canHp],['mp','✦ Mana',s.mp,s.canMp],['food','🍞 Food',s.food,s.canFood]]){const b=document.createElement('button');b.type='button';b.textContent=label+' ×'+count;b.disabled=!allowed;b.onclick=()=>{quickChoices.hidden=true;toggleQuick.setAttribute('aria-expanded','false');globalThis.PocketCrawQuickUse?.(kind)};quickChoices.appendChild(b)}};
 toggleQuick.onclick=()=>{quickChoices.hidden=!quickChoices.hidden;toggleQuick.setAttribute('aria-expanded',String(!quickChoices.hidden));if(!quickChoices.hidden)renderQuick()};
 const quickPosKey='pocketCrawQuickPositionV2';let quickPos='bottom-slot';try{quickPos=localStorage.getItem(quickPosKey)||'bottom-slot'}catch(e){};
 function positionQuick(pos){quickPos=['bottom-slot','top-left','top-right','bottom-left','bottom-right'].includes(pos)?pos:'bottom-slot';quick.dataset.position=quickPos;try{localStorage.setItem(quickPosKey,quickPos)}catch(e){}}
 positionQuick(quickPos);
 const explore=document.createElement('section');explore.className='explore-screen';game.appendChild(explore);
 const viewport=$('viewport');explore.appendChild(viewport);explore.appendChild($('heading'));const actionsPanel=section('actions');actionsPanel.classList.add('encounter-panel');explore.appendChild(actionsPanel);
 const mapPanel=section('map');mapPanel.className='map-inset';mapPanel.querySelector('h3').textContent='Map';const expand=document.createElement('button');expand.className='map-expand';expand.textContent='Enlarge map';expand.setAttribute('aria-expanded','false');expand.onclick=()=>{const full=mapPanel.classList.toggle('map-full');expand.textContent=full?'↙':'⛶';expand.setAttribute('aria-label',full?'Close expanded map':'Expand map');expand.setAttribute('aria-expanded',String(full));globalThis.PocketCrawResize?.()};const mapBar=document.createElement('div');mapBar.className='map-controls';
 const zoomButtons=document.createElement('div');zoomButtons.className='zoom-buttons';
 for(const [symbol,delta,name] of [['−',1,'Zoom out'],['+',-1,'Zoom in']]){const b=document.createElement('button');b.type='button';b.textContent=symbol;b.setAttribute('aria-label',name);b.onclick=()=>globalThis.PocketCrawMapZoom?.(delta);zoomButtons.appendChild(b)}
 const zoomLabel=document.createElement('span');zoomLabel.id='mapZoomLabel';zoomLabel.textContent='11 tiles';
 expand.textContent='⛶';expand.setAttribute('aria-label','Expand map');
 const legend=document.createElement('div');legend.className='pc-map-legend';legend.textContent='B Guardian · Ω Portal · ↩ Return · ! Enemy · E Elite · $ Trader · S Shrine · A Altar · W Wager · ◆ Chest · V Vault · + Fountain · ? Discovery · P Supplies · R Resources · D Door · ▲ Trap · ⌂ Camp';mapPanel.append(legend);mapBar.append(zoomButtons,zoomLabel,expand);mapPanel.prepend(mapBar);viewport.appendChild(mapPanel);const bottom=document.createElement('div');bottom.className='dungeon-bottom';explore.appendChild(bottom);bottom.appendChild(mapPanel);bottom.appendChild($('heading'));bottom.appendChild(actionsPanel);
 $('biomeInfo').classList.add('tab-off');document.querySelector('.layout').classList.add('tab-off');
 const panels={explore:[explore],gear:[section('gearSlots')],skills:[section('passiveGraph')],journal:[section('log')],hero:[section('characterBenefits')],menu:[document.querySelector('.save-tools'),$('legacySkillPanel')]};
 const content=document.createElement('div');content.className='screen-content';for(const els of Object.values(panels))for(const el of els)content.appendChild(el);game.appendChild(content);
 const quickSettings=document.createElement('section');quickSettings.className='panel pc-quick-settings';quickSettings.innerHTML='<h3>Quick-use position</h3><label for="pcQuickPosition">Place the potion button</label> ';
 const quickSelect=document.createElement('select');quickSelect.id='pcQuickPosition';for(const [value,label] of [['bottom-slot','Bottom-right thumb slot'],['top-left','Upper left'],['top-right','Upper right (near minimap)'],['bottom-left','Lower left'],['bottom-right','Lower right']]){const opt=document.createElement('option');opt.value=value;opt.textContent=label;quickSelect.appendChild(opt)}quickSelect.value=quickPos;quickSelect.onchange=()=>positionQuick(quickSelect.value);quickSettings.appendChild(quickSelect);content.appendChild(quickSettings);panels.menu.push(quickSettings);
 const foodSettings=document.createElement('section');foodSettings.className='panel';
 foodSettings.innerHTML='<h3>Settings</h3><label><input id="pcAutoEat" type="checkbox"> Auto-eat rations</label><p class="muted">Automatically eat one ration (+40 hunger) when an action drops hunger below 10% of your maximum, before starvation damage. Manual eating remains available for topping up.</p>';
 const autoEatToggle=foodSettings.querySelector('#pcAutoEat');autoEatToggle.checked=globalThis.PocketCrawAutoEat.enabled;autoEatToggle.onchange=()=>globalThis.PocketCrawAutoEat.set(autoEatToggle.checked);content.appendChild(foodSettings);panels.menu.push(foodSettings);
 // One bounded scroll container owns the full connected tree.
 const skillSection=section('passiveGraph');skillSection.classList.add('pc-progress');
 const graph=$('passiveGraph'),scroll=graph.parentElement,pointsSource=$('passivePoints'),detail=$('passiveDetail'),learn=$('learnPassive');
 const skillTop=document.createElement('div');skillTop.className='pc-skill-top';
 const skillPoints=document.createElement('span');skillPoints.className='pc-skill-points';
 const skillHelp=document.createElement('button');skillHelp.type='button';skillHelp.textContent='ⓘ';skillHelp.setAttribute('aria-label','Skill tree help');
 const helpText=document.createElement('dialog');helpText.className='pc-skill-dialog';helpText.innerHTML='<h3>Skill tree</h3><p>Swipe the tree in either direction. Search and zoom the connected web. Select a node to preview a route, then Learn one point at a time. Choose one mastery per cluster. Free resets before level 5 and once at class choice; later reset at camp for gold.</p><button type="button">Close</button>';helpText.querySelector('button').onclick=()=>helpText.close();skillHelp.onclick=()=>helpText.showModal();document.body.appendChild(helpText);
 const classSection=section('classTree');classSection.classList.remove('tab-off');classSection.querySelector('details').open=true;
 const classDialog=document.createElement('dialog');classDialog.className='pc-skill-dialog';const closeClasses=document.createElement('button');closeClasses.textContent='Close classes';closeClasses.onclick=()=>classDialog.close();classDialog.append(closeClasses,classSection);document.body.appendChild(classDialog);
 const classToggle=document.createElement('button');classToggle.type='button';classToggle.textContent='Classes';classToggle.onclick=()=>classDialog.showModal();
 skillTop.append(skillPoints,classToggle,skillHelp);
 const skillSheet=document.createElement('div');skillSheet.className='pc-skill-sheet';skillSheet.hidden=true;
 const closeSkill=document.createElement('button');closeSkill.type='button';closeSkill.className='pc-skill-close';closeSkill.textContent='×';closeSkill.setAttribute('aria-label','Close skill details');closeSkill.onclick=()=>skillSheet.hidden=true;
 skillSheet.append(closeSkill,detail,learn);const webTools=document.createElement('div');webTools.className='web-tools';const search=document.createElement('input');search.type='search';search.placeholder='Find a skill or mechanic';search.setAttribute('aria-label','Search passive web');search.oninput=()=>globalThis.PocketCrawWeb.search(search.value);webTools.append(search);for(const [label,action]of [['−',()=>globalThis.PocketCrawWeb.zoom(-.15)],['+',()=>globalThis.PocketCrawWeb.zoom(.15)],['Center',()=>globalThis.PocketCrawWeb.center()],['Reset points',()=>globalThis.PocketCrawWeb.reset()]]){const b=document.createElement('button');b.textContent=label;b.onclick=action;if(label==='Reset points')b.id='pcRespec';webTools.append(b)}skillSection.replaceChildren(skillTop,webTools,scroll,skillSheet);scroll.setAttribute('aria-label','Skill tree; swipe horizontally and vertically');
 const updateSkillPoints=()=>{skillPoints.textContent=pointsSource.textContent||'Skill points'};pointsSource.hidden=true;skillSection.appendChild(pointsSource);new MutationObserver(updateSkillPoints).observe(pointsSource,{childList:true,subtree:true});updateSkillPoints();
 graph.addEventListener('click',e=>{if(e.target.closest('button'))skillSheet.hidden=false});
 // Status: concise active effects and combat diagnostics; avoid duplicate main HUD.
 const statusSection=section('characterBenefits');statusSection.querySelector('h3').textContent='Status · effects and combat';
 const statusBox=document.createElement('div');statusBox.id='pcStatusDiagnostics';statusBox.className='pc-status-diagnostics';statusSection.insertBefore(statusBox,statusSection.querySelector('details'));
 const originalShowStatus=()=>{const raw=$('stats').textContent;const benefits=$('characterBenefits').textContent;const effects=(benefits.match(/(?:Poison|Bleeding|Burn|Frostbite|Curse)[^\n]*/gi)||[]);statusBox.replaceChildren();const stats=document.createElement('p');stats.textContent=raw||'Combat statistics available during a run.';statusBox.appendChild(stats);const active=document.createElement('p');active.textContent=effects.length?'Conditions: '+effects.join(' · '):'Conditions: inspect character benefits below for active effects and modifiers.';statusBox.appendChild(active)};
 new MutationObserver(originalShowStatus).observe($('stats'),{childList:true,characterData:true,subtree:true});
 // In-game ticker: no parent/host DOM access is needed for imported updates.
 const tickerDefault={size:12,seconds:5,mode:'scroll',timestamps:false,alerts:true,dock:'top'};
 let tickerPrefs={...tickerDefault};try{tickerPrefs={...tickerPrefs,...JSON.parse(localStorage.getItem('pocketCrawTickerPrefsV1')||'{}')}}catch(e){}
 const eventStyle=msg=>{const m=msg.toLowerCase();if(/combat|attacks|lunges|berserk|ambush|enemy strikes|battle begins/.test(m))return 'combat';if(/trap activates|poison darts|you take|critical|you died|dead|bleeding|starving/.test(m))return 'danger';if(/suspicious|might be|seems odd|thin wire|warning|uneasy/.test(m))return 'caution';if(/discover|found|unlocked|reveals|detected|hidden compartment/.test(m))return 'discovery';if(/gain|earned|experience|loot|reward|gold|ration/.test(m))return 'reward';return 'normal'};
 const colors={normal:'#edf0f6',combat:'#ff8a8a',danger:'#ff7474',caution:'#f2c66d',discovery:'#75e4ad',reward:'#8dbfff'};
 const ticker=document.createElement('button');ticker.id='pcInGameTicker';ticker.type='button';ticker.setAttribute('aria-label','Open event log and ticker settings');
 const display=document.createElement('span');ticker.appendChild(display);game.prepend(ticker);
 const dialog=document.createElement('dialog');dialog.id='pcInGameLog';dialog.innerHTML='<h2>Event Log</h2><div id="pcEventHistory"></div><details><summary>Ticker settings</summary><label>Text size <select id="pcTickerSize"><option value="10">Small</option><option value="12">Normal</option><option value="15">Large</option><option value="18">Extra large</option></select></label><label>Long messages <select id="pcTickerMode"><option value="scroll">Scroll</option><option value="truncate">Short preview</option></select></label><label>Seconds per message <input id="pcTickerSeconds" type="number" min="2" max="12" step="1"></label><label>Show timestamps <input id="pcTickerTime" type="checkbox"></label><label>Highlight danger <input id="pcTickerAlerts" type="checkbox"></label><label>Ticker position <select id="pcTickerDock"><option value="top">Top of game</option><option value="bottom">Above bottom menu</option></select></label></details><button id="pcEventClose" type="button">Return to game</button>';
 document.body.appendChild(dialog);const logBody=dialog.querySelector('#pcEventHistory');
 function applyTicker(){ticker.style.fontSize=tickerPrefs.size+'px';ticker.dataset.dock=tickerPrefs.dock;display.style.textOverflow=tickerPrefs.mode==='truncate'?'ellipsis':'clip';display.style.animation='none';void display.offsetWidth;if(tickerPrefs.mode==='scroll'&&display.scrollWidth>ticker.clientWidth)display.style.animation='pcTickerMarquee '+Math.max(6,tickerPrefs.seconds)+'s linear infinite'}
 function updateLog(){logBody.replaceChildren();for(const line of ($('log').textContent||'').split('\n').filter(Boolean)){const d=document.createElement('div');d.textContent=line;d.style.color=colors[eventStyle(line)];logBody.appendChild(d)}}
 ticker.onclick=()=>{updateLog();dialog.showModal()};dialog.querySelector('#pcEventClose').onclick=()=>dialog.close();
 for(const [id,key,convert] of [['pcTickerSize','size',Number],['pcTickerMode','mode',String],['pcTickerSeconds','seconds',Number],['pcTickerTime','timestamps',Boolean],['pcTickerAlerts','alerts',Boolean],['pcTickerDock','dock',String]]){const el=dialog.querySelector('#'+id);el[el.type==='checkbox'?'checked':'value']=tickerPrefs[key];el.onchange=()=>{tickerPrefs[key]=el.type==='checkbox'?el.checked:convert(el.value);if(key==='seconds')tickerPrefs.seconds=Math.max(2,Math.min(12,tickerPrefs.seconds||5));try{localStorage.setItem('pocketCrawTickerPrefsV1',JSON.stringify(tickerPrefs))}catch(e){}applyTicker()}}
 let lastNote='',tickerTimer=null,queue=[];
 function showTickerMessage(msg){clearTimeout(tickerTimer);display.textContent=(tickerPrefs.timestamps?'['+new Date().toLocaleTimeString()+'] ':'')+msg;const kind=eventStyle(msg);display.style.color=colors[kind];ticker.style.borderColor=(kind==='combat'||kind==='danger')&&tickerPrefs.alerts?'#d46b6b':'#526079';applyTicker();tickerTimer=setTimeout(()=>{tickerTimer=null;if(queue.length)showTickerMessage(queue.shift())},Math.min(1800,Math.max(700,tickerPrefs.seconds*350)))}
 function emitTicker(msg){if(!msg)return;const previous=lastNote;lastNote=msg;if(previous==='Ticker ready — tap for Event Log'){queue.length=0;showTickerMessage(msg)}else if(tickerTimer){queue.push(msg);if(queue.length>80)queue.shift()}else showTickerMessage(msg)}
 const newestEvent=()=>($('log').textContent||'').split('\n')[0]?.replace(/^›\s*/,'').trim();
 document.addEventListener('pc-event',e=>{emitTicker(e.detail);if(dialog.open)updateLog()});
 showTickerMessage('Ticker ready — tap for Event Log');lastNote='Ticker ready — tap for Event Log';

 applyTicker();
 const nav=document.createElement('nav');nav.className='mobile-nav';nav.setAttribute('aria-label','Game screens');const buttons={};
 function show(tab){game.dataset.screen=tab;globalThis.PocketCrawRefreshScreen?.(tab);if(tab==='hero')originalShowStatus();for(const [key,els]of Object.entries(panels))for(const el of els)el.classList.toggle('tab-off',key!==tab);for(const [key,b]of Object.entries(buttons))b.setAttribute('aria-current',key===tab?'page':'false');extra.hidden=true;statsButton.setAttribute('aria-expanded','false');content.scrollTop=0;requestAnimationFrame(()=>{globalThis.PocketCrawResize?.();if(tab==='skills')globalThis.PocketCrawWeb?.open()})}
 for(const [key,label]of Object.entries({explore:'Dungeon',gear:'Items',skills:'Progress',hero:'Status',menu:'More'})){const b=document.createElement('button');b.textContent=label;b.onclick=()=>show(key);nav.appendChild(b);buttons[key]=b}game.appendChild(nav);nav.appendChild(quick);
 function mountQuick(){if(quickPos==='bottom-slot'){nav.appendChild(quick)}else viewport.appendChild(quick)}
 const originalPositionQuick=positionQuick;positionQuick=function(pos){originalPositionQuick(pos);mountQuick()};positionQuick(quickPos);
 $('legacyBtn').addEventListener('click',()=>show('explore'));$('startBtn').addEventListener('click',()=>show('explore'));$('continueBtn').addEventListener('click',()=>{if(!$('game').hidden)show('explore')});
 for(const [id,label]of Object.entries({left:'Turn left',right:'Turn right',up:'Move forward',down:'Move backward',sl:'Strafe left',sr:'Strafe right'})){$(id).setAttribute('aria-label',label);$('view-'+id).onclick=()=>$(id).click()}
 const compact=document.createElement('div');compact.className='survival-strip';compact.innerHTML='<span>❤️ <b id=miniHp></b></span><span>✦ <b id=miniMp></b></span><span id=miniFoodWrap>🍞 <b id=miniFood></b></span><span id=miniGoldWrap>🪙 <b id=miniGold></b></span><span>S<b id=miniFloor></b></span>';hud.prepend(compact);const compactObserver=new MutationObserver(()=>{const status=$('money').textContent;const rationMatch=status.match(/\bFood\s+(\d+)/);const hungerMatch=status.match(/\bHunger\s+([\d.]+)\/([\d.]+)/);const food=rationMatch&&hungerMatch?[null,rationMatch[1],hungerMatch[1],hungerMatch[2]]:null;const goldMatch=status.match(/(?:🪙\s*|\b(?:Gold|Coins?)\s*[:=]?\s*)([\d,]+)/i);$('miniGold').textContent=goldMatch?goldMatch[1]:'—';$('miniHp').textContent=$('hp').textContent;$('miniMp').textContent=$('mp').textContent;$('miniFloor').textContent=($('floor').textContent.match(/Stage\s+(\d+)/)||[])[1]||'?';$('miniFood').textContent=food?food[2]+'/'+food[3]+' · '+food[1]+' food':'—';$('miniFoodWrap').classList.toggle('food-warning',!!food&&Number(food[2])<=Number(food[3])*.2)});compactObserver.observe($('money'),{childList:true,characterData:true,subtree:true});const controlSetting=document.createElement('label');controlSetting.className='touch-hints-setting';const hints=document.createElement('input');hints.type='checkbox';hints.id='touchHints';let showHints=true;try{showHints=localStorage.getItem('pocketCrawTouchHints')!=='off'}catch(e){}hints.checked=showHints;viewport.classList.toggle('hide-touch-hints',!showHints);hints.onchange=()=>{viewport.classList.toggle('hide-touch-hints',!hints.checked);try{localStorage.setItem('pocketCrawTouchHints',hints.checked?'on':'off')}catch(e){}};controlSetting.append(hints,document.createTextNode(' Show movement icons'));panels.menu[0].prepend(controlSetting);$('legacyBtn').hidden=true;
 const legacyPanel=document.createElement('section');legacyPanel.className='panel pc-legacy-entry';
 const legacyOpen=document.createElement('button');legacyOpen.type='button';legacyOpen.textContent='🏛 Legacy Upgrades';legacyOpen.className='pc-progress-legacy';legacyOpen.textContent='Legacy';skillTop.insertBefore(legacyOpen,classToggle);
 const legacyDialog=document.createElement('dialog');legacyDialog.className='pc-legacy-dialog';legacyDialog.innerHTML='<div class="pc-legacy-head"><h2>🏛 Legacy Upgrades</h2><button type="button" class="pc-legacy-close">✕</button></div><p id="pcLegacyBalance"></p><div id="pcLegacyCatalog"></div><details><summary>Classic unlocks already in your save</summary><p>Previously purchased classes, locations and equipment remain active. Older one-time purchases are preserved.</p><div id="pcClassicUnlocks"></div><button type="button" id="pcClassicHall">Open Classic Legacy Hall</button></details>';
 document.body.appendChild(legacyDialog);
 const legacyList=legacyDialog.querySelector('#pcLegacyCatalog');legacyDialog.querySelector('#pcClassicHall').onclick=()=>{legacyDialog.close();$('legacyBtn').click();show('explore')};
 function refreshLegacy(){const data=globalThis.PocketCrawLegacyCatalog?.();if(!data)return;legacyDialog.querySelector('#pcLegacyBalance').textContent=data.points+' Legacy Points available';legacyList.replaceChildren();for(const item of data.modern){const row=document.createElement('div');row.className='pc-legacy-row';const info=document.createElement('div');const name=document.createElement('strong');name.textContent=item.name+' · '+item.rank+'/'+item.cap;const desc=document.createElement('small');desc.textContent=item.desc;info.append(name,desc);const b=document.createElement('button');b.textContent=item.rank>=item.cap?'MAX':item.price+' LP';b.disabled=data.test||item.rank>=item.cap||data.points<item.price;b.onclick=()=>{const result=globalThis.PocketCrawLegacyPurchase?.(item.id);if(result&&!result.ok)alert(result.message);refreshLegacy()};row.append(info,b);legacyList.appendChild(row)}const classic=legacyDialog.querySelector('#pcClassicUnlocks');classic.replaceChildren();for(const item of data.original){const p=document.createElement('p');p.textContent=(item.owned?'✓ ':'○ ')+item.name+' · '+item.cost+' LP';classic.appendChild(p)}}
 function openLegacyDialog(){refreshLegacy();legacyDialog.showModal()};legacyOpen.onclick=openLegacyDialog;legacyDialog.querySelector('.pc-legacy-close').onclick=()=>legacyDialog.close();
 const splashLegacy=document.createElement('button');splashLegacy.type='button';splashLegacy.textContent='🏛 Spend Legacy Points';splashLegacy.className='pc-splash-legacy';$('continueBtn').after(splashLegacy);splashLegacy.onclick=openLegacyDialog;
 const devPanel=document.createElement('div');devPanel.className='dev-panel';devPanel.innerHTML='<h3>Developer test mode</h3><p class="muted">Isolated test run. Your real save and Legacy remain unchanged.</p><button id="devStart">Start test run</button><button id="devFloor" disabled>Next test floor</button><button id="devSupplies" disabled>Test supplies</button><button id="devLevel" disabled>Reach class level (5)</button><button id="devMimic" disabled>Test mimic chest</button><button id="devExit" disabled>Return to saved game</button><label>Monster density <output id="devDensityValue">100%</output><input id="devDensity" type="range" min="50" max="250" step="10" value="100" disabled></label><button id="devRegenerate" disabled>Regenerate current test floor</button><p id="devStatus" role="status"></p>';
 panels.menu[0].appendChild(devPanel);
 const devBtns=['devFloor','devSupplies','devLevel','devMimic','devExit','devDensity','devRegenerate'].map(id=>$(id));
 const updateDev=()=>{const active=!!globalThis.PocketCrawDev?.active;$('devStart').disabled=active;devBtns.forEach(b=>b.disabled=!active);$('devStatus').textContent=active?'TEST MODE ACTIVE — saves disabled':''};
 $('devStart').onclick=()=>{if(globalThis.PocketCrawDev?.enter()){updateDev();show('explore')}};
 $('devDensity').oninput=()=>{$('devDensityValue').textContent=globalThis.PocketCrawDev.density(Number($('devDensity').value))+'%'};
 $('devRegenerate').onclick=()=>{globalThis.PocketCrawDev.regenerate();show('explore')};
 $('devFloor').onclick=()=>{const next=Number(($('floor').textContent.match(/Stage (\d+)/)||[])[1]||1)+1;globalThis.PocketCrawDev?.floor(next);show('explore')};
 $('devLevel').onclick=()=>{globalThis.PocketCrawDev?.level(5);show('explore')};
 $('devMimic').onclick=()=>{globalThis.PocketCrawDev?.mimic();show('explore')};
 $('devSupplies').onclick=()=>{globalThis.PocketCrawDev?.supplies();show('explore')};
 $('devExit').onclick=()=>{globalThis.PocketCrawDev?.exit();updateDev();show('explore')};updateDev();
 const help=document.createElement('p');help.className='muted';help.textContent='Tap the left or right side below the map to turn. Tap the center to walk forward; bottom center to step back. Bottom corners step sideways. Hiding icons keeps these tap areas active.';controlSetting.after(help);
 for(const id of ['up','down','left','right','sl','sr']){const b=$('view-'+id);b.querySelector('span')?.remove()}
 const note=document.createElement('p');note.textContent='Use App menu for game updates. Save files are separate.';panels.menu[0].appendChild(note);
 let resizeFrame=0;if(typeof ResizeObserver!=='undefined')new ResizeObserver(()=>{if(!resizeFrame)resizeFrame=requestAnimationFrame(()=>{resizeFrame=0;globalThis.PocketCrawResize?.()})}).observe(viewport);

 // Unified mobile action inspector: selection never commits a purchase or upgrade.
 const inspector=document.createElement('aside');inspector.className='mobile-inspector';inspector.hidden=true;
 inspector.innerHTML='<div class="inspector-copy"><strong id="inspectorTitle">Selection</strong><p id="inspectorDetail"></p></div><div class="inspector-controls"><button id="inspectorCancel" type="button">Cancel</button><button id="inspectorConfirm" type="button">Confirm</button></div>';
 game.appendChild(inspector);
 let pending=null,approved=false;
 const dismiss=()=>{pending=null;inspector.hidden=true;game.classList.remove('inspector-open')};
 $('inspectorCancel').onclick=dismiss;
 $('inspectorConfirm').onclick=()=>{if(!pending)return;const target=pending;dismiss();if(!target.isConnected||target.disabled)return;approved=true;try{target.click()}finally{approved=false}};
 function inspectAction(target){
   const name=target.textContent.trim().replace(/\s+/g,' '), card=target.closest('.gear-card,.merchant-section'),context=card?.textContent.replace(/\s+/g,' ').slice(0,430)||'';
   let detail=context&&context!==name?context:name;
   if(target.id==='learnPassive')detail=($('passiveDetail')?.textContent||name)+' Current skill points: '+($('passivePoints')?.textContent||'')+'.';
   else if(target.closest('#legacySkills'))detail=name+' This is a permanent Legacy enhancement. Confirm to spend Legacy Points.';
   else if(target.closest('#actions')&&game.dataset.mode==='legacy')detail=name+' Permanent unlock; check its price and your available Legacy Points before confirming.';
   else if(target.closest('#actions')&&game.dataset.mode==='class')detail=name+' Class selection grants the displayed stats and changes your progression path.';
   else if(target.closest('#actions')&&game.dataset.mode==='merchant')detail=name+' Review this merchant trade before spending or receiving gold. '+context;
   else if(target.closest('#actions')&&game.dataset.mode==='workbench')detail=name+' Crafting consumes the listed materials. '+context;
   $('inspectorTitle').textContent=name.split(' · ')[0].slice(0,100);
   $('inspectorDetail').textContent=detail;
   $('inspectorConfirm').textContent=/^(Sell|Salvage|Unequip|Equip|Craft|Buy|Upgrade|Learn|Rest)/i.test(name)?name.split(' · ')[0]:'Confirm selection';
   pending=target;inspector.hidden=false;game.classList.add('inspector-open');
 }
 const actionable=target=>target.matches('#learnPassive,#legacySkills button,#inventory button,#gearSlots button,#actions button');
 game.addEventListener('click',event=>{
   if(approved||event.target.closest('#pcMerchant')||game.dataset.mode==='merchant')return;
   const b=event.target.closest('button');if(!b||b.disabled||!actionable(b))return;
   const actionMode=game.dataset.mode;
   if(b.closest('#actions')&&!['legacy','class','merchant','workbench'].includes(actionMode))return;
   if(b.closest('#inventoryToolbar')||b.closest('#gearSlots,#inventory')&&/^(Equip|Unequip|Repair|Protect|Unprotect|Scavenge corpse|Dismantle treasure)/i.test(b.textContent))return;
   event.preventDefault();event.stopImmediatePropagation();inspectAction(b);
 },true);
 globalThis.PocketCrawResetView=()=>show('explore');const originalShow=show;
 for(const b of Object.values(buttons))b.addEventListener('click',dismiss);
 const observer=new MutationObserver(()=>{if(pending&&!pending.isConnected)dismiss()});observer.observe($('actions'),{childList:true});
 // The skill tree uses a single-column card layout on phones, avoiding horizontal panning.

 const diagButton=document.createElement('button');diagButton.textContent='Error Log / Diagnostics';diagButton.onclick=()=>globalThis.PocketCrawShowDiagnostics?.();panels.menu[0].appendChild(diagButton);
 show('explore');window.parent.postMessage({type:'pocket-craw-ready',version:globalThis.PocketCrawVersion},'*');
})();
