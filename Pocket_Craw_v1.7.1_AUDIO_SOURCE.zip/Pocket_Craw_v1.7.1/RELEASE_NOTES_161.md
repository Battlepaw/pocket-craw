# Pocket Craw v1.6.1 — inventory and crafting

JSON-only update. Launch https://flying-poplar-97ino7z-paw20.vercel.app and import Pocket_Craw_v1.6.1_UPDATE.json through the existing update menu. No live deployment. v1.6.0 is preserved independently.

## Changes
- Inventory opens on backpack gear. A category selector switches between backpack, equipped gear, corpses, treasures, supplies and all items. Search filters carried gear/cargo. Empty gear groups are omitted. Outer category accordions are removed.
- Individual equipment details remain open across ordinary actions in the current session; filter/search and scroll position are retained during redraws where content height allows. No promise to retain UI expansion across browser reload or save replacement.
- Single corpse scavenging and treasure dismantling execute directly without the mobile confirmation panel. Protection toggles also work directly. Individual gear salvage retains its existing confirmation.
- Scavenge all corpses, dismantle all treasures, and salvage all unprotected gear each show one review listing eligible items. Cancel does nothing; confirm processes the batch with one final refresh. Equipped/protected gear is excluded. Corpse processing still requires scavenging ability. Bulk scope includes all eligible carried items, independent of filters/search, and says so on screen.
- Crafting rolls d100 once when producing equipment. Rolls 76–100 add one rarity tier/modifier. Basic starts Common, Refined Magic, Masterwork Rare; maximum Epic. Modifiers are randomly selected without duplicates from the existing modifier pool. Fixed recipe costs and eligibility remain; lockpick crafting is unchanged. Roll and modifier names appear in the log and equipment details. Ordinary loot generation is unchanged.
- After defeating an exit guardian, Descend floor appears while standing on the exit. An unclaimed reward blocks descent and opens its choice window with a log warning. Choose a reward, then descend immediately—no step off/on required. Required class selection, if triggered by leveling, still occurs first.

## Comparison and design choices
Diablo IV documents Favorite items, and Guild Wars 2 documents bulk salvage and item management controls. The useful patterns here are explicit protection, bulk operations and category access. A drag-and-drop grid would add precision demands on a phone; this release instead keeps readable rows, comparisons and large action buttons. It is not a reproduction of either game's inventory.
References reviewed:
- https://news.blizzard.com/en-us/article/24092662/diablo-iv-patch-notes-1-0-1-2
- https://wiki.guildwars2.com/wiki/Inventory
- https://wiki.guildwars2.com/wiki/Salvage

## Verification
16 grouped checks passed in headless Chromium at a 390×780 touch viewport. Includes prior loot/progression/migration/trader/guardian checks plus actual UI single corpse processing, category persistence, bulk cancel/confirm, protection, preserved item details, crafting roll endpoints/unique modifiers, and reward-gated descent without movement. Browser errors: none. Actual import into an unchanged local v1.5.25 host preserved existing character/gold and Legacy ranks; installed version survived reload. JS syntax, JSON version and ZIP/source byte correspondence verified.
Physical Android playtesting remains pending. The earlier campaign results belong to v1.6.0; they were not rerun or claimed as v1.6.1 balance evidence. The crafting bonus probability is an initial tuning choice and needs human playtest feedback.

Run `node tests/release161.cjs` with Playwright and Chromium available. Set PC_CHROMIUM when needed. Import test uses PC_HOST_BASELINE for the original v1.5.25 host. Build JSON with `python3 build_update.py`.
