# v1.7.0

Pocket UI cleanup, portal arches, stage/level guardian locks, biome resources, persistent side areas, reliable merchants and voluntary food sinks. See RELEASE_NOTES_170.md for the complete post-v1.6.2 decision checklist.

# v1.6.2

Dedicated workshop, salvage material-flow fixes and recycling safeguard, visible committed dice results, fitted skill web, Universal Legacy starters and clean Legacy reset. See RELEASE_NOTES_162.md.

# v1.6.1

Inventory categories/search, bulk processing with protection, persistent item details, crafting d100 modifiers, and direct post-guardian descent. JSON-only update.

# v1.6.0

Exit guardians, merchant baskets/finite stock, food traders, cargo and treasures, encounter markers, level-based starter loot, connected passive web with migration/refunds, intents/Defend, elites/relics, protection and pinned recipes. JSON-only release. See RELEASE_NOTES_160.md.

# v1.5.27 — Combat, equipment and crafting playtest overhaul

## Changes
- Enemies scale with floor using curved HP/attack growth, plus physical armor and magic ward. Enemy quantity remains separate from individual strength.
- Percentage mitigation replaces flat damage subtraction. Gear/passive attack and spell bonus pools have diminishing returns; critical chance caps at 40%, evade at 30%, resistance at 60%.
- Mage/Alchemist skills use arcane power instead of multiplying the entire physical ATK stack. Class skill Legacy ranks are preserved, with a smaller bonus. Power Strike costs at least 3 MP; class skills at least 4 MP. Overchannel trades 3 extra MP for an additive 25% bonus.
- Well-fed movement above 50% hunger regenerates 1 HP and 1 MP, even with no spare ration. Turns and UI actions do not regenerate. All camping tiers now restore MP, including the basic bedroll. Auto-eat below 10% remains enabled by default and independent of manual top-ups.
- Class-labelled weapons, armor and accessories. Specializations inherit their root class restrictions. Camping equipment and unidentified old starter equipment are Universal. Unclassed heroes can use class equipment until their first class selection.
- Warrior greatswords/warhammers, Mage staffs, Rogue chain whips/kusarigama, Knight halberds, Ranger longbows and Alchemist sprayers occupy both hands. Only Rogues may equip a second dagger/dirk. Conflicting equipment returns to inventory.
- One-time first-class weapon/armor kit prevents a class choice from leaving a new hero unequipped. Existing incompatible equipment moves to inventory without being deleted.
- Crafting offers matching class equipment and universal supplies at the current floor tier. Basic/Refined/Masterwork guarantee Common/Magic/Rare quality with fixed modifiers and item previews. Scrap converts into basic materials; dust refines into essence. Salvaging unwanted drops funds crafting and repairs.


# v1.5.26 — Auto-eat rations

- Default-on More → Settings toggle; remembers the choice in this browser.
- Eats one ration (+40 hunger) below 10% maximum hunger after movement/inspection costs, before starvation damage.
- Manual eating and existing regeneration rules unchanged. No save-schema changes.
- Import-only playtest update; hosted production remains v1.5.25.

# v1.5.25 — Stability and development controls (2026-10-25)

- Repair camp/corpse save loading; retain existing save schema and storage keys.
- Include modern Legacy ranks in exports/imports and host backups; preserve old-export compatibility.
- Keep developer progress isolated, block real save import/export/load in tests, reload real storage on exit.
- Fix death → main menu → new adventure.
- Replace overlapping Progress layouts with one scrollable skill canvas, visible Legacy/Classes controls and contextual lock reasons.
- Allow optional corpse dismissal by touch movement or turning.
- Round hunger to hundredths and trim display decimals.
- Show equipment upgrade scrap/gold costs and disable unaffordable upgrades.
- Raise normal base monster count from 6 to 8 plus biome extras on new floors.
- Add developer-only 50–250% monster density slider and current-floor regeneration.
- Reduce hidden panel rendering, coalesce resize callbacks, bound sprite cache memory and clear stale floor sprites.
- Consolidate host version/cache metadata; automatically use newer bundled distribution while retaining prior imported code for rollback.
- Self-contained distribution; remove dependency on remote source-download build scripts.

Validation: see TEST_RESULTS.json. Tests use headless Chromium with phone-sized/touch contexts, not physical Android hardware. Larger design/balance backlog remains pending.

---

## v1.5.23 — UI and Legacy playtest (import-only)
- Quick Use defaults to bottom-right navigation slot, retains configurable placement.
- Workbench starts with Craft / Leave; recipes are shown only after Craft.
- Legacy is visible in Progression and on the start screen. New repeatable, capped upgrades use escalating LP prices; previous unlocks remain intact.
- Scavenge equipment wording explains its enabling effect.
- Gameplay and mimic feeding remain unchanged. No Vercel deployment.

# Pocket Craw changelog

## v1.5.22 — UI replacement playtest
- Rebuilt inventory rendering as grouped, compact, expandable rows with direct Equip/Unequip and side-by-side stat deltas.
- Removed duplicate consumable buttons from action lists; Quick Use now calls game actions directly, including combat potion.
- Default Quick Use to upper right, offset from existing minimap. Settings retain selectable corners.
- Reworked skills screen to use full available canvas; node details on selection, floating help, class drawer.
- Replaced first-line journal polling with queued per-event ticker updates and removed redundant visible action feed and Log navigation.
- No changes to save schema, Legacy keys, or mimic mechanics.
- Unverified: actual Android touch layout and all interaction flows.

# v1.5.20 — UI correction playtest (import-only)
- Restored spatial connected passive tree with circular symbolic nodes, scrollable on mobile.
- Converted class progression to compact branching paths.
- Condensed inventory/equipment card layout and controls; full categorized comparison redesign remains pending.
- Added a quick-use button within the existing actions panel (not over movement/minimap).
- Three death options: spend Legacy after starting new hero, restart without spending, main menu.
- Supply miscellaneous reward is scrap, not substituted gold.
- No save-key or Legacy-schema changes. No Vercel deployment. Android touch testing pending.

# v1.5.19 — Import-only playtest update

- Discarded supplies: 45% one food ration, 25% empty/spoiled, 20% weak vermin, 10% small gold reward. One interaction per pile.
- Treasure chest food reduced to 1–5 rations instead of large stacks.
- Healing potion quantities shown on existing combat and exploration actions.
- Compact expandable Quick use selector added inside the existing exploration actions panel; no floating controls over minimap, movement or playfield.
- Existing save keys, Legacy and movement layout unchanged.
- Vercel production deployment unchanged; mobile playtest pending.

## 1.5.16 — Gold HUD hotfix
- Fix compact gold display to parse the actual coin-icon-prefixed value (🪙 123) emitted by the game, rather than requiring a nonexistent Gold label.
- Keep the working ticker, food/hunger, map, and game logic unchanged.
- Importer playtest package only; published Vercel host unchanged.

## 1.5.14 — 2026-10-24
- Restore gold to compact mobile survival HUD; read it from the existing money status rather than changing game economy.
- Align host version and App button to the right in full host source. Note: imported JSON updates only the game frame, not the deployed host.
- Preserve working in-game ticker, 3D view, minimap, food, saves, and Legacy.

# Pocket Craw Changelog

## 1.5.13 — 2026-10-24
- Replace fragile outer-host DOM ticker with a self-contained in-game ticker that the JSON importer can update.
- Tap ticker to open color-coded Event Log and persistent display settings.
- Choose ticker position: top of game or above bottom menu.
- Keep existing bottom Log button until on-device verification.
- Preserve approved map, controls, food HUD, saves and Legacy. No save schema changes.


## 1.5.12 — 2026-10-24
- Fix stalled ticker queue so messages advance.
- Show visible ticker-ready text and replace it on first event.
- Add journal polling fallback when a mutation is missed.
- Retain bottom Log button until phone verification; preserve saves, Legacy, map and gameplay.


## 1.5.11 — 2026-10-24
- Playtest hotfix: visible outer-app header ticker between sword icon and version; tap opens full color-coded Event Log.
- Event Log includes persistent ticker text size, scrolling, duration, timestamps and danger highlight settings.
- Preserve hidden hazard information: only color messages already emitted by the game.
- No changes to gameplay, save schema, Legacy, 3D viewport or minimap.
- Imported JSON updates use same-origin host-header integration without requiring a production host redeployment.

## 1.5.10 — 2026-10-24
- Hotfix: compact mobile Food/Hunger display parses ration and hunger values independently, even when chest keys appear between them.
- No changes to food mechanics, save schema, Legacy progression, minimap, or action ticker.

## 1.5.9 — 2026-10-24
- Visible compact action ticker in header, tap for full journal; map/playfield dimensions unchanged.
- Inspection costs 2 hunger and provides class-sensitive chest trap/mimic clues.
- Chest hazards pre-rolled on encounter; spell unlock requires magical class; scavenge requires relevant skill/class/equipment.
- Rare universal chest keys; feed a detected mimic one ration for pacification or berserk combat.
- Mimic pets and inventory weight/limits remain proposals, not shipped.
- Existing save schema, storage keys, Legacy and importer preserved.

## 1.5.8 — 2026-10-24
- Enlarged minimap, player-centered zoom (7/9/11/15/19 tiles), left-side zoom buttons and separated right-side expand control.
- Rebalanced the portrait layout for a larger map while keeping the tappable 3D playfield prominent.
- Removed overlapping in-game version badge; host displays a small centered version label above survival stats.
- Added isolated developer test mode: test floors and supplies without overwriting normal run/Legacy saves.
- Preserved existing game save export/import and existing storage keys.
- Host defaults to newer bundled game if an older imported update is still stored; previous imported update remains available for rollback.
- Consolidated a complete self-contained source package.

## 1.5.7 — Previous release
- Compact mobile UI and existing save/Legacy systems.

## 1.5.16 — playtest candidate
- Persistent merchants until explicitly dismissed; keep inventory on revisit.
- Generated sheltered camp tiles, visible map marker, inspection clue, reduced but nonzero ambush risk and explicit preview.
- Restrict ring channel to explicitly channel-capable rings; passive bonuses remain equipped.
- Distant sprite wall line-of-sight check and revised floor alignment.
- Existing floor-scaled enemy stats preserved for camp ambushes.
- Not deployed; Android gameplay verification pending.

## v1.5.17 — Save recovery diagnostics (import playtest)
- Display actionable errors for Continue Save, import and autosave; add Error Log and copyable diagnostics.
- Repair selected missing legacy save fields using explicit migration; retain raw original before saving converted format.
- Prevent Continue navigation when a load has not succeeded.
- No save storage key changes; unsupported/corrupt data remains protected and reported.
\n## v1.5.21 — imported UI correction candidate\n- Repair ordinary unequip eligibility outside combat and add unequip feedback.\n- Compact equipment rows; floating potion quick-use with position selection in More.\n- Move class advancement to Progress; rename Hero to Status.\n- Collapse skill help and enlarge tree viewport.\n- Preserve save keys, movement buttons, minimap, and existing skill nodes.\n- Browser/mobile interaction verification remains pending.\n
## v1.5.24 — playtest importer candidate (2026-10-25)
- Restored skill tree container visibility in the mobile Progression screen; guard invalid selected nodes.
- Removed newly generated workbenches; existing saved workbench events migrate to supply caches. Camp now offers Rest, Craft, and Continue; recipes are hidden until Craft.
- Added consumable Basic/Fine/Magic lockpicks with displayed quantity and calculated chance on locked chests, common Basic drops, merchant stock, and a Basic crafting recipe.
- Legacy Expedition Supplies now gives 10/15/20/25/30 extra starting rations by rank, including previously purchased ranks. Added one-time basic starter armor, boots, and shield Legacy unlocks. Retains existing Legacy rank storage key.
- Defeated enemy remains no longer block movement; no-scavenge characters automatically return to exploration.
- Candidate only: automated browser test was blocked by environment; Android rendering and live import require user playtest. Existing production Vercel deployment unchanged.

## v1.7.1 — Audio integration import playtest
- Based on the complete v1.7.0 source, not v1.5.25; v1.7.0 source archived independently.
- Added additive Web Audio engine, eight biome musical palettes and menu theme, procedural musical variation, environment textures, subdued movement steps, and context-sensitive action/monster effects.
- Embedded the approved small retro apple-bite sample; all other effects are procedural.
- Added one-tap mute and audio preferences under the existing mobile menu; separate storage key pocketCrawAudioV1.
- Kept existing save schema, Legacy keys, portal arches, combat, minimap, and touch movement intact.
- Import-only preview; no Vercel deployment. Automated Playwright suite blocked by missing dependency; Android validation pending.
