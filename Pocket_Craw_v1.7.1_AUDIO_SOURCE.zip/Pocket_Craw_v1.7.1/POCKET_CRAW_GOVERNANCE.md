# Pocket Craw — Project Governance

Current source baseline: v1.5.27, 2026-10-25. This document supersedes the historical v1.5.24 handoff; previous releases remain backups.

## Authority and workflow
Read this document before development, testing changes, or deployment. Newer explicit user decisions supersede this document. Inspect current source and live Vercel state before changes. Keep a complete current source archive, import JSON, changelog and verified previous backup. The hosted base and browser-imported playtest may differ; report both honestly.

The user prefers inexpensive, quick playtesting via the permanent site: edit actual source → build import JSON → test → archive full source → deliver JSON and stable play link. Importing changes the user's browser installation only. A hosted distribution update is a separate authorized action. Never require a new login loop for routine import updates. Use the connected Vercel integration; if access fails, stop and explain rather than repeatedly retrying authentication.

## Permanent infrastructure
- Project: flying-poplar-97ino7z
- Project ID: prj_e5p9GquKapJ5QNtAiGT6xQxMqDBh
- Team ID: team_dhqj3hl7WW6QUP6IvOEMSIGT
- Permanent URL: https://flying-poplar-97ino7z-paw20.vercel.app
- Prior verified production: dpl_AxkssUJZUzoYgUXwU28d4YbghFDk (compact v1.5.7).
- v1.5.25 production: dpl_2Nn7Ab2Yu3JX8awFM4T2jZHebMaD, READY and live-verified 2026-10-25. See RELEASE_STATUS.md for checks and access limitations.
- Release is self-contained static HTML/CSS/JavaScript/assets. No remote source downloads in a build script. Use existing project, production target, framework null, empty build/install commands and no output/root subdirectory. Never create a replacement site for routine updates.

## Product and mobile constraints
Mobile-first browser roguelike with 3D tap navigation, procedural characters/classes, equipment/crafting, traps, merchants, hunger, saves and Legacy. Android is the primary physical playtest device.
- Preserve 3D aspect ratio and direct tap-to-move/turn hit regions; no permanent movement-button cluster.
- Preserve approved minimap layout, fog of war, zoom persistence, adjacent minus/plus on left and expand on right. Keep map useful, HUD readable, and viewport dominant.
- HP, MP, Food/Hunger, gold and floor remain visible; format fractional hunger to at most two decimal places. Version must not overlap HUD.
- Quick Use defaults to bottom-right navigation slot; preserve user's configured placement. Avoid duplicate consumable controls.
- Progress contains connected skill tree with one scroll area, contextual skill details/help, Classes/milestones and Legacy access. Inventory stays categorized/compact with equip/unequip and comparisons.
- Working event ticker opens Event Log; redundant bottom Log tab stays removed.
- Camp offers Craft before recipes; generated workbenches are removed, legacy tiles migrate to supplies.
- Post-combat scavenging is optional; movement/turning can dismiss it.
- Supply outcomes remain 45% food, 25% empty/spoiled, 20% weak vermin, 10% gold.
- Lockpicks are consumed per attempt; Basic crafting stays predictable. Existing mimic behavior remains; no pet feature claimed.

## Saves and Legacy
Keep same origin and keys: pocketCrawSaveV1, labyrinthLegacyV1, pocketCrawLegacyRanksV1 and host installation state pocketCrawHostV1. Do not reset real progression during routine updates. Classic unlocks and modern capped ranks remain valid.
Save schema stays version 1 with additive gameVersion, testRun and legacy.modernRanks fields. Modern exports carry all progression. Old exports lacking modernRanks retain the destination's existing ranks for compatibility; do not claim old files contain purchases they never stored. Continue uses the local Legacy ledger to avoid undoing start-screen purchases. Import uses the imported progression after confirmation.
Support camp/corpse and all existing encounter-state saves. Preserve pre-migration originals when migration occurs. Host backups now include modern ranks; old host backups cannot recreate data they never included.
Developer mode cannot save/export/import/load real progress. Exit reloads untouched normal storage. Density settings are test-run-only. No real user data is erased by these repairs.
Preserve death screen's three choices: spend Legacy/start, new adventure/keep Legacy, main menu. Full erase-all-progress remains pending, not implemented.

## v1.5.25 scope
- Hunger precision/clamping and display overflow fix.
- Save-state validation, modern Legacy export/restore, developer isolation and death-menu restart repairs.
- Progress layout consolidation and visible skill eligibility reasons.
- Touch movement/turn dismissal of optional scavenging.
- Equipment Upgrade costs and affordability shown.
- Base enemy entries increase from six to eight plus biome extras, only on newly generated floors. Existing saved floors unchanged.
- More → Developer test mode: density slider 50–250%, regenerate current test floor. 100% means new normal default.
- Render heavy panels only when their screen is active; coalesce resize work; cap sprite cache and clear it between floors/restores to prevent stale enemy images.
- Current bundled host/version metadata, older-import upgrade with retained rollback, refreshed offline cache, identical direct/game markup.

## Verification and release gate
Run JavaScript syntax checks, rebuild JSON from source, verify ZIP integrity and exact package/source correspondence. Run tests/stability.cjs (Playwright; optional PC_CHROMIUM executable path). Record actual tests in TEST_RESULTS.json. Physical Android validation is distinct from headless mobile viewport/touch emulation; never claim the former from the latter.
Before publishing, create and verify a full versioned source ZIP and preserve prior release. Deploy the same runtime files to the existing project. Verify READY, permanent URL, live served bytes/version and browser functionality. Include playable link, source ZIP and import JSON in handoff. Mark any remaining test limitations explicitly.

## Source continuity
Versioned ZIP is the authoritative complete source; individual files alone omit host/mobile/build/test components. Keep prior v1.5.24 archive independently accessible before replacing the current-source copy. Library persistence and ChatGPT Project-source replacement are separate; only claim Project-source replacement if independently confirmed. If unavailable, provide revised governance/source archive for manual replacement. Never delete the prior Project source before confirming replacement and backup.

## Remaining backlog
The user's consolidated checklist remains the design backlog. This stability release does not claim completion of class combat redesign, elemental resistance/armor-break/intent systems, procedural bosses on every floor, five-tier crafting overhaul, six Legacy paths, reset-all-progress UI, full monster framing/occlusion audit, or economic balancing. Track these separately from repaired stability issues. Preserve historical approved choices unless explicitly superseded.

## v1.5.26 playtest decision
Default-on Auto-eat rations under More → Settings consumes one ration (+40 hunger) after an action lowers hunger below 10% of hunger capacity, before starvation damage. Manual eating remains available. Preference key pocketCrawAutoEatV1 is browser-local; developer mode does not persist changes. No hunger overhaul. Import-only update; hosted production remains v1.5.25. Every update handoff must include the clickable permanent play link, import JSON, and full source ZIP.

## v1.5.27 approved scope and delivery
User requests a coordinated scaling, class-equipment and crafting overhaul with repeated automated playtests, well-fed/camping MP recovery, two-handed weapons and Rogue-only dagger dual wielding. Runtime rules and measured limitations are in BALANCE_NOTES.md. New enemy stat curves apply to new profiles; existing floor profiles retained. Wrong-class gear is moved to inventory, not discarded. No live deployment: use the JSON import loop. Preserve v1.5.26 as an independent backup. Every delivery includes JSON, complete ZIP and permanent clickable launch link. Hosted production remains v1.5.25. Class weapons, armor and accessories carry root-class labels; camping and unidentified legacy starter gear remain Universal.

## v1.6.0 authoritative overrides (2026-10-25)
User approved recommendations and required exit guardians, complete merchant purchase/sale baskets, finite stock, encounter minimap icons and inventory corpses/treasures. Implemented scope and limits are in RELEASE_NOTES_160.md. Enemy movement and inventory weight are deferred. Corpse pickup now replaces post-combat scavenging mode; old corpse saves migrate to cargo.
Routine updates MUST remain JSON imports: edit source, validate, package full source ZIP and JSON, then supply permanent clickable launch link. Do not follow the older deployment paragraph for these import-only updates. No Vercel deployment or authentication loop is authorized or needed for this release.
Passive progression now uses a connected 104-node web. Preserve migrationVersion/progressionVersion markers and exactly-once refunds, classic unlocks and modern ranks. Do not reintroduce learned-skill Legacy upgrades. Future revisions must preserve stock, cargo, pending rewards, relics and exit-guardian HP in saves.
Current test entrypoint is tests/release160.cjs, plus campaign160.cjs and import-existing-host.cjs. Historical reports under history are not current verification. Headless emulation is not physical Android testing. Do not promise target difficulty from automated completion rates alone.
Source archive v1.5.27 remains an independent backup. This delivery does not replace ChatGPT Project source attachments automatically; user may replace them with the new full archive and governance file.

## v1.6.1 approved fixes
Inventory outer categories are flat/filterable; avoid rebuilding closed accordions after every action. Preserve active details/filter/search during routine updates. Bulk processing must never touch equipped/protected gear, must recheck eligibility, and must use one review per batch. Single cargo processing does not need repeated confirmation. Bulk scope is all eligible carried items, not only visible search results, and must be stated.
Crafted equipment now uses one d100 roll with 25% bonus rarity/modifier and random affixes; this supersedes the older fixed-bonus crafting instruction. Keep costs predictable, show the result, and avoid free rerolls.
At a cleared exit, offer descent immediately; unclaimed rewards must be surfaced and claimed first. No forced tile re-entry. Current regression entrypoint: tests/release161.cjs. Preserve prior archive and JSON-only delivery with permanent launch link.

## v1.6.2 approved scope
Dedicated workshop dialog, clear material costs/conversion, persistent last result, animated committed craft/wager rolls, initial fitted/centered skill web, Universal Legacy starter gear and confirmed clean Legacy/current-run reset are implemented. Reset must preserve settings and installed update and be disabled in developer mode; old exports remain independently restorable.
Weapon salvage returns metal/wood; metal-primary natural salvage minimum is 2. Crafted salvage returns half paid costs rounded down, zero scrap and zero random bonus materials. Prevent resource-positive craft/salvage loops. Always preview guaranteed yields separately from possible random bonuses.
Current regression suite is tests/release162.cjs. Final campaign and salvage audit are CAMPAIGNS_162.json and SALVAGE_AUDIT_162.json. Further passive expansion deferred. JSON-only workflow and permanent launch link remain mandatory.

## v1.7.0 authoritative conversation decisions
The game is relaxed hack-and-slash downtime play. Do not introduce puzzles, timed switches or mandatory environmental chores. Portal ARCH replaces stairs and the superseded crystal concept. Stages keep the internal floor key for compatibility.
Phone content area is a release gate: compact headings, essential costs visible, help behind tap controls, one main scroller, full-width phone dialogs. Merchant/workshop lists must retain substantial usable area on small and shortened screens; working click tests alone are insufficient.
New main-stage guardians use max(stage, hero level), locked at generation. Power score is observation only until calibrated. Preserve guardian health across retreat and side travel. Old stages must not regenerate on import.
Biome resource tables, themed caches, creature-appropriate remains, reliable near-exit general merchants and every-third-stage food specialists are active. Food sinks are reserve-aware sale, one order per trader and camp meals. No thief or moving-enemy implementation authorized by this release.
Returning side areas retain parent discovery, encounters, traders and guardians; revisits cannot reroll rewards or heal the hero. Side exits remain retreatable. Main stage guardians remain mandatory.
Further outdoor environments, branching destination choices, active terrain systems, skill-web expansion and weight remain backlog. Current tests are release170.cjs, campaign170.cjs and import-existing-host.cjs. Preserve v1.6.2 independently and deliver JSON + complete source ZIP + permanent launch link, never direct deploy for routine updates. Full conversation decision matrix is RELEASE_NOTES_170.md.

## v1.7.1 audio import playtest (2026-10-25)
The authoritative source for audio integration is v1.7.0 SOURCE.zip, not any v1.5.x hosted shell. The permanent Vercel project is retained as the import launcher; no deployment or URL change for this test. Audio controls must remain thumb-friendly, separate from save/Legacy state, with one-tap mute and distinct music/effects/ambient/footsteps/UI levels. Procedural sound palettes must follow the eight actual biomes and event outcomes; footsteps subdued. Embedded small CC0-style apple sample is permitted. Keep all v1.7.0 systems and mobile controls. The v1.7.1 import is experimental until automated and physical mobile tests pass.
