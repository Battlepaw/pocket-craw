# Pocket Craw v1.7.1 — Audio import playtest

Use the existing permanent launcher: https://flying-poplar-97ino7z-paw20.vercel.app

App → Import update → select Pocket_Craw_v1.7.1_AUDIO_IMPORT.json. This changes the browser-installed game only, not the hosted Vercel shell. Do not reset browser storage or clear saves.

The source archive includes all files, tests and previous release history. See RELEASE_NOTES_171.md for limits.
