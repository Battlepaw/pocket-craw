# Pocket Craw v1.7.1 — Audio Integration Playtest

Base: verified v1.7.0 SOURCE ZIP and UPDATE JSON. This is a browser-import test, not a production deployment.

New: audio.js procedural soundtrack/effects engine, eight biome palettes, menu theme, terrain steps, lightweight ambient accents, apple bite OGG embedded in source, event-driven action sounds, mute button and audio controls. Audio preferences are saved separately in pocketCrawAudioV1.

Known limitations: The v0.6 soundboard is a design prototype, not an identical implementation; the in-game arrangements are first-pass approximations. The 1.7.0 automated Playwright suite could not execute because playwright is not installed. Android listening and click validation required before publishing. The first-pass action classifier may not cover every event. No deployment made.
