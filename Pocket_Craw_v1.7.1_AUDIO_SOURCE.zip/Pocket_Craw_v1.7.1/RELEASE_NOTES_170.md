# Pocket Craw v1.7.0 — pocket interface and portal stages

JSON-only update from v1.6.2. Launch https://flying-poplar-97ino7z-paw20.vercel.app and use the update menu to import Pocket_Craw_v1.7.0_UPDATE.json. No live deployment or real-user progression reset was performed. Prior archives are preserved.

## Conversation decisions since v1.6.2
| Topic | Decision carried into this update |
|---|---|
| Intended experience | Relaxed hack-and-slash, simple choices, no puzzles, switch sequences, timers or environmental chores. |
| Phone interface | Prioritize usable list area across merchant, crafting and inventory. Compact controls and tap help; retain essential prices/costs/protection. |
| Travel correction | Portal ARCH, superseding both stairs and the earlier crystal idea. Guardian activates it; claim reward then Travel onward. |
| Guardian scaling | Higher of stage or character level, frozen when a new stage generates. Record a modest power estimate for observation only; do not use it to dynamically raise stats. |
| Resources and encounters | Eight existing biomes have material specialties, themed resource caches/treasures and appropriately edible or nonedible enemy remains. |
| Floor variety | Rotate the existing rooms/loops/caves layouts across stages; add compact returning side areas. No new open-world/outdoor renderer claimed. |
| Merchants | Reliable general trader near the exit approach; food specialist every third newly generated stage. |
| Food surplus | Reserve-aware bulk selling, one food order per trader and optional camp meal. No theft mechanic. |
| Parked ideas | Enemy movement, thieves, outdoor environments, two-destination portal choices, further skill expansion, complex terrain and inventory weight remain deferred. Feeding creatures is also deferred; food orders are the initial sink. |

## Included behavior
Merchant: full-width phone dialog with compact Buy/Sell/Food orders tabs and checkout bar. Item descriptions use Details help. Clear resets both basket and displayed quantities. Sell surplus adds rations above a chosen reserve to the basket; payment is still explicit. Each trader can buy one 10-ration order for 40g. Existing stock and protected gear rules remain.
Workshop: full-width phone dialog with Recipes, Materials and Last craft tabs. Recipe list occupies the main area; select one for quality, costs and Craft. Conversions are on Materials. Craft results and animations are retained. Fixed missing lockpick result text.
Inventory: compact Auto-equip control, category/search, one Salvage menu and help. Individual gear details and existing protection remain. Bulk confirmations still show actual scope. No repeated explanatory wall above the list.
Portal: stone arch art with a dormant/active appearance, portal map marker, fixed next-biome preview, Travel onward and stage numbering. Existing internal floor/save keys stay compatible. Main-stage guardian remains mandatory; unclaimed rewards block travel.
Guardians: generated at stage entry using max(stage, character level), then existing guardian HP/attack multipliers. Equipment, later level-ups and retreat do not reroll it. Power estimate records attack/defense/max HP/max MP/allocated-node count and does not influence difficulty yet. It is not a calibrated build-strength model. Guardian remaining HP continues to persist.
Resources: two ordinary encounter slots become resource caches, replacing a chest/altar rather than endlessly adding stops. Collect is one action. Each biome favors particular materials, with most treasure rolls themed and a minority offering shared essentials. Existing ordinary gear/material routes remain available. Construct and spirit kills yield component/essence cargo instead of edible corpses; skeleton remains yield bone without food. These enemy types also stop dropping generic food rations.
Side areas: on every third new main stage, a discovery entrance can lead to a compact biome-named pocket with an enemy, an optional elite, a resource cache and a chest. All currently share a small base layout with biome visuals/enemies/resources. Return arch is immediately available; the elite guards optional rewards, not retreat. Return restores the parent stage, discovery state, trader stock and guardian HP. Re-entry retains consumed encounters. No stage advancement or free healing occurs on return. Main-stage level scaling stays unchanged by visiting a side area.
Food: a camp meal costs 3 rations and restores up to 30% max HP/MP plus 40 hunger, with no stacking combat buff. Cannot be bought at full HP/MP. Normal rest remains. General traders buy food; specialists buy food and edible corpses, offering rations in exchange for the latter.

## Biome specialties
| Biome | Resource cache | Guaranteed cache materials | Side area |
|---|---|---|---|
| Forgotten Keep | Armory locker | 4 metal, 2 leather | Abandoned Armory |
| Sunken Sewers | Scavenger stash | 3 cloth, 2 metal; 2 rations | Smuggler Cistern |
| Hollow Crypt | Burial offerings | 4 bone, 2 dust | Sealed Ossuary |
| Deepstone Caverns | Mineral seam | 3 metal, 2 gems | Crystal Grotto |
| Overgrown Ruins | Overgrown supplies | 4 wood, 2 cloth; 2 rations | Overgrown Storehouse |
| Frozen Catacombs | Lost expedition cache | 3 cloth, 2 gems; 2 rations | Frozen Shelter |
| Volcanic Forge | Machinery cache | 4 metal, 2 mechanical parts | Abandoned Foundry |
| Abyssal Sanctum | Occult remnants | 3 dust, 1 essence | Sealed Sanctuary |

## Save compatibility and limits
Existing saved floors are not regenerated. New guaranteed traders, resource placements, side entrances and entry-frozen guardians apply to newly generated stages. An existing guardian retains recorded stats/health. If an old stage has no guardian yet, it is created at first challenge because its original entry state cannot be reconstructed. An old stage may show Uncharted region until onward travel generates its destination. Portal visuals/UI apply immediately. UI preferences/settings and Legacy are not reset.
No moving enemies, theft, puzzles, real-time hazards, new outdoor biomes or destination-selection tree were added. Basic side-area geometry is intentionally shared; the material tables and existing biome enemies provide the initial variation. The food economy and guardian scaling remain playtest tuning, not a claim of final balance.

## Verification
21 grouped mobile browser regression checks passed. Includes existing loot/progression/migration/trade/guardian checks and new stage-entry locks, reliable traders, food order persistence, camp meals, all eight resource tables, nonedible remains, side-area save/return/re-entry, compact inventory salvage, reserve selling, recipe tabs/crafting and portal reward gating.
Measured list area at 390×780: merchant about 79%, recipe list about 86%. Also checked 320×568, 430×932 and a shortened 390×400 viewport. All tested merchant/recipe lists exceed 60% of their dialog height; phone dialogs fill viewport width. The shortened viewport approximates reduced space, not a physical Android keyboard test. Screenshots visually inspected; no browser JS errors. Physical Android testing remains pending.
Existing-host JSON import passed in an unchanged local v1.5.25 host, retaining character/gold/modern Legacy and surviving reload. JS syntax and exact ZIP/source correspondence verified.
36 final automated full-exploration campaigns used six classes, three seeds and no/high modern-Legacy profiles. Bots use preset builds, full-map BFS, crafting, consumables, food orders and camp meals/rest; side-area persistence is tested separately. No-Legacy: median ending stage 12.0, 1 stage-16 clears in 18 runs. High-Legacy: median stage 11.0, 2 stage-16 clears in 18 runs. Overall 33 deaths, three clears, no action-limit stops or JS exceptions. The changed generation and loot mix prevent treating these runs as a controlled difficulty comparison with v1.6.2. Human feedback should focus on guardian difficulty and retreat recovery. These are not human win-rate predictions.

## Reproduction
Build: python3 build_update.py. Regression: node tests/release170.cjs. Campaigns: node tests/campaign170.cjs. Import: node tests/import-existing-host.cjs with PC_HOST_BASELINE set to unchanged v1.5.25 host source. Playwright/Chromium required; PC_CHROMIUM may select the browser. Current evidence: TEST_RESULTS.json, VIEWPORT_RESULTS_170.json, CAMPAIGNS_170.json. Older tests/reports are historical.
