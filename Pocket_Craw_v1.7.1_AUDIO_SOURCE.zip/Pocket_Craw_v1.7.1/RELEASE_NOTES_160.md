# Pocket Craw v1.6.0 — import release

Install the JSON through the existing site's update menu. This is an import-only release. No production deployment was performed. The permanent host remains v1.5.25; the installed browser game becomes v1.6.0.

Launch: https://flying-poplar-97ino7z-paw20.vercel.app

## Included
- A required exit guardian on every floor. Retreat and save/continue preserve its remaining health. Defeating it unlocks the exit and offers one reward choice.
- Shared encounter marker registry and expanded minimap legend, including shrines, wagers, elites and traders. Fog of war and concealed traps remain intact.
- Full merchant dialog with buy/sell tabs, quantities, +1/+5 controls, a mixed basket and one payment. Stock persists per trader, including finite lockpicks. Affordability and stock are rechecked before applying the transaction.
- Rare food traders sell/buy rations and exchange edible corpses for food. General traders buy supplies, equipment and cargo. Protected equipment cannot be sold or salvaged.
- Corpses automatically enter Items; scavenge later when eligible or trade them. Three treasure categories can be sold or dismantled into materials. No weight system yet.
- Level 1–4 drops are Common, classless starter items. Later gear tier follows hero level, with a class-compatible bias and a guaranteed compatible roll after three incompatible rolls. Off-class salvage remains possible; advanced subclass names are excluded from the normal base pool.
- A connected 104-node passive web with eight themed branches, route nodes, notables, mutually exclusive masteries and keystones. Two points per level plus milestone bonuses, capped at 70. Search, zoom, route preview and respec included. This is an original web inspired by the requested structure, not a copy of Path of Exile.
- Old passive allocations reset once; their numerical bonuses are removed and the new point budget is restored. Retired Legacy learned-skill enhancement spending is refunded once. Classic unlocks and modern capped Legacy ranks remain. Class selection provides a free respec; subsequent paid resets occur at camp.
- Enemy intent, Defend, optional elite encounters, run relics and reward choices; recent combat-hit details on death. Recipe pinning and equipment protection.
- Previous v1.5.26/27 changes retained: default-on auto-eat below 10%, manual eating, well-fed/camp MP recovery, class equipment rules, two-handed weapons, Rogue dagger dual wield, resistance/scaling and crafting improvements.

## Verification
13 grouped browser regression checks passed, including 2,500 loot rolls, migration/refund idempotence, boss retreat/save/reward/descent, cargo, merchant atomicity and stock persistence, specialty traders, elite rewards, HP/MP recovery and actual mobile merchant/passive controls.
The update installed into an unchanged local copy of the v1.5.25 host. Existing character/gold and modern Legacy ranks remained; the installed version survived reload. This was an isolated browser test, not a change to the live server or user saves.
72 longer automated campaigns used six classes, two Legacy profiles and three seeds each. Full-exploration policy: 35 deaths and one floor-16 clear, median ending floor 13. Exit-rush policy: 36 deaths, median ending floor 10. No action-limit stops or browser exceptions. An earlier 36-run floor-8 smoke test cleared all runs.
These bots know the full maze, choose preset builds, manage consumables/crafting and may retreat from guardians. They do not represent human win rates or prove final balance. Mage median ending floor was 13 in exploration and 9.5 when rushing; no claim that all classes are equally balanced. Physical Android testing remains pending.

## Known scope limits
The encounter changes rebuild markers, exit gating, elite rewards, persistent merchant state and cargo flow; existing shrine/wager outcome tables remain. Corpse yields are deliberately simple. Burning cannot deliver the final point of damage without a follow-up attack. Death history currently records enemy hits, not every environmental damage source. Relic effects are intentionally modest. Food abundance and the broader hunger economy still need the planned overhaul. Existing enemy profiles in old saves retain their recorded stats.

## Deferred design
Enemy movement: advance one enemy tick per meaningful player action; keep idle/wait safe and explicit; start with stationary guardians, short patrol routes and limited pursuit; show intent/last-seen markers; resolve movement deterministically; prevent multiple enemies entering one tile or trapping the arrival tile; persist positions and test retreat routes. Introduce this separately from combat/economy changes.
Inventory weight: first add stackable cargo and clear bulk sale/scavenge actions, then measure inventory volume. Later add visible carrying capacity and predictable penalties, avoiding mid-run surprise overload after migration.
Next balance pass: collect human deaths by floor/class/level, turns per fight, resource surplus and unused crafting materials. Tune first-floor guardian warnings, Alchemist survivability, food abundance and merchant demand from that evidence.

## Reproduce
Use Node with Playwright and a Chromium executable (PC_CHROMIUM if not using Playwright's installed browser). Run `node tests/release160.cjs`, then `node tests/campaign160.cjs`; repeat the latter with PC_RUSH=1. The import test uses PC_HOST_BASELINE pointing to an unchanged v1.5.25 host directory. Build with `python3 build_update.py`. Older tests/reports are historical and may assume the retired passive tree.
