/* Packages and recovery journal are atomic; character saves stay in their original keys. */
(()=>{'use strict';const NAME='pocketCrawUpdatesV2';let db;
function open(){return new Promise((resolve,reject)=>{const q=indexedDB.open(NAME,1);q.onupgradeneeded=()=>q.result.createObjectStore('host');q.onsuccess=()=>{db=q.result;db.onversionchange=()=>db.close();resolve()};q.onerror=()=>reject(q.error);q.onblocked=()=>reject(Error('Close other Pocket Craw tabs, then reopen this one.'))})}
function read(){return new Promise((resolve,reject)=>{const tx=db.transaction('host','readonly'),q=tx.objectStore('host').get('state');let value;q.onsuccess=()=>value=q.result;tx.oncomplete=()=>resolve(value);tx.onabort=tx.onerror=()=>reject(tx.error||q.error)})}
function write(value){return new Promise((resolve,reject)=>{const tx=db.transaction('host','readwrite');tx.objectStore('host').put(value,'state');tx.oncomplete=()=>resolve();tx.onabort=tx.onerror=()=>reject(tx.error||Error('Update storage failed.'))})}
window.PocketCrawUpdateStore={open,read,write,name:NAME};})();
