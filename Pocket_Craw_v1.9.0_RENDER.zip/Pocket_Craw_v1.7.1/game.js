(()=>{'use strict';
const GAME_VERSION='1.9.0';globalThis.PocketCrawVersion=GAME_VERSION;
const SAVE_STATES=['explore','combat','class','trap','elite','resource','merchant','chest','shrine','altar','door','mystery','vault','fountain','secret','supplies','workbench','camp','corpse','stairs','dead','legacy'];
const round2=n=>Math.round((Number(n)+Number.EPSILON)*100)/100;
const formatNumber=n=>String(round2(n));
function setHunger(n){g.hunger=round2(Math.max(0,Math.min(hungerCap(),n)));}
function canNavigate(){return ['explore','corpse'].includes(mode)}
function dismissCorpse(){if(mode==='corpse'){g.corpse=null;mode='explore'}}
const $=id=>document.getElementById(id),R=n=>Math.floor(Math.random()*n),P=a=>a[R(a.length)],D=[[0,-1],[1,0],[0,1],[-1,0]],K=(x,y)=>x+','+y;
const gearSlots=['weapon','offhand','head','armor','gloves','boots','ring','trinket','camp'];
const gearBases=[['Sword','weapon',{atk:3}],['Axe','weapon',{atk:4}],['Dagger','weapon',{atk:2,crit:.05}],['Wand','weapon',{atk:2,spell:.12}],['Shield','offhand',{def:2}],['Focus','offhand',{mana:5,spell:.08}],['Helm','head',{def:1}],['Hood','head',{mana:5}],['Mail','armor',{def:3}],['Robes','armor',{def:1,mana:6}],['Gauntlets','gloves',{atk:1}],['Grips','gloves',{crit:.04}],['Boots','boots',{def:1}],['Softsteps','boots',{evade:.04}],['Ring','ring',{life:6}],['Signet','ring',{spell:.08}],['Charm','trinket',{disarm:.08}],['Medallion','trinket',{life:6}],['Travel Bedroll','camp',{campTier:0}],['Adventurer Camp Kit','camp',{campTier:1}],['Expedition Camp','camp',{campTier:2}],['Sanctuary Kit','camp',{campTier:3}]];
const gearRules={Ring:['Warrior',1],Signet:['Mage',1],Charm:['Rogue',1],Medallion:['Knight',1],'War Badge':['Warrior',1],'Shadow Ring':['Rogue',1],'Rune Pendant':['Mage',1],'Oath Ring':['Knight',1],'Trail Ring':['Ranger',1],'Trail Token':['Ranger',1],'Reagent Ring':['Alchemist',1],'Formula Seal':['Alchemist',1],
 Sword:['Warrior',1],Axe:['Warrior',1],Greatsword:['Warrior',2],Warhammer:['Warrior',2],Shield:['Warrior',1],Helm:['Warrior',1],Mail:['Warrior',1],Gauntlets:['Warrior',1],Boots:['Warrior',1],
 Dagger:['Rogue',1],Dirk:['Rogue',1], 'Chain Whip':['Rogue',2],Kusarigama:['Rogue',2],Cowl:['Rogue',1],Leathers:['Rogue',1],Grips:['Rogue',1],Softsteps:['Rogue',1],
 Wand:['Mage',1],Scepter:['Mage',1],Staff:['Mage',2],Focus:['Mage',1],Hood:['Mage',1],Robes:['Mage',1],Spellweave:['Mage',1],Slippers:['Mage',1],
 Mace:['Knight',1],Halberd:['Knight',2],Aegis:['Knight',1],Greathelm:['Knight',1],Plate:['Knight',1],Vambraces:['Knight',1],Sabatons:['Knight',1],
 Spear:['Ranger',1],Longbow:['Ranger',2],Quiver:['Ranger',1],Cap:['Ranger',1],Jerkin:['Ranger',1],Bracers:['Ranger',1],Trailboots:['Ranger',1],
 Catalyst:['Alchemist',1],Sprayer:['Alchemist',2],Retort:['Alchemist',1],Goggles:['Alchemist',1],Coat:['Alchemist',1],Labgloves:['Alchemist',1],Waders:['Alchemist',1]
};
gearBases.push(['War Badge','trinket',{life:6}],['Shadow Ring','ring',{crit:.04}],['Rune Pendant','trinket',{life:6}],['Oath Ring','ring',{life:6}],['Trail Ring','ring',{life:6}],['Trail Token','trinket',{disarm:.08}],['Reagent Ring','ring',{spell:.08}],['Formula Seal','trinket',{life:6}],['Greatsword','weapon',{atk:7}],['Warhammer','weapon',{atk:6,penetration:.18}],['Dirk','weapon',{atk:3,crit:.03}],['Chain Whip','weapon',{atk:5,penetration:.2}],['Kusarigama','weapon',{atk:6,crit:.05}],['Scepter','weapon',{atk:3,spell:.08}],['Staff','weapon',{atk:5,spell:.16,mana:5}],['Cowl','head',{def:1}],['Leathers','armor',{def:2,evade:.03}],['Spellweave','gloves',{spell:.06}],['Slippers','boots',{def:1,mana:3}],['Mace','weapon',{atk:4}],['Halberd','weapon',{atk:7}],['Aegis','offhand',{def:2}],['Greathelm','head',{def:2}],['Plate','armor',{def:4}],['Vambraces','gloves',{def:1}],['Sabatons','boots',{def:1}],['Spear','weapon',{atk:4}],['Longbow','weapon',{atk:6,penetration:.15}],['Quiver','offhand',{crit:.05}],['Cap','head',{def:1}],['Jerkin','armor',{def:2}],['Bracers','gloves',{atk:1}],['Trailboots','boots',{evade:.04}],['Catalyst','weapon',{atk:3,spell:.10}],['Sprayer','weapon',{atk:5,spell:.14}],['Retort','offhand',{mana:5}],['Goggles','head',{mana:4}],['Coat','armor',{def:2}],['Labgloves','gloves',{spell:.06}],['Waders','boots',{def:1}]);
function tagGear(i){
 if(!i)return i;const starter=/^(?:\[[^\]]+\] )?(?:Starter (?:Sword|Shield|Wooden Shield|Leather Armor|Leather Boots)|Lucky Charm)(?: T\d+)?$/.test(i.n)||i.legacyStarter===true;if(starter){i.baseType=null;i.legacyStarter=true;i.classTag='Universal';i.hands=1;i.dagger=false;i.n='[Universal] '+i.n.replace(/^\[[^\]]+\] /,'');return i;}
 if(!Object.hasOwn(i,'baseType')){const candidates=gearBases.map(x=>x[0]).sort((a,b)=>b.length-a.length);i.baseType=candidates.find(n=>new RegExp('\\b'+n+'\\b','i').test(i.n))||null;}
 const rule=gearRules[i.baseType];i.classTag=rule?rule[0]:'Universal';i.hands=i.slot==='weapon'?(rule?.[1]||1):1;
 i.dagger=['Dagger','Dirk','Worn Dagger'].includes(i.baseType);
 if(!/^\[(Warrior|Rogue|Mage|Knight|Ranger|Alchemist|Universal)\] /.test(i.n))i.n='['+i.classTag+'] '+i.n;
 return i;
}
function classCanUse(i){tagGear(i);return !g.baseClass||i.classTag==='Universal'||i.classTag===g.baseClass}
function equipReason(i,target=i.slot){
 tagGear(i);if(!classCanUse(i))return i.classTag+' only';
 if(i.requiredLevel&&g.level<i.requiredLevel)return 'Requires level '+i.requiredLevel;
 if(target==='offhand'&&i.slot==='weapon'&&(!i.dagger||g.baseClass!=='Rogue'))return 'Only Rogues dual wield daggers';
 if(target!==i.slot&&!(target==='offhand'&&i.slot==='weapon'&&i.dagger&&g.baseClass==='Rogue'))return 'Wrong equipment slot';
 return '';
}
function reconcileEquipment(){
 for(const i of [...g.inventory,...Object.values(g.equipment)])if(i)tagGear(i);
 let moved=0;
 for(const slot of gearSlots){const i=g.equipment[slot];if(i&&(equipReason(i,slot)||(slot==='offhand'&&g.equipment.weapon?.hands===2))){g.inventory.push(i);g.equipment[slot]=null;moved++;}}
 g.hp=Math.min(g.hp,healthCap());g.mp=Math.min(g.mp,manaCap());return moved;
}

const starterBases=['Crude Sword','Simple Staff','Worn Dagger','Wooden Buckler','Cloth Cap','Shoddy Leathers','Rough Gloves','Worn Boots','Plain Band','Twine Charm'];
gearBases.push(['Crude Sword','weapon',{atk:2}],['Simple Staff','weapon',{atk:2,mana:2}],['Worn Dagger','weapon',{atk:1,crit:.02}],['Wooden Buckler','offhand',{def:1}],['Cloth Cap','head',{def:1}],['Shoddy Leathers','armor',{def:1}],['Rough Gloves','gloves',{atk:1}],['Worn Boots','boots',{def:1}],['Plain Band','ring',{life:3}],['Twine Charm','trinket',{mana:2}]);
function lootTier(level=g.level){return level<5?1:2+Math.floor((level-5)/5)}
function eligibleBase(name){const base=gearBases.find(b=>b[0]===name);return base&&((g.level<5||!g.baseClass)?starterBases.includes(name)||name==='Travel Bedroll':base[1]==='camp'?(base[2].campTier||0)<=Math.floor((g.level-1)/5):!starterBases.includes(name))}

const gearAffixes=[['Stout',{life:5}],['Keen',{crit:.04}],['Warded',{def:1}],['Mystic',{mana:4}],['Brutal',{atk:1}],['Nimble',{evade:.03}],['Delver’s',{disarm:.06}],['Runed',{spell:.08}],['Sustaining',{hungerSave:.1}],['Forager’s',{foodFind:.2}],['Scavenger’s',{scavenge:.15}]];
function gearWorks(i){return !!i&&(i.durability===undefined||i.durability>0)}
function initDurability(i){tagGear(i);if(i.maxDurability===undefined){i.maxDurability=(i.slot==='camp'?75:i.slot==='armor'?140:i.slot==='weapon'?120:100)+({Common:0,Magic:10,Rare:25,Epic:40}[i.rarity]||0)}if(i.durability===undefined)i.durability=i.maxDurability;return i}
function wearSlot(slot,amount){const i=g.equipment[slot];if(!i)return;initDurability(i);if(i.durability<=0)return;const before=i.durability;i.durability=Math.max(0,Math.round((i.durability-amount)*100)/100);if(i.durability===0)say(i.n+' broke! Its bonuses are inactive until repaired.');else if(before>i.maxDurability*.2&&i.durability<=i.maxDurability*.2)say(i.n+' is badly worn. Repair it in Gear.');g.hp=Math.min(g.hp,healthCap());g.mp=Math.min(g.mp,manaCap())}
function wearArmor(damage,type){const amount=1+Math.ceil(damage/12)+(type==='acid'?2:type==='fire'||type==='heat'?1:0);for(const slot of ['armor','head','gloves','boots'])wearSlot(slot,slot==='armor'?amount:Math.max(1,Math.ceil(amount/2)));if(g.equipment.offhand?.def)wearSlot('offhand',amount)}
function repairPower(){return 20+Math.min(20,Math.floor(g.level/5)*2)+Math.floor(passiveValue('repair'))+(g.baseClass==='Alchemist'?15:['Warrior','Knight'].includes(g.baseClass)?10:0)}
function ownsGear(i){return g.inventory.includes(i)||Object.values(g.equipment).includes(i)}
function repairGear(i){if(!gearAllowed()||!ownsGear(i)||g.scrap<1)return;initDurability(i);if(i.durability>=i.maxDurability)return;const restored=Math.min(repairPower(),i.maxDurability-i.durability);g.scrap--;i.durability=Math.min(i.maxDurability,Math.round((i.durability+restored)*100)/100);say('Repaired '+i.n+': +'+Math.round(restored)+' durability for 1 scrap.');render()}
function addSustainingMod(i){if(!gearAllowed()||!ownsGear(i)||g.scrap<3||i.sustainingMod)return;g.scrap-=3;i.hungerSave=(i.hungerSave||0)+.1;i.sustainingMod=true;say('Added Sustaining modifier to '+i.n+': 10% less hunger consumption.');render()}
function durabilityControls(card,i){initDurability(i);const label=document.createElement('p');label.textContent='Durability '+Math.ceil(i.durability)+'/'+i.maxDurability+(i.durability===0?' · BROKEN':'');card.appendChild(label);const bar=document.createElement('progress');bar.max=i.maxDurability;bar.value=i.durability;bar.className='durability-bar';bar.style.accentColor=i.durability<=i.maxDurability*.2?'#e86a76':'#74bd96';bar.setAttribute('aria-label',i.n+' durability');card.appendChild(bar);card.appendChild(button('Repair +'+repairPower()+' · 1 scrap',()=>repairGear(i),!gearAllowed()||g.scrap<1||i.durability>=i.maxDurability));card.appendChild(button(i.sustainingMod?'Sustaining modifier installed':'Add Sustaining · 3 scrap',()=>addSustainingMod(i),!gearAllowed()||g.scrap<3||i.sustainingMod))}
function legacyHungerCap(){return 100+25*['Deep Reserves I (+25 hunger capacity)','Deep Reserves II (+25 hunger capacity)','Deep Reserves III (+25 hunger capacity)'].filter(n=>unlocks.has(n)).length}
function hungerCap(){return g.hungerMax||100}
function biomeHunger(){return ({keep:1,ruins:1,sewer:1.15,crypt:1.1,cave:1.2,ice:1.5,forge:1.5,abyss:1.3})[m?.biome]||1}
function hungerDrain(){return Math.round(biomeHunger()*(1-Math.min(.6,gearStat('hungerSave')))*100)/100}
function channelRing(){const ring=g.equipment.ring;if(mode!=='combat'||!ring?.channelHeal||!gearWorks(ring)||g.mp<3||g.hp>=healthCap())return;if(tickEffects()){render();return}g.mp-=3;const heal=Math.min(healthCap()-g.hp,8+Math.floor(g.level/3));g.hp+=heal;wearSlot('ring',2+Math.ceil(heal/10));say('Channeled '+ring.n+': restored '+heal+' HP; ring durability reduced.');enemyAttack();render()}
function gearStat(key){return Object.entries(g.equipment).reduce((n,[slot,i])=>n+(gearWorks(i)&&classCanUse(i)&&!(slot==='offhand'&&g.equipment.weapon?.hands===2)?(i[key]||0):0),0)}
function healthCap(){return g.maxhp+gearStat('life')}function manaCap(){return g.maxmp+gearStat('mana')}
function gearText(i){tagGear(i);return i.classTag+' · '+(i.slot==='weapon'?(i.hands===2?'Two-handed · occupies both hands':i.dagger?'One-handed · Rogue offhand eligible':'One-handed'):'')+' · '+gearStatsText(i)}
function gearStatsText(i){if(i.slot==='ring'&&i.channelHeal)return 'Passive while equipped; active channel heals HP for 3 MP and ring durability. '+Object.entries({atk:'ATK',def:'DEF',life:'HP',mana:'MP',spell:'Skill'}).filter(([k])=>i[k]).map(([k,label])=>label+' +'+i[k]).join(' · ');if(i.slot==='camp')return 'Camping tier '+((i.campTier||0)+1)+' · Rest efficiency '+[5,12,22,35][i.campTier||0]+'% HP / '+[5,8,15,25][i.campTier||0]+'% MP';return Object.entries({atk:'ATK',def:'DEF',life:'HP',mana:'MP',crit:'Crit',evade:'Evade',spell:'Skill',disarm:'Disarm',hungerSave:'Hunger saving',foodFind:'Food yield',scavenge:'Scavenge chance (enables corpse scavenging)'}).filter(([k])=>i[k]).map(([k,label])=>label+' +'+(['crit','evade','spell','disarm','hungerSave','foodFind','scavenge'].includes(k)?Math.round(i[k]*100)+'%':i[k])).join(' · ')}
function rollGear(floor=g.floor,quality=0){let pool=gearBases.filter(b=>eligibleBase(b[0]));const force=g.baseClass&&((g.lootMisses||0)>=3||Math.random()<.70);if(force)pool=pool.filter(b=>!gearRules[b[0]]||gearRules[b[0]][0]===g.baseClass);const base=P(pool),r=Math.random(),rank=g.level<5||!g.baseClass?0:quality>=2?2:r<Math.min(.10,.02+floor*.002)?3:r<.20?2:r<.55?1:0;const item=makeGear(base[0],g.level,rank);if(g.baseClass)g.lootMisses=classCanUse(item)?0:(g.lootMisses||0)+1;return item}
function makeGear(baseName,floor,rank=0,crafted=false){
 const [name,slot,stats]=gearBases.find(x=>x[0]===baseName),tier=lootTier(g.level),i={n:name+' T'+tier,baseType:name,slot,rarity:['Common','Magic','Rare','Epic'][rank],tier,upgrade:0,price:12+tier*6+rank*12};
 for(const [k,v]of Object.entries(stats))i[k]=['atk','def','life','mana'].includes(k)?v+(tier-1)*(k==='atk'&&gearRules[name]?.[1]===2?2:1):v;
 const pool=gearAffixes.slice();if(crafted){i.craftRoll=1+R(100);rank=Math.min(3,rank+(i.craftRoll>=76?1:0));i.rarity=['Common','Magic','Rare','Epic'][rank];i.price=12+tier*6+rank*12;i.craftAffixes=[];}
 for(let n=0;n<rank;n++){const index=R(pool.length),[prefix,values]=pool.splice(index,1)[0];i.n=prefix+' '+i.n;if(crafted)i.craftAffixes.push(prefix);for(const [k,v]of Object.entries(values))i[k]=(i[k]||0)+v;}
 i.crafted=crafted;return initDurability(i);
}
function gearAllowed(){return !!g&&g.hp>0&&!['combat','dead','splash'].includes(mode)}
function equipGear(item,target=item.slot){
 if(!gearAllowed()||!g.inventory.includes(item))return;
 const reason=equipReason(item,target);if(reason){say(reason);return}initDurability(item);
 g.inventory.splice(g.inventory.indexOf(item),1);
 const displace=slot=>{if(g.equipment[slot]){g.inventory.push(g.equipment[slot]);g.equipment[slot]=null}};
 if(target==='weapon'&&item.hands===2)displace('offhand');
 if(target==='offhand'&&g.equipment.weapon?.hands===2)displace('weapon');
 displace(target);g.equipment[target]=item;g.hp=Math.min(g.hp,healthCap());g.mp=Math.min(g.mp,manaCap());say('Equipped '+item.n+(item.hands===2?' (both hands)':''));render();
}
function unequipGear(slot){if(!gearAllowed()||!g.equipment[slot])return;g.inventory.push(g.equipment[slot]);g.equipment[slot]=null;g.hp=Math.min(g.hp,healthCap());g.mp=Math.min(g.mp,manaCap());say('Unequipped '+g.inventory[g.inventory.length-1].n+'.');render()}
const materialNames={metal:'Metal fragments',leather:'Leather',cloth:'Cloth',wood:'Wood',bone:'Bone',gem:'Gem fragments',dust:'Arcane dust',mechanical:'Mechanical parts',plates:'Reinforcement plates',essence:'Essence'};
const materialKeys=Object.keys(materialNames);
const salvageTypes={camp:['cloth','leather'],weapon:['metal','wood'],offhand:['metal','wood'],head:['metal','cloth'],armor:['metal','plates'],gloves:['leather','cloth'],boots:['leather','cloth'],ring:['gem','dust'],trinket:['bone','gem']};
function materialBag(){if(!g.materials||typeof g.materials!=='object')g.materials={};for(const k of materialKeys)g.materials[k]??=0;return g.materials}
function salvagePreview(item){initDurability(item);if(item.crafted){const paid=item.craftCost||craftRecipes.find(r=>r.base===item.baseType)?.cost||{};return Object.fromEntries(Object.entries(paid).map(([k,n])=>[k,Math.floor(n/2)]).filter(([,n])=>n>0))}const rank=({Common:0,Magic:1,Rare:2,Epic:3})[item.rarity]||0,ratio=item.durability/item.maxDurability;const [primary,secondary]=salvageTypes[item.slot]||['metal','wood'];const result={[primary]:Math.max(primary==='metal'?2:1,Math.floor((3+rank*2)*(.4+.6*ratio))),[secondary]:Math.max(1,Math.floor((1+rank)*(.5+.5*ratio)))};if(passiveValue('salvage'))result[primary]++;if(rank>=1)result.dust=(result.dust||0)+rank;if(rank>=2)result.essence=(result.essence||0)+rank-1;if(rank>=3)result.plates=(result.plates||0)+2;return result}
function salvageGear(item,quiet=false){if(!gearAllowed()||!g.inventory.includes(item)||item.protected)return;const found=salvagePreview(item);g.inventory.splice(g.inventory.indexOf(item),1);const bag=materialBag();for(const [key,n]of Object.entries(found))bag[key]+=n;const scrap=salvageScrap(item);g.scrap+=scrap;const special=item.crafted?0:(item.rarity==='Rare'?.22:item.rarity==='Epic'?.6:0);if(Math.random()<special){const k=P(['gem','dust','essence']);bag[k]++;found[k]=(found[k]||0)+1}say('Salvaged '+item.n+': '+Object.entries(found).map(([k,n])=>n+' '+materialNames[k]).join(', ')+' and '+scrap+' scrap.');if(!quiet)render()}
const lockpickTiers=[{id:'basic',name:'Basic',bonus:0},{id:'fine',name:'Fine',bonus:.20},{id:'magic',name:'Magic',bonus:.38}];
function ensurePicks(){g.lockpicks??={basic:3,fine:0,magic:0};return g.lockpicks}
const craftRecipes=[{name:'Basic Lockpicks ×3',base:'lockpick',cost:{metal:2,wood:1}},...gearBases.map(([name,slot,stats])=>({name:(gearRules[name]?.[0]||'Universal')+' · '+name,base:name,minFloor:slot==='camp'?1+(stats.campTier||0)*5:1,cost:slot==='camp'?{cloth:4+(stats.campTier||0)*2,leather:3+(stats.campTier||0)*2,wood:2}:slot==='weapon'?{metal:4,wood:2}:slot==='offhand'?{metal:3,wood:2}:['head','armor','gloves','boots'].includes(slot)?{leather:4,cloth:2}:{gem:2,dust:2}}))];
const qualityCost={basic:{},refined:{dust:2,essence:1},masterwork:{dust:5,essence:3,plates:2}};
function recipeCost(recipe,quality){const cost={...recipe.cost};if(passiveValue('craft'))for(const k of Object.keys(cost))cost[k]=Math.max(1,Math.ceil(cost[k]*.8));for(const [k,n]of Object.entries(qualityCost[quality]))cost[k]=(cost[k]||0)+n;return cost}
function canCraft(recipe,quality){if((g.level<5||!g.baseClass)&&quality!=='basic'||!qualityCost[quality]||g.level<(recipe.minFloor||1)||!eligibleBase(recipe.base)&&recipe.base!=='lockpick')return false;const rule=gearRules[recipe.base];if(g.baseClass&&rule&&rule[0]!==g.baseClass)return false;const bag=materialBag(),cost=recipeCost(recipe,quality);return Object.entries(cost).every(([k,n])=>bag[k]>=n)}
function craftGear(recipe,quality){if(mode!=='camp'||!craftRecipes.includes(recipe)||!canCraft(recipe,quality))return;const bag=materialBag(),cost=recipeCost(recipe,quality);for(const [k,n]of Object.entries(cost))bag[k]-=n;if(recipe.base==='lockpick'){ensurePicks().basic+=3;g.lastCraft={name:'Basic Lockpicks ×3',text:'Added 3 basic lockpicks. No random roll.',roll:null};say('Crafted 3 basic lockpicks.')}else{const rank={basic:0,refined:1,masterwork:2}[quality];const item=makeGear(recipe.base,g.floor,rank,true);item.craftCost={...cost};g.lastCraft={name:item.n,text:gearText(item),roll:item.craftRoll,affixes:item.craftAffixes,item:JSON.parse(JSON.stringify(item))};acquireGear(item);say('Crafted '+item.rarity+' '+item.n+' · d100 roll '+item.craftRoll+' · '+(item.craftAffixes.join(', ')||'no bonus modifiers')+'.')}render()}
function convertScrap(key){if(mode!=='camp'||!['metal','wood','leather','cloth'].includes(key)||g.scrap<1)return;g.scrap--;materialBag()[key]+=2;say('Converted 1 scrap into 2 '+materialNames[key]+'.');render()}
function refineMaterials(){const bag=materialBag();if(mode!=='camp'||bag.dust<4)return;bag.dust-=4;bag.essence++;say('Refined 4 arcane dust into 1 essence.');render()}

function workbenchRecipes(a){const info=document.createElement('p');info.textContent='Craft at your character level tier. Basic starts Common, Refined Magic, Masterwork Rare. Roll d100: 76–100 adds one rarity/modifier, up to Epic. Modifiers are random; costs stay fixed. Materials: '+materialKeys.filter(k=>materialBag()[k]).map(k=>materialNames[k]+' ×'+materialBag()[k]).join(' · ');a.appendChild(info);
 for(const key of ['metal','wood','leather','cloth'])a.appendChild(button('1 scrap → 2 '+materialNames[key],()=>convertScrap(key),g.scrap<1));
 a.appendChild(button('4 dust → 1 essence',refineMaterials,materialBag().dust<4));
 for(const recipe of craftRecipes){const rule=gearRules[recipe.base];if(!eligibleBase(recipe.base)&&recipe.base!=='lockpick'||g.baseClass&&rule&&rule[0]!==g.baseClass)continue;const details=document.createElement('details');details.className='merchant-section';const title=document.createElement('summary');title.textContent=recipe.name+(g.level<(recipe.minFloor||1)||!eligibleBase(recipe.base)&&recipe.base!=='lockpick'?' · level '+recipe.minFloor:'');details.appendChild(title);details.appendChild(button(g.pinnedRecipe===recipe.base?'Unpin recipe':'Pin recipe',()=>{g.pinnedRecipe=g.pinnedRecipe===recipe.base?null:recipe.base;render()}));const area=document.createElement('div');area.className='actions';for(const quality of recipe.base==='lockpick'||g.level<5||!g.baseClass?['basic']:['basic','refined','masterwork']){const preview=recipe.base==='lockpick'?'':gearText(makeGear(recipe.base,g.floor,{basic:0,refined:1,masterwork:2}[quality],true));const desc=document.createElement('small');desc.textContent=quality+': '+preview;area.appendChild(desc);const cost=recipeCost(recipe,quality);area.appendChild(button('Craft '+quality+' · '+Object.entries(cost).map(([k,n])=>n+' '+materialNames[k]).join(', '),()=>craftGear(recipe,quality),!canCraft(recipe,quality)))}details.appendChild(area);a.appendChild(details)}a.appendChild(button('Back to camp',()=>{workbenchOpen=false;render()}));
}
let workbenchOpen=false;
function workbenchPanel(a){if(workbenchOpen){workbenchRecipes(a);return;}a.appendChild(button('⚒ Craft items',()=>openCrafting()));a.appendChild(button('Leave workbench',()=>{workbenchOpen=false;mode='explore';render()}))}

function sellGear(item){if(mode!=='merchant'||!g.inventory.includes(item))return;g.inventory.splice(g.inventory.indexOf(item),1);g.gold+=Math.max(1,Math.floor((item.price||12)*.4));render()}
function upgradeGear(item){const rank=item.upgrade||0,cost=2*(rank+1),gold=8*(rank+1);if(mode!=='merchant'||!Object.values(g.equipment).includes(item)||rank>=3||g.scrap<cost||g.gold<gold)return;g.scrap-=cost;g.gold-=gold;item.upgrade=rank+1;const key=item.slot==='weapon'||item.slot==='gloves'?'atk':item.mana?'mana':item.def?'def':'life';item[key]=(item[key]||0)+(key==='mana'||key==='life'?3:1);say('Improved '+item.n+' to +'+item.upgrade);render()}
function autoEquipPreference(){try{return localStorage.getItem('pocketCrawAutoEquip')!=='false'}catch(e){return true}}
function acquireGear(item){initDurability(item);let slot=item.slot;
 if(g.baseClass==='Rogue'&&item.dagger&&g.equipment.weapon?.dagger&&!g.equipment.offhand)slot='offhand';
 if(g.autoEquip!==false&&!equipReason(item,slot)&&!g.equipment[slot]&&!(slot==='offhand'&&g.equipment.weapon?.hands===2)&&!(item.hands===2&&g.equipment.offhand)){g.equipment[slot]=item;say('Auto-equipped '+item.n+'.')}else g.inventory.push(item);
}
function receiveGear(quality=0){const item=rollGear(g.floor,quality);acquireGear(item);say('Found '+item.rarity+' '+item.n+' ('+gearText(item)+').')}
const consumables={manaTonics:{name:'Mana tonic',price:20,stock:'merchantMana',description:'Restore 12 MP'},antidotes:{name:'Antidote',price:12,stock:'merchantAntidotes',description:'Remove poison'},bandages:{name:'Bandage',price:10,stock:'merchantBandages',description:'Heal 10 HP and stop bleeding'}};
function buyFoodBundle(){const count=10,cost=count*12;if(mode!=='merchant'||g.merchantRations<count||g.gold<cost)return;g.gold-=cost;g.rations+=count;g.merchantRations-=count;say('Bought 10 rations for '+cost+' gold. Merchant has '+g.merchantRations+' rations remaining.');render()}
function merchantGear(floor){let item=rollGear(floor);const max=floor<=3?1:floor<=7?2:3;let attempts=0;while(({Common:0,Magic:1,Rare:2,Epic:3}[item.rarity]||0)>max&&attempts++<30)item=rollGear(floor);if(({Common:0,Magic:1,Rare:2,Epic:3}[item.rarity]||0)>max)item=rollGear(floor,0),item.rarity='Common';return item}
function merchantFoodStock(floor){const max=Math.min(1000,200+Math.max(0,floor-3)*40);return 10*(1+R(Math.floor(max/10)))}
function buyConsumable(key){const c=consumables[key];if(!c||mode!=='merchant'||g[c.stock]<1||g.gold<c.price)return;g.gold-=c.price;g[c.stock]--;g[key]++;say('Bought '+c.name+' for '+c.price+' gold.');render()}
function canUseConsumable(key){if(!['explore','combat','merchant','stairs'].includes(mode)||!g[key])return false;return key==='manaTonics'?g.mp<manaCap():key==='antidotes'?(g.effects||[]).some(e=>e.kind==='Poison'):key==='bandages'?g.hp<healthCap()||(g.effects||[]).some(e=>e.kind==='Bleeding'):false}
function useConsumable(key){if(!canUseConsumable(key))return;const inCombat=mode==='combat';g[key]--;if(key==='manaTonics')g.mp=Math.min(manaCap(),g.mp+12);if(key==='antidotes')g.effects=g.effects.filter(e=>e.kind!=='Poison');if(key==='bandages'){g.hp=Math.min(healthCap(),g.hp+10);g.effects=g.effects.filter(e=>e.kind!=='Bleeding')}say('Used '+consumables[key].name+': '+consumables[key].description+'.');if(inCombat&&!tickEffects())enemyAttack();render()}
function merchantPanel(a){const group=(title,open)=>{const details=document.createElement('details');details.className='merchant-section';details.open=open;const summary=document.createElement('summary');summary.textContent=title;details.appendChild(summary);const body=document.createElement('div');body.className='actions';details.appendChild(body);a.appendChild(details);return body},add=(parent,text,fn,disabled=false)=>parent.appendChild(button(text,fn,disabled));
 const food=group('Food · 10-ration bundles',true),count=g.merchantRations;
 add(food,count?'Buy 10 rations · 120g · '+count+' in stock':'Food sold out',buyFoodBundle,count<10||g.gold<120);
 const supplies=group('Consumables · limited stock',true);
 add(supplies,'Healing potion · 18g · '+g.merchantPotions+' left',()=>{if(mode!=='merchant'||g.merchantPotions<1||g.gold<18)return;g.gold-=18;g.merchantPotions--;g.potions++;say('Bought healing potion for 18 gold.');render()},g.gold<18||!g.merchantPotions);
 for(const [key,c]of Object.entries(consumables))add(supplies,c.name+' · '+c.price+'g · '+g[c.stock]+' left — '+c.description,()=>buyConsumable(key),!g[c.stock]||g.gold<c.price);
 const tools=group('Lockpicks',false);for(const [tier,price] of [['basic',6],['fine',24],['magic',55]])add(tools,'Buy '+tier+' lockpick · '+price+'g',()=>{if(mode!=='merchant'||g.gold<price)return;g.gold-=price;ensurePicks()[tier]++;say('Purchased '+tier+' lockpick.');render()},g.gold<price);const equipment=group('Equipment · '+stock.length+' items',false);stock.forEach(i=>add(equipment,(i.rarity||'Common')+' '+i.n+' · '+gearText(i)+' · '+i.price+'g',()=>{if(mode!=='merchant'||!stock.includes(i)||g.gold<i.price)return;g.gold-=i.price;acquireGear(i);stock=stock.filter(x=>x!==i);say('Purchased '+i.n);render()},g.gold<i.price));
 add(a,'Leave merchant · trader stays here',()=>{mode='explore';render()});add(a,'Dismiss merchant permanently',()=>{events.delete(K(g.x,g.y));mode='explore';render()});
}
const campTiers=[{hp:5,mp:5,wear:1,risk:.25},{hp:12,mp:8,wear:2,risk:.18},{hp:22,mp:15,wear:3,risk:.10},{hp:35,mp:25,wear:4,risk:.05}];
function campData(){const item=g.equipment.camp;return item&&gearWorks(item)?campTiers[Math.max(0,Math.min(3,item.campTier||0))]:null}
function campRisk(){const base=campData()?.risk??0;return Math.max(.01,base*(campSites.has(K(g.x,g.y))?.2:1))}
function campPreview(){const item=g.equipment.camp,info=campData();if(!info)return item?'Camping kit is broken; repair or replace it.':'Equip camping gear before resting.';return item.n+' · 1 ration · +'+Math.max(1,Math.ceil(healthCap()*info.hp/100))+' HP (up to '+info.hp+'%) · +'+Math.ceil(manaCap()*info.mp/100)+' MP · +30 hunger · '+info.wear+' durability · '+Math.round(campRisk()*100)+'% ambush chance'+(campSites.has(K(g.x,g.y))?' (sheltered campsite; not guaranteed safe).': ' (exposed location).')}
function rest(){if(mode!=='camp'||g.rations<1||!campData())return;const info=campData(),kit=g.equipment.camp;g.rations--;wearSlot('camp',info.wear);setHunger(g.hunger+30);if(Math.random()<campRisk()){say('Camp ambush! 1 ration and '+info.wear+' camping durability spent. Recovery interrupted.');enemy=makeEnemy();mode='combat';render();return}const beforeHp=g.hp,beforeMp=g.mp;g.hp=Math.min(healthCap(),g.hp+Math.max(1,Math.ceil(healthCap()*info.hp/100)));g.mp=Math.min(manaCap(),g.mp+Math.ceil(manaCap()*info.mp/100));say('Camp complete: 1 ration, '+info.wear+' durability; +'+(g.hp-beforeHp)+' HP, +'+(g.mp-beforeMp)+' MP, +30 hunger.');render()}

const AUTO_EAT_KEY='pocketCrawAutoEatV1';
let autoEatRations=true;try{autoEatRations=localStorage.getItem(AUTO_EAT_KEY)!=='off'}catch(_){}
globalThis.PocketCrawAutoEat={get enabled(){return autoEatRations},set(enabled){autoEatRations=!!enabled;if(!devMode)try{localStorage.setItem(AUTO_EAT_KEY,autoEatRations?'on':'off')}catch(_){}}};
function autoEatIfNeeded(){
 if(!autoEatRations||!g||g.hp<=0||g.rations<1||g.hunger>=hungerCap()*.1)return false;
 g.rations--;setHunger(g.hunger+40);
 say('Auto-eat: ate 1 ration, +40 hunger ('+formatNumber(g.hunger)+'/'+hungerCap()+').');
 return true;
}
function eat(){if(mode!=='explore'||g.rations<1||g.hunger>=hungerCap())return;g.rations--;setHunger(g.hunger+40);say('Ate 1 ration: +40 hunger ('+formatNumber(g.hunger)+'/'+hungerCap()+').');render()}
function foodDrop(chance,source){if(Math.random()>=chance)return false;g.rations++;say(source+': found 1 sealed food ration.');return true}
function monsterFoodDrop(defeated){if(['golem','crystal','wraith','stalker','skeleton'].includes(defeated.model))return 0;
 const level=Math.max(1,g.floor), bonus=Math.max(0,gearStat('foodFind')+passiveValue('foodFind'));
 // Strongly favors small drops; the floor and foraging gear improve the upper tail.
 const exponent=Math.max(1.65,4.1-Math.min(1.6,(level-1)*.055)-Math.min(.85,bonus*1.5));
 const amount=Math.max(1,Math.min(50,1+Math.floor(49*Math.pow(Math.random(),exponent))));
 g.rations+=amount;
 say('Defeated '+defeated.n+': recovered '+amount+' food ration'+(amount===1?'':'s')+'.');
 return amount;
}
function canScavenge(){return g.baseClass==='Rogue'||g.baseClass==='Ranger'||passiveValue('detect')>0||gearStat('scavenge')>0}
function scavengeCorpse(){
 if(mode!=='corpse'||!g.corpse||!canScavenge())return;
 const corpse=g.corpse;g.corpse=null;
 const bonus=Math.max(0,gearStat('scavenge'));
 // A corpse can be scavenged only once, with a modest chance of bonus gear.
 const food=corpse.mimic?12+R(29):Math.random()<Math.min(.95,.55+bonus)?1+R(Math.min(20,4+g.floor)):0;
 if(food){g.rations+=food;say('Scavenged '+food+' extra food ration'+(food===1?'':'s')+'.')}
 if(Math.random()<Math.min(.65,.12+bonus)){receiveGear();say('Found bonus equipment while scavenging.')}
 else if(Math.random()<Math.min(.9,.4+bonus)){const gold=2+R(7+g.floor*2);g.gold+=gold;say('Scavenged '+gold+' extra gold.')}
 else if(!food)say('The '+corpse.n+' has nothing useful left.');
 for(const slot of ['gloves','trinket'])if(g.equipment[slot]&&(g.equipment[slot].scavenge||g.equipment[slot].foodFind))wearSlot(slot,.4);
 mode='explore';render();
}
function hungerStep(){const before=g.hunger,cap=hungerCap();setHunger(g.hunger-hungerDrain());autoEatIfNeeded();wearSlot('boots',.05);if(g.hunger===0){const damage=Math.ceil(healthCap()*.1);g.hp=Math.max(0,g.hp-damage);say('Starvation: '+damage+' damage (10% max HP). Eat a ration or find food!');if(g.hp===0){die();return true}}else{if(g.hunger>cap*.5){const hp=g.hp,mp=g.mp;g.hp=Math.min(healthCap(),g.hp+1);g.mp=Math.min(manaCap(),g.mp+1);if(g.hp>hp||g.mp>mp)say('Well-fed: recovered '+(g.hp-hp)+' HP and '+(g.mp-mp)+' MP.');}if(before>cap*.5&&g.hunger<=cap*.5)say('Hunger is at or below 50%; natural healing has stopped.');if(before>cap*.2&&g.hunger<=cap*.2)say('Food is running low: '+formatNumber(g.hunger)+'/'+hungerCap()+' hunger.')}return false}
function searchSupplies(){
 if(mode!=='supplies')return;
 const label=supplyName(),roll=Math.random();
 if(roll<.45)foodDrop(1,label);
 else if(roll<.70)say(label+': empty, spoiled, or picked clean.');
 else if(roll<.90){
  const hp=6+g.floor*2;
  enemy={n:g.floor<=2?'Startled Dungeon Rat':'Scavenging Cave Vermin',hp,maxhp:hp,atk:2+g.floor,xp:4+g.floor,armor:0,special:'',model:'rat'};
  mode='combat';say('Vermin spring from '+label.toLowerCase()+'!');render();return;
 }else{const coins=2+R(5+g.floor);g.gold+=coins;say(label+': found '+coins+' gold among the scraps.');}
 mode='explore';render();
}
function supplyName(){return ({keep:'Cast-off belongings',sewer:'Rubbish pile',crypt:'Abandoned pilgrim pack',cave:'Lost miner supplies',ruins:'Overgrown campsite',ice:'Frozen travel pack',forge:'Discarded worker satchel',abyss:'Lost expedition pack'})[m.biome]||'Abandoned belongings'}
function renderGear(){
 const toggle=$('autoEquip');if(toggle){toggle.checked=g.autoEquip!==false;toggle.onchange=()=>{g.autoEquip=toggle.checked;try{localStorage.setItem('pocketCrawAutoEquip',String(g.autoEquip))}catch(e){}saveGame();render()}}
 $('equipment').textContent='Scrap '+g.scrap+' · Food '+g.rations;
 const slots=$('gearSlots');slots.replaceChildren();
 function compactRow(item,slot,equipped){
  const wrap=document.createElement('details');wrap.className='pc-item-row '+(item?.rarity||'Common').toLowerCase();if(item){let id=inventoryIds.get(item);if(!id){id=++inventorySerial;inventoryIds.set(item,id)}wrap.dataset.inventoryId=id;wrap.open=inventoryExpanded.has(String(id));}
  const summary=document.createElement('summary');summary.className='pc-item-summary';
  const name=document.createElement('span');name.textContent=item?item.n:(slot==='offhand'&&g.equipment.weapon?.hands===2?'OFFHAND · occupied by two-handed weapon':slot+' · empty');
  const type=document.createElement('small');type.textContent=slot.toUpperCase()+(item?' · '+(item.rarity||'Common'):'');
  const headline=document.createElement('span');headline.className='pc-item-headline';headline.append(name,type);
  const badge=document.createElement('span');badge.className='pc-item-badge';badge.textContent=equipped?'EQUIPPED':item?.protected?'PROTECTED':item?'VIEW':'EMPTY';const art=paintedItem(item);if(art)summary.append(art);summary.append(headline,badge);wrap.appendChild(summary);
  if(!item)return wrap;
  const detail=document.createElement('div');detail.className='pc-item-detail';const desc=document.createElement('p');desc.textContent=(gearText(item)||'No special modifiers')+(item.craftRoll?' · Craft d100: '+item.craftRoll+' · '+(item.craftAffixes?.join(', ')||'no bonus modifiers'):'');detail.appendChild(desc);if(!equipped){const yieldLine=document.createElement('p');yieldLine.textContent='Salvage: '+formatMaterials(salvagePreview(item))+' + '+salvageScrap(item)+' scrap (rare bonus may add more).';detail.append(yieldLine);}
  if(!equipped){const old={...(g.equipment[item.slot]||{})};if(item.slot==='offhand'&&g.equipment.weapon?.hands===2)for(const k of ['atk','def','life','mana','crit','evade','spell','disarm','hungerSave','foodFind','scavenge'])old[k]=(old[k]||0)+(g.equipment.weapon[k]||0);if(item.hands===2&&g.equipment.offhand)for(const k of ['atk','def','life','mana','crit','evade','spell','disarm','hungerSave','foodFind','scavenge'])old[k]=(old[k]||0)+(g.equipment.offhand[k]||0);const cmp=document.createElement('div');cmp.className='pc-item-comparison';cmp.appendChild(document.createTextNode('Compared with equipped: '));let changed=false;
   for(const key of ['atk','def','life','mana','crit','evade','spell','disarm','hungerSave','foodFind','scavenge']){const delta=(item[key]||0)-(old[key]||0);if(!delta)continue;changed=true;const s=document.createElement('span');s.className=delta>0?'pc-positive':'pc-negative';s.textContent=key.toUpperCase()+' '+(delta>0?'+':'')+(['crit','evade','spell','disarm','hungerSave','foodFind','scavenge'].includes(key)?Math.round(delta*100)+'%':delta)+' ';cmp.appendChild(s)}if(!changed)cmp.appendChild(document.createTextNode('No stat change'));detail.appendChild(cmp)}
  initDurability(item);const durability=document.createElement('small');durability.textContent='Durability '+Math.ceil(item.durability)+'/'+item.maxDurability;detail.appendChild(durability);
  const actions=document.createElement('div');actions.className='pc-item-actions';
  if(equipped)actions.appendChild(button('Unequip',()=>unequipGear(slot),!gearAllowed()));else{actions.appendChild(button(equipReason(item)||'Equip main / slot',()=>equipGear(item),!gearAllowed()||!!equipReason(item)));if(item.dagger&&g.baseClass==='Rogue')actions.appendChild(button('Equip offhand dagger',()=>equipGear(item,'offhand'),!gearAllowed()));actions.appendChild(button(item.protected?'Unprotect':'Protect from salvage',()=>{item.protected=!item.protected;render()}));actions.appendChild(button('Salvage',()=>salvageGear(item),!gearAllowed()||item.protected));if(mode==='merchant')actions.appendChild(button('Sell',()=>sellGear(item)))}
  actions.appendChild(button('Repair · 1 scrap',()=>repairGear(item),!gearAllowed()||g.scrap<1||item.durability>=item.maxDurability));
  if(mode==='merchant'&&equipped)actions.appendChild(button('Upgrade +'+((item.upgrade||0)+1)+' · '+(2*((item.upgrade||0)+1))+' scrap + '+(8*((item.upgrade||0)+1))+' gold',()=>upgradeGear(item),(item.upgrade||0)>=3||g.scrap<2*((item.upgrade||0)+1)||g.gold<8*((item.upgrade||0)+1)));
  detail.appendChild(actions);wrap.appendChild(detail);return wrap;
 }
 for(const slot of gearSlots)slots.appendChild(compactRow(g.equipment[slot],slot,true));
 const bag=$('inventory');bag.replaceChildren();
 const categories=[['Weapons',i=>['weapon','offhand'].includes(i.slot)],['Armor',i=>['head','armor','gloves','boots'].includes(i.slot)],['Accessories',i=>['ring','trinket'].includes(i.slot)],['Camping',i=>i.slot==='camp']];
 for(const [title,filter] of categories){const items=g.inventory.filter(filter);if(!items.length)continue;const group=document.createElement('section');group.className='pc-item-group';group.dataset.inventoryCategory='gear';const heading=document.createElement('h3');heading.textContent=title+' ('+items.length+')';group.appendChild(heading);for(const item of items)group.appendChild(compactRow(item,item.slot,false));bag.appendChild(group)}
 const supplies=document.createElement('section');supplies.className='pc-item-group';supplies.dataset.inventoryCategory='supplies';const sh=document.createElement('h3');sh.textContent='Supplies & materials';supplies.appendChild(sh);const mat=document.createElement('p');mat.className='pc-material-summary';mat.textContent=(g.pinnedRecipe?'Pinned: '+g.pinnedRecipe+' · Missing: '+Object.entries(recipeCost(craftRecipes.find(r=>r.base===g.pinnedRecipe),'basic')).filter(([k,n])=>materialBag()[k]<n).map(([k,n])=>(n-materialBag()[k])+' '+materialNames[k]).join(', ')+' | ':'')+materialKeys.filter(k=>materialBag()[k]).map(k=>materialNames[k]+' ×'+materialBag()[k]).join(' · ')||'No materials';supplies.appendChild(mat);bag.appendChild(supplies);
}

const unlocksList=[['Deep Reserves I (+25 hunger capacity)',8],['Deep Reserves II (+25 hunger capacity)',16],['Deep Reserves III (+25 hunger capacity)',28],['Hardy Bloodline (+8 starting HP)',6],['Provisioner (+1 starting ration)',8],['Guard Training (+1 starting DEF)',10],['Knight',15],['Ranger',20],['Alchemist',25],['Starter Sword',12],['Extra Potion',10],['Lucky Charm',18],['Treasure Vaults',22],['Healing Fountains',18],['Secret Rooms',25]];

// Each specialization has two descendants; mastery continues every 15 levels.
const classRoots={Warrior:['Shield Bash','Guardian','Berserker'],Rogue:['Backstab','Assassin','Trickster'],Mage:['Fireball','Elementalist','Arcanist'],Knight:['Holy Strike','Paladin','Dread Knight'],Ranger:['Piercing Shot','Sharpshooter','Warden'],Alchemist:['Acid Bomb','Bombardier','Apothecary']};
const branches={Guardian:['Juggernaut','Sentinel'],Berserker:['Ravager','Warlord'],Assassin:['Nightblade','Executioner'],Trickster:['Shadow Dancer','Saboteur'],Elementalist:['Pyromancer','Stormcaller'],Arcanist:['Spellweaver','Battlemage'],Paladin:['Dawn Champion','Templar'],'Dread Knight':['Soul Reaver','Deathguard'],Sharpshooter:['Deadeye','Arcane Archer'],Warden:['Beastmaster','Wildguard'],Bombardier:['Demolitionist','Siege Alchemist'],Apothecary:['Plague Doctor','Transmuter']};
const classNodes={};
const bonuses={power:{hp:8,mp:4,atk:5,def:1},guard:{hp:20,mp:4,atk:2,def:4},arcane:{hp:6,mp:18,atk:3,def:1}};
for(const [root,[skill,...children]] of Object.entries(classRoots)){
 const style=['Warrior','Knight'].includes(root)?'guard':['Mage','Alchemist'].includes(root)?'arcane':'power';
 classNodes[root]={root,skill,style,children};
 children.forEach((name,i)=>{
  const branchStyle=i===0?'power':style==='power'?'guard':'arcane';
  classNodes[name]={root,skill:name+' Strike',style:branchStyle,children:branches[name]};
  branches[name].forEach((leaf,j)=>classNodes[leaf]={root,skill:leaf+' Technique',style:j===0?branchStyle:'guard',children:[]});
 });
}
function nextClassLevel(){return 5+15*g.classPath.length}
function classOptions(){if(!g.cls)return Object.keys(classRoots).filter(c=>['Warrior','Rogue','Mage'].includes(c)||unlocks.has(c));return classNodes[g.cls].children.length?classNodes[g.cls].children:['Offensive Mastery','Defensive Mastery','Arcane Mastery']}
function choiceInfo(c){const style=classNodes[c]?.style||({'Offensive Mastery':'power','Defensive Mastery':'guard','Arcane Mastery':'arcane'})[c];const b=bonuses[style];return `+${b.hp} HP · +${b.mp} MP · +${b.atk} ATK · +${b.def} DEF`}
function skillMultiplier(){return (g.baseClass==='Mage'?1.55:1.5)+Math.min(.3,Math.max(0,g.classPath.length-1)*.1)+.025*enhancementRank('class:'+g.cls)}
function renderClassTree(){
 $('classProgress').textContent=(g.classPath.length?g.classPath.map(x=>`Lv ${x.level}: ${x.name}`).join(' → '):'Unclassed')+' · Next choice: level '+nextClassLevel();
 const box=$('classTree');box.replaceChildren();
 for(const [root,node] of Object.entries(classNodes)){
  if(!classRoots[root])continue;
  const branch=document.createElement('div');branch.className='pc-class-path';
  const rootNode=document.createElement('div');rootNode.className='pc-class-root';rootNode.textContent='✦ '+root+' · Lv 5'+(g.baseClass===root?' ✓':'');branch.appendChild(rootNode);
  for(const child of node.children){const lane=document.createElement('div');lane.className='pc-class-lane';const middle=document.createElement('span');middle.className='pc-class-node';middle.textContent='◆ '+child+' · 20';lane.appendChild(middle);for(const leaf of classNodes[child].children){const leafNode=document.createElement('span');leafNode.className='pc-class-node pc-class-leaf';leafNode.textContent='✧ '+leaf+' · 35';lane.appendChild(leafNode)}branch.appendChild(lane)}box.appendChild(branch)
 }
}


const passiveLanes=[
 ['Might','#e99079',[['Force','+2 ATK',{atk:2}],['Precision','+8% critical chance',{crit:.08}],['Heavy Blows','+3 ATK',{atk:3}],['Execution','+12% critical chance',{crit:.12}],['Weapon Master','+5 ATK',{atk:5}],['Glass Cannon','+20% outgoing damage (additive); 20% more incoming damage',{cannon:1}]]],
 ['Resolve','#8acb9e',[['Vitality','+12 maximum HP',{maxhp:12}],['Iron Skin','+2 DEF',{def:2}],['Endurance','+18 maximum HP',{maxhp:18}],['Bulwark','+3 DEF',{def:3}],['Second Wind','Heal 5 HP after each kill',{onKill:5}],['Living Fortress','20% less incoming attack damage; 15% less outgoing attack damage',{fortress:1}]]],
 ['Arcana','#ac9aef',[['Reservoir','+8 maximum MP',{maxmp:8}],['Channeling','+15% spell bonus pool; diminishing returns',{spell:.15}],['Deep Well','+12 maximum MP',{maxmp:12}],['Efficiency','Power Strike and class skills cost 1 less MP; minimum 3 / 4 MP',{discount:1}],['Spellcraft','+25% spell bonus pool; diminishing returns',{spell:.25}],['Overchannel','+25% class-skill damage (additive); class skills cost 3 more MP',{overchannel:1}]]],
 ['Cunning','#e0c478',[['Scavenger','+15% gold from combat',{gold:.15}],['Mechanist','+10% disarm; highlights traps; +20 repair per scrap',{disarm:.1,detect:1,repair:20}],['Fleet Foot','+10% chance to evade enemy attacks',{evade:.1}],['Treasure Sense','+25% gold from combat',{gold:.25}],['Escape Artist','+20% flee chance',{flee:.2}],['Opportunist','+25% critical chance; 10% more incoming attack damage',{crit:.25,fragile:1}]]]
];
const passiveNodes={origin:{name:'Origin',desc:'Your starting point. Connect any branch.',x:390,y:40,links:[],effect:{}}};
passiveLanes.forEach(([lane,color,nodes],i)=>nodes.forEach(([name,desc,effect],j)=>{const id=`p${i}_${j}`;passiveNodes[id]={name,desc,effect,color,x:105+i*190,y:145+j*100,links:[j?`p${i}_${j-1}`:'origin'],keystone:j===5}}));
// Lateral bridges let a build cross into neighboring paths.
for(let i=0;i<3;i++)passiveNodes[`p${i}_2`].links.push(`p${i+1}_2`);
const retiredPassiveNodes=JSON.parse(JSON.stringify(passiveNodes));
for(const id of Object.keys(passiveNodes))delete passiveNodes[id];
passiveNodes.origin={name:'Origin',desc:'Start any route. Connect clusters to combine mechanics.',x:800,y:800,links:[],effect:{}};
const webClusters=[
 ['Might','atk',1,'Force', ['Armor Break','Power attacks strip 2 armor for the rest of combat.',{shred:2}],['Heavy Commitment','Two-handed hits +25%; incoming damage +10%.',{heavy:1}]],
 ['Guard','def',1,'Guard', ['Mana Shield','25% of incoming damage is paid from mana first.',{manaShield:1}],['Living Fortress','20% less damage taken; 15% less damage dealt.',{fortress:1}]],
 ['Arcana','maxmp',3,'Reservoir', ['Efficiency','Class skill mana cost reduced by 1 (minimum 4).',{discount:1}],['Overchannel','Class damage +25%; costs 3 more mana.',{overchannel:1}]],
 ['Cunning','crit',.02,'Precision', ['Twin Fang','Every third attack with two daggers deals +40%.',{twin:1}],['Opportunist','Critical chance +15%; incoming damage +10%.',{crit:.15,fragile:1}]],
 ['Ember','spell',.025,'Kindling', ['Ignition','Class hits burn for 3 damage on each of the next 2 actions.',{ignite:3}],['Ember Investment','Class strikes deal 20% less direct damage; burns deal +6 damage.',{ember:1}]],
 ['Frost','maxhp',3,'Fortitude', ['Chill','Class hits weaken the next enemy attack by 20%.',{chill:1}],['Cold Focus','Chilled targets take +20% damage; critical hits disabled.',{cold:1}]],
 ['Survival','maxhp',3,'Endurance', ['Recuperation','Heal 2 HP on a kill.',{onKill:2}],['Blood Price','Skills may spend missing mana as twice that much HP; never lethal.',{blood:1}]],
 ['Artifice','repair',2,'Tinkering', ['Field Engineer','Basic crafting material costs reduced by 20%.',{craft:1}],['Salvager','Salvage yields +1 primary material; maximum HP reduced by 8.',{salvage:1,maxhp:-8}]]
];
webClusters.forEach(([name,key,value,label,notable,keystone],i)=>{
 const angle=2*Math.PI*i/8,ox=800+Math.cos(angle)*500,oy=800+Math.sin(angle)*500,route='route'+i;
 passiveNodes[route]={name:name+' route',desc:'Connect '+name+' to neighboring clusters. +2 maximum HP.',x:800+Math.cos(angle)*240,y:800+Math.sin(angle)*240,links:['origin','route'+((i+7)%8)],effect:{maxhp:2},cluster:i};
 for(let j=0;j<12;j++){const a=2*Math.PI*j/12,id='w'+i+'_'+j,small=j<7,mastery=j>=8&&j<=10;let effect=small?{[key]:value}:j===7?notable[2]:j===11?keystone[2]:j===8?{maxhp:6}:j===9?{maxmp:5}:{evade:.04};let title=small?name+' · '+label+' '+(j+1):j===7?notable[0]:j===11?keystone[0]:name+' Mastery: '+(['Life','Mana','Evasion'][j-8]);let desc=small?'+'+(['crit','spell'].includes(key)?Math.round(value*100)+'%':value)+' '+key:j===7?notable[1]:j===11?keystone[1]:j===8?'+6 maximum HP. Choose one mastery in this cluster.':j===9?'+5 maximum MP. Choose one mastery in this cluster.':'+4% evasion. Choose one mastery in this cluster.';passiveNodes[id]={name:title,desc,effect,cluster:i,mastery,keystone:j===11,notable:j===7,x:ox+Math.cos(a)*145,y:oy+Math.sin(a)*145,links:[j===0?route:j>=8?'w'+i+'_7':'w'+i+'_'+(j-1)]};}
});
function earnedPoints(level=g.level){return Math.min(70,2*level+3*[5,20,35].filter(n=>level>=n).length)}
function respecCost(){return g.level<5||g.freeRespec?0:5+g.level*2}
function respecPassives(){if(!g||!g.passives.length||!['camp','class','explore'].includes(mode)||g.level>=5&&!g.freeRespec&&mode!=='camp')return false;const cost=respecCost();if(g.gold<cost)return false;g.gold-=cost;for(const id of g.passives){const e=passiveEffect(id);for(const k of ['atk','def','maxhp','maxmp'])g[k]-=e[k]||0;}g.passives=[];g.points=earnedPoints();g.freeRespec=false;g.hp=Math.min(g.hp,healthCap());g.mp=Math.min(g.mp,manaCap());say('Passive points reset. '+g.points+' points available.');render();return true}
function plannedPath(id){const queue=[id],previous=new Map([[id,null]]);let target=null;for(let n=0;n<queue.length;n++){const at=queue[n];if(at==='origin'||g.passives.includes(at)){target=at;break}for(const next of passiveNeighbors(at))if(!previous.has(next)){previous.set(next,at);queue.push(next)}}const result=[];while(target&&target!==id){target=previous.get(target);if(target)result.push(target)}return result;}

const masteryChoices=[
 [['Brute Force','+3 ATK',{atk:3}],['Precision','+5% critical chance',{crit:.05}],['Breach','Power attacks remove 1 additional armor',{shred:1}]],
 [['Vital Guard','+8 maximum HP',{maxhp:8}],['Plating','+2 defense',{def:2}],['Footwork','+4% evasion',{evade:.04}]],
 [['Reserve','+6 maximum MP',{maxmp:6}],['Attunement','+6% spell bonus',{spell:.06}],['Conservation','Skills cost 1 less MP, within cost caps',{discount:1}]],
 [['Lethality','+6% critical chance',{crit:.06}],['Escape','+10% flee chance',{flee:.1}],['Locksmith','+10% disarm chance',{disarm:.1}]],
 [['Lingering Fire','Burn damage +2',{ignite:2}],['Heat','+6% spell bonus',{spell:.06}],['Flashpoint','+4% critical chance',{crit:.04}]],
 [['Deep Chill','Class hits chill the next attack',{chill:1}],['Winterblood','+8 maximum HP',{maxhp:8}],['Ice Step','+4% evasion',{evade:.04}]],
 [['Recovery','Heal 2 HP after a kill',{onKill:2}],['Forager','Improved food drops',{foodFind:.2}],['Resilience','+8 maximum HP',{maxhp:8}]],
 [['Repaircraft','Repairs restore 8 more durability',{repair:8}],['Efficient Design','Basic recipe costs reduced by 20%',{craft:1}],['Reclaimer','+1 primary salvage material',{salvage:1}]]
];
masteryChoices.forEach((choices,i)=>choices.forEach(([name,desc,effect],j)=>Object.assign(passiveNodes['w'+i+'_'+(8+j)],{name:webClusters[i][0]+' Mastery: '+name,desc:desc+'. Choose one mastery in this cluster.',effect})));
let selectedPassive='origin';
function passiveValue(key){return g.passives.reduce((sum,id)=>sum+(passiveEffect(id)[key]||0),0)+(g.relics||[]).reduce((sum,id)=>sum+(relicCatalog.find(r=>r.id===id)?.effect[key]||0),0)}
function passiveNeighbors(id){return Object.keys(passiveNodes).filter(other=>passiveNodes[id].links.includes(other)||passiveNodes[other].links.includes(id))}
function passiveAvailable(id){return id!=='origin'&&!g.passives.includes(id)&&passiveNeighbors(id).some(n=>n==='origin'||g.passives.includes(n))}
function passiveLockReason(id){
 if(!g||g.hp<=0)return 'Start or continue a living hero first.';
 if(!passiveNodes[id])return 'Unknown skill.';
 if(id==='origin'||g.passives.includes(id))return 'Already learned.';
 if(!['explore','class','camp','corpse','stairs','merchant'].includes(mode))return 'Finish this encounter before learning skills.';
 if(!passiveAvailable(id))return 'Learn a connected adjacent skill first.';
 if(passiveNodes[id].mastery&&g.passives.some(k=>passiveNodes[k].mastery&&passiveNodes[k].cluster===passiveNodes[id].cluster))return 'One mastery per cluster; reset to change it.';
 if(g.points<1)return 'Requires 1 skill point. Gain a level to earn one.';
 return '';
}
function allocatePassive(id){const reason=passiveLockReason(id);if(reason){say(reason);return;}g.points--;g.passives.push(id);const e=passiveEffect(id);for(const key of ['atk','def','maxhp','maxmp'])g[key]+=e[key]||0;g.hp=Math.min(g.hp,healthCap());g.mp=Math.min(g.mp,manaCap());say('Passive learned: '+passiveNodes[id].name);render()}
function renderPassives(){
 $('passivePoints').textContent=g.points+' unspent point'+(g.points===1?'':'s')+' · '+g.passives.length+'/24 learned';
 const graph=$('passiveGraph');graph.replaceChildren();
 const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 780 720');svg.setAttribute('aria-hidden','true');
 for(const [id,n] of Object.entries(passiveNodes))for(const other of n.links){const end=passiveNodes[other];if(!end)continue;const line=document.createElementNS('http://www.w3.org/2000/svg','line');line.setAttribute('x1',n.x);line.setAttribute('y1',n.y);line.setAttribute('x2',end.x);line.setAttribute('y2',end.y);line.setAttribute('stroke',g.passives.includes(id)&&(other==='origin'||g.passives.includes(other))?'#e3c580':'#46516a');line.setAttribute('stroke-width','3');svg.appendChild(line)}graph.appendChild(svg);
 for(const [id,n] of Object.entries(passiveNodes)){const owned=id==='origin'||g.passives.includes(id),available=passiveAvailable(id),b=button(({Might:'⚔',Resolve:'⬡',Arcana:'✦',Cunning:'◆'}[passiveLanes[Number(id[1])]?.[0]]||'✧')+' '+(n.keystone?'★':'') ,()=>{selectedPassive=id;renderPassives()});b.title=n.name+' — '+n.desc;b.className='passive-node '+(owned?'allocated':available?'available':'locked')+(n.keystone?' keystone':'')+(selectedPassive===id?' selected':'');b.style.left=n.x+'px';b.style.top=n.y+'px';b.setAttribute('aria-pressed',String(selectedPassive===id));b.setAttribute('aria-label',n.name+'. '+(owned?'Learned':available?'Available':'Locked')+'. '+n.desc);graph.appendChild(b)}
 if(!passiveNodes[selectedPassive])selectedPassive='origin';const n=passiveNodes[selectedPassive],owned=selectedPassive==='origin'||g.passives.includes(selectedPassive);$('passiveDetail').textContent=n.name+(n.keystone?' · KEYSTONE':'')+' · Legacy rank '+enhancementRank('passive:'+selectedPassive)+'/5 — '+n.desc+(enhancementRank('passive:'+selectedPassive)?' Enhanced bonuses: '+Object.entries(passiveEffect(selectedPassive)).map(([key,value])=>({atk:'ATK',def:'DEF',maxhp:'Max HP',maxmp:'Max MP',onKill:'HP per kill',discount:'MP discount'}[key]?({atk:'ATK',def:'DEF',maxhp:'Max HP',maxmp:'Max MP',onKill:'HP per kill',discount:'MP discount'}[key]+' +'+value):['crit','spell','gold','disarm','evade','flee'].includes(key)?key+' +'+Math.round(value*100)+'%':null)).filter(Boolean).join(' · ')+'.':'')+(owned?' · Learned.':passiveAvailable(selectedPassive)?' · Costs 1 point.':' · Connect an adjacent node first.');
 const reason=passiveLockReason(selectedPassive);$('passiveDetail').textContent+=' · '+(reason||'Ready to learn for 1 point.');$('learnPassive').disabled=!!reason;$('learnPassive').title=reason||'Spend 1 skill point';$('learnPassive').onclick=()=>allocatePassive(selectedPassive);
}
function skillCost(){return Math.max(4,7-Math.min(2,passiveValue('discount'))+3*(passiveValue('overchannel')?1:0))}
function canPaySkill(cost){return g.mp>=cost||passiveValue('blood')&&g.hp>2*(cost-g.mp)}
function paySkill(cost){if(!canPaySkill(cost))return false;const mana=Math.min(g.mp,cost);g.mp-=mana;g.hp-=2*(cost-mana);return true}

function powerCost(){return Math.max(3,4-Math.min(1,passiveValue('discount')))}
function resistance(rating,level){return Math.min(.60,Math.max(0,rating)/(Math.max(0,rating)+16+Math.max(1,level)*2))}
function softBonus(value,limit){return limit*Math.max(0,value)/(limit+Math.max(0,value))}
function attackDamage(action){
 const arcane=action==='skill'&&['Mage','Alchemist'].includes(g.baseClass),base=arcane?7+g.level*1.2+softBonus(gearStat('atk'),18)*.65+softBonus(passiveValue('atk'),8)*.25:atk();
 let multiplier=action==='skill'?skillMultiplier():action==='power'?1.45:1;
 const bonus=(g.equipment.weapon?.hands===2&&passiveValue('heavy')?.25:0)+(g.equipment.weapon?.dagger&&g.equipment.offhand?.dagger&&passiveValue('twin')&&g.combatHits%3===0?.4:0)+(enemy.chilled&&passiveValue('cold')?.2:0)+(action==='skill'?softBonus(passiveValue('spell')+gearStat('spell'),.5)+(passiveValue('overchannel')?.25:0):0)+(passiveValue('cannon')?.2:0);
 let damage=(base+R(4))*(action==='skill'&&passiveValue('ember')?.8:1)*multiplier*(1+bonus)*(passiveValue('fortress')?.85:1);
 if(!passiveValue('cold')&&Math.random()<Math.min(.4,passiveValue('crit')+gearStat('crit'))){damage*=1.4;say('Critical hit!');}
 const penetration=Math.min(.35,gearStat('penetration')+(action==='power'?.15:0)),rating=(arcane?(enemy.ward||0):enemy.armor)*(enemy.intent==='guard'?1.5:1);
 damage=Math.max(1,Math.floor(damage*(1-resistance(rating*(1-penetration),g.level))));
 if(enemy.special==='dodge'&&Math.random()<.12){damage=0;say('Enemy dodges!');}
 return damage;
}

const biomes={
 keep:{name:'Forgotten Keep',ceiling:'#141621',horizon:'#414052',floor:'#37313a',wall:[.95,.91,1],accent:'#d2a760',layout:'rooms',extra:['door','chest'],text:'Cold stone passages connect abandoned guardrooms.',foes:[['Cave Rat',19,7,11,0,'','rat'],['Goblin Scout',29,9,17,0,'','goblin'],['Bone Soldier',34,10,21,1,'','skeleton']]},
 sewer:{name:'Sunken Sewers',ceiling:'#0a1714',horizon:'#274b3c',floor:'#123e35',wall:[.65,1,.76],accent:'#76bf84',layout:'loops',extra:['trap','trap','merchant'],text:'Stagnant water laps beneath slick brick tunnels.',foes:[['Plague Rat',26,8,20,0,'','rat'],['Sewer Slime',33,7,23,1,'','slime'],['Bog Troll',46,11,32,2,'rage','troll']]},
 crypt:{name:'Hollow Crypt',ceiling:'#141020',horizon:'#453754',floor:'#292235',wall:[.96,.8,1.15],accent:'#b9a1df',layout:'rooms',extra:['shrine','altar','chest'],text:'Burial vaults branch from corridors lined with ancient bones.',foes:[['Armored Skeleton',38,10,27,3,'','skeleton'],['Crypt Reaver',42,12,32,1,'','reaver'],['Grave Wraith',30,14,34,0,'drain','wraith']]},
 cave:{name:'Deepstone Caverns',ceiling:'#111719',horizon:'#34494b',floor:'#242e30',wall:[.77,.99,1.05],accent:'#87cfd0',layout:'caves',extra:['chest','trap','secret'],text:'Rough chambers open among mineral seams and jagged rock.',foes:[['Cave Spider',29,11,26,0,'dodge','spider'],['Stone Guardian',55,12,45,5,'','golem'],['Crystal Golem',48,14,42,4,'','crystal']]},
 ruins:{name:'Overgrown Ruins',ceiling:'#101b10',horizon:'#38563b',floor:'#283c23',wall:[.74,1.07,.68],accent:'#b0d079',layout:'rooms',extra:['fountain','mystery','trap'],text:'Roots break through fallen halls and moss-covered shrines.',foes:[['Thorn Spider',32,12,29,1,'','spider'],['Goblin Berserker',34,13,30,0,'rage','goblin'],['Root Guardian',54,11,39,3,'','treant']]},
 ice:{name:'Frozen Catacombs',ceiling:'#101c2e',horizon:'#60829a',floor:'#3d5f78',wall:[.83,1.12,1.35],accent:'#c3f5ff',layout:'loops',extra:['trap','chest','shrine'],text:'Frost seals the walls of a winding subterranean tomb.',foes:[['Frost Wraith',32,13,32,0,'drain','wraith'],['Ice Spider',34,12,30,2,'dodge','spider'],['Frost Golem',60,12,44,5,'','crystal']]},
 forge:{name:'Volcanic Forge',ceiling:'#211012',horizon:'#71392c',floor:'#4b241a',wall:[1.22,.74,.58],accent:'#ffac59',layout:'rooms',extra:['trap','merchant','door'],text:'Heat shimmers above furnace channels and scorched workshops.',foes:[['Ember Slime',35,13,31,1,'','slime'],['Iron Golem',65,14,48,6,'','golem'],['Ash Imp',28,16,33,0,'dodge','imp']]},
 abyss:{name:'Abyssal Sanctum',ceiling:'#0c0817',horizon:'#422352',floor:'#221431',wall:[.9,.55,1.25],accent:'#d78aff',layout:'loops',extra:['altar','mystery','shrine'],text:'Fractured sanctuaries echo with whispers from the dark.',foes:[['Shadow Stalker',30,15,34,0,'dodge','stalker'],['Void Acolyte',46,19,55,0,'drain','acolyte'],['Abyss Reaver',52,16,48,3,'rage','reaver']]}
};
function currentBiome(){return biomes[m?.biome]||biomes.keep}
function biomeForFloor(f,previous){if(f===1)return 'keep';const available=f<4?['sewer','crypt','cave']:f<7?['sewer','crypt','cave','ruins','ice']:Object.keys(biomes);return P(available.filter(id=>id!==previous))}
function shapeFloor(map,kind){
 // Carve additional connected spaces into the existing connected maze.
 const count=kind==='rooms'?7:kind==='caves'?14:20;
 for(let i=0;i<count;i++){const [cx,cy]=P(map.cells);if(kind==='loops'){if(cx>1&&cx<17&&cy>1&&cy<17)map.a[cy][cx+1]=0;continue}const radius=kind==='rooms'?1:2;for(let y=cy-radius;y<=cy+radius;y++)for(let x=cx-radius;x<=cx+radius;x++)if(x>0&&y>0&&x<18&&y<18&&(kind==='rooms'||Math.abs(x-cx)+Math.abs(y-cy)<=radius))map.a[y][x]=0}
 map.cells=[];for(let y=1;y<18;y++)for(let x=1;x<18;x++)if(!map.a[y][x]&&x+y>5)map.cells.push([x,y]);
 // Use distance, rather than coordinate sum, to put stairs deep in the layout.
 const queue=[[1,1]],distance=new Map([['1,1',0]]);let far=[1,1];for(let i=0;i<queue.length;i++){const [x,y]=queue[i];far=[x,y];for(const [dx,dy]of D){const X=x+dx,Y=y+dy,key=K(X,Y);if(map.a[Y]?.[X]===0&&!distance.has(key)){distance.set(key,distance.get(K(x,y))+1);queue.push([X,Y])}}}map.exit=far;
}
function makeEnemy(level=g.floor){const f=P(currentBiome().foes),d=Math.max(0,level-1),tough=Math.max(.78,Math.min(1.4,f[1]/38)),offense=Math.max(.85,Math.min(1.18,f[2]/11)),hp=Math.round((26+6*d+.5*d*d)*tough),warded=['wraith','crystal','acolyte','imp'].includes(f[6]);return {n:f[0],hp,maxhp:hp,atk:Math.round((6+1.25*d+.035*d*d)*offense),xp:Math.round(f[3]*(1+d*.18)),armor:Math.round(f[4]*2+d*.7),ward:Math.round((warded?7:1)+d*.65),level,balanceVersion:170,intent:P(['strike','heavy','guard','drain']),special:f[5],model:f[6]}}

function monsterKind(name){const n=name.toLowerCase();if(/mimic/.test(n))return 'mimic';if(/minotaur/.test(n))return 'minotaur';if(/rat/.test(n))return 'rat';if(/spider/.test(n))return 'spider';if(/slime/.test(n))return 'slime';if(/goblin/.test(n))return 'goblin';if(/skeleton|bone/.test(n))return 'skeleton';if(/wraith/.test(n))return 'wraith';if(/root/.test(n))return 'treant';if(/crystal|frost golem/.test(n))return 'crystal';if(/golem|guardian/.test(n))return 'golem';if(/troll/.test(n))return 'troll';if(/imp/.test(n))return 'imp';if(/reaver/.test(n))return 'reaver';if(/acolyte/.test(n))return 'acolyte';return 'stalker'}
function drawMonster(ctx,foe,w,h){
 const kind=monsterKind(foe.n),name=foe.n.toLowerCase(),ice=/ice|frost/.test(name),fire=/ember|ash/.test(name),accent=ice?'#b8f3ff':fire?'#ffae55':currentBiome().accent;
 const body=ice?'#85b8ce':fire?'#c85b35':kind==='goblin'?'#789450':kind==='rat'?'#827466':kind==='treant'?'#706044':kind==='troll'?'#698575':kind==='minotaur'?'#8a593e':kind==='skeleton'?'#d0c7a5':kind==='golem'?(/iron/.test(name)?'#6b7b87':'#7b8382'):'#59456f';
 ctx.save();ctx.translate(w/2,h*.81);const scale=h/440*(foe.boss?1.13:1);ctx.scale(scale,scale);ctx.lineJoin='round';ctx.lineCap='round';ctx.strokeStyle='#171522';ctx.lineWidth=4;
 function ellipse(x,y,rx,ry,color){ctx.fillStyle=color;ctx.beginPath();ctx.ellipse(x,y,rx,ry,0,0,Math.PI*2);ctx.fill();ctx.stroke()}
 function poly(points,color){ctx.fillStyle=color;ctx.beginPath();points.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.closePath();ctx.fill();ctx.stroke()}
 function line(points,color,width){ctx.strokeStyle=color;ctx.lineWidth=width;ctx.beginPath();points.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.stroke();ctx.strokeStyle='#171522';ctx.lineWidth=4}
 function eyes(y= -173,spacing=16){ellipse(-spacing,y,5,4,accent);ellipse(spacing,y,5,4,accent)}
 ellipse(0,4,90,15,'#080a14aa');
 if(kind==='mimic'){
  // Stable procedural variation for each spawned mimic, based on its saved visual seed.
  const seed=Number.isInteger(foe.visualSeed)?foe.visualSeed:137;
  const rand=(n)=>{let v=Math.sin((seed+n*137.31)*12.9898)*43758.5453;return v-Math.floor(v)};
  const wood=['#87512e','#65402b','#82604a','#5b443a'][Math.floor(rand(1)*4)];
  const iron=rand(2)>.65?'#a99e70':'#8996a0',glow=['#f6c45a','#9ef2a4','#eaa5ff','#ff8075'][Math.floor(rand(3)*4)];
  // Four jointed limbs make the chest read as a living creature at combat scale.
  for(const side of [-1,1]){
   line([[side*57,-69],[side*104,-43],[side*112,-7]],iron,11);
   poly([[side*100,-11],[side*123,-11],[side*136,5],[side*92,5]],'#534b46');
   line([[side*46,-31],[side*62,1],[side*71,9]],wood,15);
  }
  poly([[-71,-95],[65,-95],[77,-17],[-75,-17]],wood);
  poly([[-75,-17],[77,-17],[58,-48],[-60,-48]],'#310d20');
  for(let i=0;i<9;i++){const x=-57+i*14;poly([[x,-47],[x+7,-47],[x+3,-28]],'#f5e6c3');poly([[x,-19],[x+7,-19],[x+3,-37]],'#e8d9b8')}
  poly([[-75,-108],[-66,-164],[-40,-188],[47,-188],[69,-165],[78,-108]],wood);
  poly([[-75,-108],[78,-108],[68,-94],[-68,-94]],iron);
  for(const x of [-53,48]){poly([[x-7,-172],[x+8,-172],[x+9,-111],[x-7,-111]],iron)}
  ellipse(-27,-142,12,14,glow);ellipse(29,-142,12,14,glow);
  ellipse(-24,-141,4,8,'#16121b');ellipse(32,-141,4,8,'#16121b');
  poly([[-15,-40],[13,-40],[21,-2],[0,10],[-18,-3]],'#bc4866');
  line([[0,-22],[3,-6],[0,5]],'#e98c9c',3);
  if(rand(4)>.5){for(const x of [-58,57])poly([[x-8,-180],[x,-211],[x+11,-180]],iron)}
  if(rand(5)>.45){for(const x of [-43,44])ellipse(x,-77,6,7,glow)}
 }else if(kind==='rat'){
  line([[48,-35],[104,-12],[124,-36],[113,-60]],'#bb938c',7);ellipse(0,-45,68,40,body);ellipse(-43,-59,33,28,body);ellipse(-55,-85,14,17,'#bb938c');ellipse(-26,-84,13,15,'#bb938c');poly([[-72,-61],[-96,-40],[-65,-32]],body);ellipse(-84,-44,6,5,'#d6a7a8');ellipse(-53,-62,5,5,accent);line([[-67,-43],[-105,-53]],'#d8c9b1',2);line([[-66,-37],[-106,-30]],'#d8c9b1',2);ellipse(-33,-9,20,9,body);ellipse(36,-9,20,9,body);
 }else if(kind==='spider'){
  for(const side of [-1,1])for(let i=0;i<4;i++)line([[side*20,-60-i*7],[side*(85+i*8),-120+i*24],[side*(115+i*6),-22+i*7]],body,9);ellipse(0,-80,47,53,body);ellipse(0,-37,32,27,body);for(const x of [-18,-6,6,18])ellipse(x,-43,4,5,accent);poly([[-16,-22],[-7,-3],[-4,-23]],'#ddd1b5');poly([[16,-22],[7,-3],[4,-23]],'#ddd1b5');
 }else if(kind==='slime'){
  poly([[-83,-5],[-74,-52],[-43,-99],[-5,-119],[39,-106],[70,-70],[87,-12],[46,3],[0,-5],[-42,4]],fire?'#d46a35':'#5f9d78');ellipse(-26,-67,14,20,'#c3f3c266');ellipse(-23,-43,6,6,'#152b27');ellipse(23,-43,6,6,'#152b27');line([[-12,-25],[0,-19],[13,-25]],'#203c35',4);
 }else if(['wraith','acolyte','stalker','reaver'].includes(kind)){
  poly([[-27,-190],[-54,-134],[-81,-10],[-40,-24],[-17,0],[9,-19],[40,-2],[72,-13],[48,-134],[26,-190]],body);poly([[-35,-168],[0,-200],[35,-168],[25,-130],[-25,-130]],'#191724');eyes(-161,13);line([[-47,-128],[-79,-76],[-100,-90]],body,15);line([[46,-126],[78,-77],[95,-108]],body,15);
  if(kind==='reaver'){line([[93,-141],[92,4]],'#9b8063',7);poly([[92,-143],[128,-173],[145,-155],[105,-127]],'#bdc5cf')}
  if(kind==='acolyte'){line([[-99,-180],[-99,4]],'#907359',7);ellipse(-99,-185,13,17,accent)}
 }else{
  const bulky=['golem','crystal','troll','minotaur','treant'].includes(kind),wide=bulky?56:35;
  if(kind==='skeleton'){
   line([[-18,-85],[-30,-42],[-31,-4]],body,12);line([[18,-85],[29,-42],[31,-4]],body,12);line([[0,-156],[0,-79]],body,10);for(let i=0;i<4;i++)line([[-29,-143+i*13],[0,-134+i*13],[29,-143+i*13]],body,7);line([[-30,-147],[-57,-104],[-64,-65]],body,10);line([[30,-147],[59,-107],[64,-66]],body,10);ellipse(0,-177,27,30,body);eyes(-182,11);poly([[-5,-172],[0,-180],[5,-172]],'#222331');if(/armored/.test(name))poly([[-32,-154],[32,-154],[28,-113],[0,-99],[-28,-113]],'#697b8a');
  }else{
   poly([[-wide+8,-88],[-14,-85],[-15,-8],[-55,-6]],body);poly([[14,-85],[wide-8,-88],[55,-6],[15,-8]],body);poly([[-wide,-156],[wide,-156],[wide-7,-78],[-wide+7,-78]],body);line([[-wide,-145],[-wide-28,-109],[-wide-25,-65]],body,bulky?26:17);line([[wide,-145],[wide+28,-108],[wide+24,-63]],body,bulky?26:17);ellipse(0,-183,bulky?38:27,34,body);eyes(-185,15);
   if(kind==='goblin'||kind==='imp'){poly([[-23,-196],[-58,-211],[-31,-173]],body);poly([[23,-196],[58,-211],[31,-173]],body);poly([[-10,-163],[-6,-147],[0,-163]],'#e4d9b2')}
   if(kind==='minotaur'||kind==='imp'){poly([[-26,-205],[-57,-231],[-51,-187],[-31,-184]],'#d8c6a1');poly([[26,-205],[57,-231],[51,-187],[31,-184]],'#d8c6a1');ellipse(0,-163,27,17,body)}
   if(kind==='treant'){for(const side of [-1,1])line([[side*20,-206],[side*39,-236],[side*61,-239]],'#8b7950',9);line([[0,-150],[-10,-111],[4,-82]],'#b6a777',4)}
   if(kind==='crystal'){for(const [x,y]of [[-39,-153],[35,-133],[0,-208]])poly([[x-12,y+15],[x,y-25],[x+15,y+10],[x+2,y+25]],accent)}
   if(kind==='golem'){line([[-30,-145],[-13,-129],[-22,-107]],accent,3);ellipse(0,-120,10,14,accent)}
  }
  if(['goblin','skeleton','minotaur'].includes(kind)){line([[75,-109],[81,-2]],'#b59b71',7);poly([[73,-111],[86,-160],[98,-112]],'#c6ccd2')}
 }
 ctx.restore();ctx.save();ctx.textAlign='center';ctx.font='bold 18px system-ui';ctx.fillStyle='#f4e5c8';ctx.fillText(foe.n,w/2,32);ctx.restore();
}

let campSites=new Set();let saved={};try{saved=JSON.parse(localStorage.getItem('labyrinthLegacyV1')||'{}')||{};if(typeof saved!=='object')saved={}}catch(e){}let legacy=Number(saved.points)||0,unlocks=new Set(saved.unlocks||[]),g,m,seen,events,enemy=null,mode='splash',notes=[],stock=[];
const learnedSkills=new Set(Array.isArray(saved.learnedSkills)?saved.learnedSkills:[]);
const skillEnhancements={};
for(const [id,rank] of Object.entries(saved.skillEnhancements||{}))if(Number.isInteger(rank)&&rank>0)skillEnhancements[id]=Math.min(5,rank);
function enhancementRank(){return 0}
function skillLabel(id){return id.startsWith('passive:')?(passiveNodes[id.slice(8)]||retiredPassiveNodes[id.slice(8)])?.name:classNodes[id.slice(6)]?.skill}
function enhancementCost(id){return 5*((skillEnhancements[id]||0)+1)}
function enhancementDescription(id){if(id.startsWith('class:'))return '+0.025 class-skill multiplier per rank; bounded stacking.';const n=passiveNodes[id.slice(8)];if(n?.keystone)return '+2 ATK and +5 maximum HP per rank; original tradeoff unchanged.';if(n?.effect.discount)return 'Cost reduction caps at 2 MP for class skills (minimum 4 MP), 1 MP for Power Strike (minimum 3 MP).';return 'Each rank adds 20% of the base bonus (whole-number stat gains round up); chance caps still apply.'}
function buyEnhancement(){return false}
function passiveEffect(id){return {...(passiveNodes[id]?.effect||{})}}
function renderEnhancements(){const el=$('legacySkillPanel');el.hidden=true;$('legacySkills').replaceChildren()}
function applyLegacyUnlock(name){
 if(name.startsWith('Deep Reserves')){g.hungerMax+=25;g.hunger+=25}
 else if(name==='Hardy Bloodline (+8 starting HP)'){g.maxhp+=8;g.hp+=8}
 else if(name==='Guard Training (+1 starting DEF)')g.def++;
 else if(name==='Provisioner (+1 starting ration)')g.rations++;
 else if(name==='Extra Potion')g.potions++;
 else if(name==='Starter Sword'&&!g.equipment.weapon){g.equipment.weapon={n:'Starter Sword',slot:'weapon',atk:3};initDurability(g.equipment.weapon)}
 else if(name==='Lucky Charm'&&!g.equipment.trinket){g.equipment.trinket={n:'Lucky Charm',slot:'trinket',def:1};initDurability(g.equipment.trinket)}
}
function renderCharacterBenefits(){
 const panel=$('characterBenefits');if(!panel||!g)return;
 const lines=[];
 lines.push('Current hero · '+g.name+' · '+(g.cls||'Unclassed')+' · Level '+g.level);
 lines.push('Legacy Points available: '+legacy);
 lines.push('Purchased Legacy unlocks: '+([...unlocks].join(', ')||'None'));
 lines.push('Starting/active Legacy effects: '+([
  'Hunger capacity '+hungerCap()+' ('+(hungerCap()-100>=0?'+':'')+(hungerCap()-100)+' from Deep Reserves)',
  unlocks.has('Hardy Bloodline (+8 starting HP)')?'+8 maximum HP (Hardy Bloodline)':'',
  unlocks.has('Guard Training (+1 starting DEF)')?'+1 base DEF (Guard Training)':'',
  unlocks.has('Provisioner (+1 starting ration)')?'+1 starting ration (Provisioner)':'',
  unlocks.has('Extra Potion')?'+1 starting potion':'',
  unlocks.has('Starter Sword')?'Starter Sword unlocked':'',
  unlocks.has('Lucky Charm')?'Lucky Charm unlocked':''].filter(Boolean).join(' · ')));
 lines.push('Learned passives: '+(g.passives.map(id=>passiveNodes[id]?.name||id).join(', ')||'None'));
 lines.push('Class path: '+(g.classPath.map(x=>x.name).join(' → ')||'Not chosen'));
 lines.push('Retired Legacy skill ranks (refunded): '+(Object.entries(g.enhancements||{}).filter(([id,n])=>n>0).map(([id,n])=>(skillLabel(id)||id)+' rank '+n).join(', ')||'None'));
 lines.push('Temporary effects: '+((g.effects||[]).map(e=>e.kind+' ('+e.turns+' turns)').join(', ')||'None'));
 lines.push('Camping gear: '+(g.equipment.camp?.n||'None')+' · '+(g.equipment.camp?Math.ceil(g.equipment.camp.durability||0)+'/'+g.equipment.camp.maxDurability+' durability':'no camping available'));
 lines.push('Equipment bonuses: ATK +'+gearStat('atk')+' · DEF +'+gearStat('def')+' · HP +'+gearStat('life')+' · MP +'+gearStat('mana'));
 lines.push('Current totals: ATK '+atk()+' · DEF '+def()+' · HP '+healthCap()+' · MP '+manaCap());
 panel.textContent=lines.join('\n');
}
let devMode=false,devDensity=100;
const BASE_ENEMIES=8;
const legacyModern=[
 {id:'expedition',name:'Expedition Supplies',desc:'Start each life with +10 / +15 / +20 / +25 / +30 rations by rank.',cap:5,cost:4,step:4},
 {id:'vigor',name:'Enduring Bloodline',desc:'Gain +6 maximum HP at the start of each life per rank.',cap:5,cost:6,step:5},
 {id:'tonic',name:'Emergency Tonics',desc:'Start each life with +1 healing potion per rank.',cap:3,cost:6,step:5},
 {id:'scrap',name:'Salvager Kit',desc:'Start each life with +2 repair scrap per rank.',cap:3,cost:5,step:4},
 {id:'starterArmor',name:'Starter Armor',desc:'Start each life wearing basic armor.',cap:1,cost:5,step:0},{id:'starterBoots',name:'Starter Boots',desc:'Start each life with basic boots.',cap:1,cost:5,step:0},{id:'starterShield',name:'Starter Shield',desc:'Start each life with a basic shield.',cap:1,cost:6,step:0},{id:'mana',name:'Arcane Reserves',desc:'Gain +3 maximum MP at the start of each life per rank.',cap:4,cost:5,step:4}
 ];
 let legacyModernRanks={};try{const x=JSON.parse(localStorage.getItem('pocketCrawLegacyRanksV1')||'{}');if(x&&typeof x==='object')for(const item of legacyModern)legacyModernRanks[item.id]=Math.max(0,Math.min(item.cap,Math.floor(Number(x[item.id])||0)))}catch(e){}
 function applyModernLegacy(){for(const item of legacyModern){const r=legacyModernRanks[item.id]||0;if(item.id==='expedition')g.rations+=[0,10,15,20,25,30][r];else if(['starterArmor','starterBoots','starterShield'].includes(item.id)&&r){const [slot,name,def]=item.id==='starterArmor'?['armor','Starter Leather Armor',2]:item.id==='starterBoots'?['boots','Starter Leather Boots',1]:['offhand','Starter Wooden Shield',1];if(!g.equipment[slot]){g.equipment[slot]={n:name,slot,def,rarity:'Common'};initDurability(g.equipment[slot])}}else if(item.id==='vigor'){g.maxhp+=6*r;g.hp+=6*r}else if(item.id==='tonic')g.potions+=r;else if(item.id==='scrap')g.scrap+=2*r;else if(item.id==='mana'){g.maxmp+=3*r;g.mp+=3*r}}}
 function legacyCatalog(){return {points:legacy,modern:legacyModern.map(i=>({...i,rank:legacyModernRanks[i.id]||0,price:i.cost+i.step*(legacyModernRanks[i.id]||0)})),original:unlocksList.map(([name,cost])=>({name,cost,owned:unlocks.has(name)})),test:devMode}}
 function purchaseLegacy(id){if(devMode)return {ok:false,message:'Legacy spending is disabled in developer test mode.'};const item=legacyModern.find(x=>x.id===id);if(!item)return {ok:false,message:'Unknown upgrade.'};const rank=legacyModernRanks[id]||0,cost=item.cost+rank*item.step;if(rank>=item.cap)return {ok:false,message:'Maximum rank reached.'};if(legacy<cost)return {ok:false,message:'Not enough Legacy Points.'};legacy-=cost;legacyModernRanks[id]=rank+1;try{localStorage.setItem('pocketCrawLegacyRanksV1',JSON.stringify(legacyModernRanks))}catch(e){}if(g&&g.hp>0){if(id==='expedition')g.rations+=[0,10,15,20,25,30][rank+1]-[0,10,15,20,25,30][rank];else if(['starterArmor','starterBoots','starterShield'].includes(id)){const [slot,name,def]=id==='starterArmor'?['armor','Starter Leather Armor',2]:id==='starterBoots'?['boots','Starter Leather Boots',1]:['offhand','Starter Wooden Shield',1];if(!g.equipment[slot]){g.equipment[slot]={n:name,slot,def,rarity:'Common'};initDurability(g.equipment[slot])}}else if(id==='vigor'){g.maxhp+=6;g.hp+=6}else if(id==='tonic')g.potions++;else if(id==='scrap')g.scrap+=2;else if(id==='mana'){g.maxmp+=3;g.mp+=3}}persist();if(g&&g.hp>0){say('Legacy: '+item.name+' rank '+(rank+1));render()}return {ok:true,message:'Purchased '+item.name+' rank '+(rank+1)}}
 globalThis.PocketCrawLegacyCatalog=legacyCatalog;
 globalThis.PocketCrawLegacyPurchase=purchaseLegacy;
 function persist(){if(devMode)return;try{localStorage.setItem('pocketCrawLegacyRanksV1',JSON.stringify(legacyModernRanks));localStorage.setItem('labyrinthLegacyV1',JSON.stringify({progressionVersion:160,points:legacy,unlocks:[...unlocks],learnedSkills:[...learnedSkills],skillEnhancements}))}catch(e){reportError('Legacy save failed',e)}}
function say(s){if(!s)return;notes.unshift('› '+s);notes=notes.slice(0,24);try{document.dispatchEvent(new CustomEvent('pc-event',{detail:String(s)}))}catch(e){}}
function maze(){let a=Array.from({length:19},()=>Array(19).fill(1));function carve(x,y){a[y][x]=0;let ds=[[0,2],[0,-2],[2,0],[-2,0]].sort(()=>Math.random()-.5);for(let [dx,dy] of ds){let X=x+dx,Y=y+dy;if(X>0&&Y>0&&X<18&&Y<18&&a[Y][X]){a[y+dy/2][x+dx/2]=0;carve(X,Y)}}}carve(1,1);let cells=[];for(let y=1;y<18;y++)for(let x=1;x<18;x++)if(!a[y][x]&&x+y>5)cells.push([x,y]);return {a,cells,exit:cells.reduce((p,c)=>c[0]+c[1]>p[0]+p[1]?c:p)}}
function wall(x,y){return !m.a[y]||m.a[y][x]!==0}
function reveal(){for(let y=-2;y<=2;y++)for(let x=-2;x<=2;x++)if(g.x+x>=0&&g.y+y>=0&&g.x+x<19&&g.y+y<19)seen.add(K(g.x+x,g.y+y))}
function generate(biomeOverride=null){distantSpriteCache.clear();campSites=new Set();const previous=m?.biome,biome=typeof biomeOverride==='string'&&biomes[biomeOverride]?biomeOverride:biomeForFloor(g.floor,previous);m=maze();m.biome=biome;shapeFloor(m,['rooms','loops','caves'][g.floor%3]);seen=new Set();events=new Map();g.x=1;g.y=1;g.dir=1;let cells=m.cells.filter(c=>K(...c)!==K(...m.exit)).sort(()=>Math.random()-.5);let types=['chest','chest','merchant','shrine','altar','mystery'];const density=devMode?devDensity:100;const biomeEnemies=currentBiome().extra.filter(t=>t==='enemy').length;const enemyCount=Math.max(1,Math.round((BASE_ENEMIES+biomeEnemies)*density/100));types.unshift(...Array(enemyCount).fill('enemy'));m.monsterDensity=density;m.generatedEnemyCount=enemyCount;types.push('supplies');if(g.floor>=3)types.push('elite');types.push(...currentBiome().extra.filter(t=>t!=='trap'&&t!=='door'&&t!=='enemy'));const trapCount=g.floor<=3?(Math.random()<.2?1:0):Math.min(5,1+Math.floor(g.floor/3));for(let i=0;i<trapCount;i++)types.push('trap');if(g.floor>=4){types.push('door');if(g.floor>=8&&['keep','forge','crypt'].includes(biome))types.push('door')}g.lastMerchantTile=null;g.scouted=null;g.chestTier=null;g.chestLocked=false;if(unlocks.has('Treasure Vaults'))types.push('vault');if(unlocks.has('Healing Fountains'))types.push('fountain');if(unlocks.has('Secret Rooms'))types.push('secret');// Place events apart when the floor has enough space; avoid corridor-long clusters.
const placed=[];for(const t of types){const choices=cells.filter(c=>!events.has(K(...c))&&!placed.some(q=>Math.abs(q[0]-c[0])+Math.abs(q[1]-c[1])<3));const fallback=cells.filter(c=>!events.has(K(...c)));const pool=choices.length?choices:fallback;if(!pool.length)break;const cell=pool[R(pool.length)];events.set(K(...cell),t);placed.push(cell)}
// Each visible enemy tile has a persistent identity. Do not reroll when stepped on.
m.enemyProfiles={};for(const [key,type] of events)if(type==='enemy')m.enemyProfiles[key]=makeEnemy();for(const [key,type]of [...events])if(type==='door'){const [x,y]=key.split(',').map(Number);if(!D.some(([dx,dy])=>wall(x+dx,y+dy))){events.delete(key);const dest=cells.find(([cx,cy])=>!events.has(K(cx,cy))&&D.some(([dx,dy])=>wall(cx+dx,cy+dy)));if(dest)events.set(K(...dest),'door')}}for(const cell of cells.filter(c=>!events.has(K(...c))&&D.filter(([dx,dy])=>wall(c[0]+dx,c[1]+dy)).length>=2).sort(()=>Math.random()-.5).slice(0,Math.max(1,Math.floor(g.floor/4)+1)))campSites.add(K(...cell));m.campSites=[...campSites];prepareStage();reveal();mode='explore';enemy=null}
function newRun(){menuTestSnapshot=null;legacyReturn='explore';workbenchOpen=false;g={equipmentRules27:true,name:P(['Kael','Mira','Vesper','Thorne','Nyx','Rowan'])+' '+P(['Vale','Ash','Stone','Dusk']),race:P(['Human','Elf','Dwarf','Orc']),cls:null,baseClass:null,classPath:[],level:1,xp:0,need:30,hp:34,maxhp:34,mp:12,maxmp:12,atk:6,def:2,gold:0,potions:1+(unlocks.has('Extra Potion')?1:0),floor:1,kills:0,traps:0,chests:0,bosses:0,points:2,passives:[],progressionVersion:160,freeRespec:true,cargo:[],relics:[],pendingRewards:[],damageLog:[],enhancements:{...skillEnhancements},hungerMax:legacyHungerCap(),hunger:legacyHungerCap(),rations:1+(unlocks.has('Provisioner (+1 starting ration)')?1:0),chestKeys:0,scrap:0,merchantPotions:0,merchantRations:0,manaTonics:0,antidotes:0,bandages:0,merchantMana:0,merchantAntidotes:0,merchantBandages:0,effects:[],scouted:null,materials:{},autoEquip:autoEquipPreference(),inventory:[],equipment:Object.fromEntries(gearSlots.map(k=>[k,null])),skill:'Power Strike',lockpicks:{basic:3,fine:0,magic:0}};g.equipment.camp={n:'Basic Bedroll',slot:'camp',rarity:'Common',campTier:0,price:8};if(unlocks.has('Starter Sword'))g.equipment.weapon={n:'Starter Sword',slot:'weapon',atk:3};if(unlocks.has('Lucky Charm'))g.equipment.trinket={n:'Lucky Charm',slot:'trinket',def:1};if(unlocks.has('Hardy Bloodline (+8 starting HP)')){g.maxhp+=8;g.hp+=8}if(unlocks.has('Guard Training (+1 starting DEF)'))g.def++;for(const item of Object.values(g.equipment))if(item)initDurability(item);applyModernLegacy();selectedPassive='origin';notes=[];generate();say('A new adventurer enters the '+currentBiome().name+'. '+currentBiome().text);say('Legacy Hall purchases are now available and will apply to this hero.');render()}
function atk(){const natural=6+g.level-1+g.classPath.reduce((n,c)=>n+(bonuses[classNodes[c.name]?.style||({'Offensive Mastery':'power','Defensive Mastery':'guard','Arcane Mastery':'arcane'})[c.name]]?.atk||0),0);return Math.round(Math.min(g.atk,natural)+softBonus(Math.max(0,g.atk-natural),18)+softBonus(gearStat('atk'),24))}function def(){return g.def+gearStat('def')}
function move(f,s=0){if(mode==='corpse'){g.corpse=null;mode='explore'}if(mode!=='explore')return;let d=D[g.dir],side=D[(g.dir+1)%4],x=g.x+d[0]*f+side[0]*s,y=g.y+d[1]*f+side[1]*s;if(wall(x,y)){say('Solid stone blocks your way.');render();return}if(tickEffects()){render();return}g.x=x;g.y=y;globalThis.PocketCrawAudio?.play('step');reveal();if(hungerStep()){render();return}let k=K(x,y);if(events.has(k)){let t=events.get(k);if(t==='workbench'){events.delete(k);t='supplies'}if(t!=='merchant')events.delete(k);encounter(t)}else if(k===K(...m.exit)){mode='stairs';say('You find a portal arch.')}render()}
function turn(n){if(!canNavigate())return;dismissCorpse();g.dir=(g.dir+n+4)%4;render()}
function encounter(t){mode=t;if(t==='supplies')say('You find '+supplyName().toLowerCase()+'. There may be food inside.');const local={sewer:{merchant:'A drain scavenger offers reclaimed supplies.',fountain:'A filtered cistern holds clean water.'},crypt:{shrine:'A memorial shrine glows between burial slabs.',chest:'An untouched burial coffer lies on the stone.'},cave:{secret:'A mineral pocket glitters in the rock.'},ruins:{secret:'Medicinal roots fill an overgrown recess.',fountain:'Clear water gathers beneath tangled roots.'},ice:{fountain:'A warm spring melts a ring through the frost.'},forge:{secret:'A discarded tool cache contains usable metal.',merchant:'A furnace salvager lays out supplies.'},abyss:{shrine:'A forgotten pact stone hums with power.'}}[m.biome]?.[t];if(local)say(local);if(t==='trap'&&!trapDetection()&&g.scouted!==K(g.x,g.y)){triggerHazard();if(mode!=='dead')mode='explore';return}if(t==='enemy'){enemy=m.enemyProfiles?.[K(g.x,g.y)]||makeEnemy();if(m.enemyProfiles)delete m.enemyProfiles[K(g.x,g.y)];mode='combat';say('A '+enemy.n+' approaches!')}else say(({merchant:'A wandering merchant offers supplies.',trap:'You spot a dangerous mechanism.',chest:'A sealed treasure chest awaits.',shrine:'A strange shrine hums.',altar:'An altar demands a sacrifice.',door:'A locked door blocks an alcove.',mystery:'A stranger offers a wager.',vault:'You find a treasure vault.',fountain:'A healing fountain bubbles.',secret:'A hidden chamber opens.',workbench:'An abandoned crafting workbench is ready to use.'})[t]);if(t==='chest'||t==='vault')prepareChest(t==='vault');if(t==='merchant')visitMerchant()}
function enemyAttack(){if(Math.random()<Math.min(.30,passiveValue('evade')+gearStat('evade'))){g.guarding=false;enemy.chilled=false;enemy.intent=P(['strike','heavy','guard','drain']);say('You evade the attack!');return}let raw=(enemy.atk+R(4))*(g.guarding?.45:1)*(enemy.intent==='heavy'?1.45:enemy.intent==='guard'?.7:1)*(enemy.chilled?.8:1);enemy.chilled=false;g.guarding=false;if(enemy.special==='rage'&&Math.random()<.25)raw*=1.25;if(enemy.intent==='drain'||enemy.special==='drain'&&Math.random()<.3){g.mp=Math.max(0,g.mp-4);say('Your mana is drained!')}let dmg=Math.max(1,Math.floor(raw*(1-resistance(def(),enemy.level||g.floor))*(1+.2*!!passiveValue('cannon')+.1*!!passiveValue('fragile'))*(passiveValue('fortress')?.8:1)));if(passiveValue('manaShield')){const absorb=Math.min(g.mp,Math.floor(dmg*.25));g.mp-=absorb;dmg-=absorb;}dmg=Math.ceil(dmg*(passiveValue('heavy')&&g.equipment.weapon?.hands===2?1.1:1));g.damageLog??=[];g.damageLog.unshift({source:enemy.n,damage:dmg,intent:enemy.intent||'strike'});g.damageLog=g.damageLog.slice(0,8);g.hp=Math.max(0,g.hp-dmg);enemy.intent=P(['strike','strike','heavy','guard','drain']);wearArmor(dmg,enemy.special==='drain'?'arcane':'physical');say(enemy.n+' deals '+dmg+' damage.');if(g.hp===0)die()}

function fight(action){if(mode!=='combat')return;if(action==='ring'){channelRing();return}if((action==='potion'&&!g.potions)||(action==='skill'&&!canPaySkill(skillCost()))||(action==='power'&&!canPaySkill(powerCost())))return;if(tickEffects()){render();return}if(action==='guard'){g.guarding=true;enemyAttack();render();return}if(enemy.burnTurns>0){enemy.hp=Math.max(1,enemy.hp-enemy.burn);enemy.burnTurns--;say('Burn deals '+enemy.burn+' damage.')}if(action==='flee'){if(Math.random()<Math.min(.95,.45+passiveValue('flee'))){enemy=null;mode='explore';say('You escape!');render();return}say('Escape failed!')}else if(action==='potion'){if(!g.potions)return;g.potions--;g.hp=Math.min(healthCap(),g.hp+24);say('You drink a potion.')}else{let cost=action==='power'?powerCost():action==='skill'?skillCost():0;if(!paySkill(cost)){say('Not enough mana or health.');render();return}g.combatHits=(g.combatHits||0)+1;let damage=attackDamage(action);if(action==='power'&&passiveValue('shred'))enemy.armor=Math.max(0,enemy.armor-passiveValue('shred'));if(action==='skill'){if(passiveValue('ignite')||passiveValue('ember')){enemy.burn=passiveValue('ignite')+6*passiveValue('ember');enemy.burnTurns=2;}if(passiveValue('chill'))enemy.chilled=true;}enemy.hp-=damage;wearSlot('gloves',.5);if(g.baseClass==='Rogue'&&g.equipment.offhand?.dagger)wearSlot('offhand',1);wearSlot('weapon',1+Math.floor(damage/25)+(action==='power'?2:action==='skill'?Math.ceil(cost/3):0));if(action==='skill'){if(g.equipment.offhand?.spell||g.equipment.offhand?.mana)wearSlot('offhand',1+Math.ceil(cost/3));if(g.equipment.ring?.spell)wearSlot('ring',1+Math.ceil(cost/4))}say('You deal '+damage+' damage.')}if(enemy.hp<=0){g.kills++;g.xp+=enemy.xp;g.gold+=Math.floor((5+R(12)*g.floor)*(1+passiveValue('gold')));g.hp=Math.min(healthCap(),g.hp+Math.min(6,passiveValue('onKill')));if(Math.random()<.008){g.chestKeys=(g.chestKeys||0)+1;say('Rare drop: universal chest key!')}if(enemy.exitGuardian){m.exitBossDefeated=true;m.exitBoss=null;g.bosses++;queueRewards();g.points=Math.min(earnedPoints()-g.passives.length,g.points+1)}else if(enemy.boss){g.bosses++;queueRewards()}else if(enemy.elite){queueRewards()}else if(enemy.mimic){const item=rollGear(g.floor,2);item.n='Mimic-Touched '+item.n;item.mimicTreasure=true;acquireGear(item);say('Mimic treasure: '+item.rarity+' '+item.n+'!');if(Math.random()<.35){const special=rollGear(g.floor,2);special.n='Mimic Relic '+special.n;acquireGear(special);say('Bonus mimic relic recovered!')}const bonus=8+R(23);g.rations+=bonus;say('Mimic dropped '+bonus+' additional food rations.')}else if(Math.random()<.28)receiveGear();monsterFoodDrop(enemy);if(Math.random()<.20)collectTreasure();if(Math.random()<.30){ensurePicks().basic++;say('Found a basic lockpick.')}say('Victory! '+enemy.xp+' XP earned.');collectCorpse(enemy);enemy=null;mode='explore';levelCheck();render();return}enemyAttack();render()}
function levelCheck(){
 if(g.level>=nextClassLevel()){mode='class';return}
 while(g.xp>=g.need){g.xp-=g.need;g.level++;g.need=Math.floor(g.need*1.35);g.maxhp+=6;g.maxmp+=3;g.atk+=1;g.def+=g.level%2===0?1:0;g.hp=Math.min(healthCap(),g.hp+6);g.mp=Math.min(manaCap(),g.mp+3);g.points=Math.max(0,earnedPoints()-g.passives.length);say('LEVEL UP! Level '+g.level);if(g.level>=nextClassLevel()){mode='class';break}}
}
function classPick(c){
 if(mode!=='class'||g.level<nextClassLevel()||!classOptions().includes(c))return;
 const milestone=nextClassLevel(),node=classNodes[c],style=node?.style||({'Offensive Mastery':'power','Defensive Mastery':'guard','Arcane Mastery':'arcane'})[c],b=bonuses[style];
 const firstClass=!g.baseClass;if(firstClass){g.freeRespec=true;g.points=Math.max(0,earnedPoints()-g.passives.length);}
 if(node){g.cls=c;g.baseClass=node.root;g.skill=node.skill}
 const moved=reconcileEquipment();if(moved)say(moved+' incompatible items moved to inventory.');
 if(firstClass){const kit={Warrior:['Sword','Mail'],Rogue:['Dagger','Leathers'],Mage:['Wand','Robes'],Knight:['Mace','Plate'],Ranger:['Spear','Jerkin'],Alchemist:['Catalyst','Coat']}[g.baseClass];for(const name of kit){const item=makeGear(name,1,0,true);if(!g.equipment[item.slot])g.equipment[item.slot]=item;else g.inventory.push(item)}if(g.baseClass==='Rogue')acquireGear(makeGear('Dagger',1,0,true));}

 g.classPath.push({name:c,level:milestone});g.maxhp+=b.hp;g.maxmp+=b.mp;g.atk+=b.atk;g.def+=b.def;g.hp=healthCap();g.mp=manaCap();mode='explore';say('Class advancement: '+c+'! '+choiceInfo(c));levelCheck();render()
}
const hazards={
 keep:[['Pressure spikes','physical','Bleeding'],['Dart slit','piercing','Poison']],
 sewer:[['Venom seep','poison','Poison'],['Corrosive drain','acid','Burn']],
 crypt:[['Grave seal','necrotic','Curse'],['Bone needles','piercing','Bleeding']],
 cave:[['Loose shale','physical','Bleeding'],['Crystal fissure','arcane','Curse']],
 ruins:[['Thorn snare','piercing','Bleeding'],['Spore patch','poison','Poison']],
 ice:[['Thin ice','cold','Frostbite'],['Frost vent','cold','Frostbite']],
 forge:[['Steam vent','heat','Burn'],['Ember grate','fire','Burn']],
 abyss:[['Void seal','void','Curse'],['Shadow fissure','necrotic','Curse']]
};
function trapDetection(){return g.baseClass==='Rogue'||passiveValue('detect')>0}
function hazardHere(){const list=hazards[m.biome]||hazards.keep;return list[(g.x*7+g.y*3+g.floor)%list.length]}
function triggerHazard(){const [name,type,kind]=hazardHere(),damage=Math.max(2,4+g.floor*2+R(5)-(type==='physical'||type==='piercing'?Math.floor(def()/2):0));g.hp=Math.max(0,g.hp-damage);wearArmor(damage,type);say(name+': '+damage+' '+type+' damage; '+kind+' for 3 actions.');g.effects??=[];g.effects=g.effects.filter(e=>e.kind!==kind);g.effects.push({kind,turns:3,damage:Math.min(8,1+Math.floor(g.floor/3))});if(g.hp===0)die()}
function tickEffects(){g.effects??=[];for(const e of g.effects){g.hp=Math.max(0,g.hp-e.damage);if(e.kind==='Frostbite'||e.kind==='Curse')g.mp=Math.max(0,g.mp-1);e.turns--;say(e.kind+' deals '+e.damage+' damage.')}g.effects=g.effects.filter(e=>e.turns>0);if(g.hp===0){die();return true}return false}
function aheadTrap(){const [dx,dy]=D[g.dir],x=g.x+dx,y=g.y+dy;return events.get(K(x,y))==='trap'?K(x,y):null}
function visibleAhead(maxTiles=5){
 const d=D[g.dir],found=[];
 for(let step=1;step<=maxTiles;step++){
  const x=g.x+d[0]*step,y=g.y+d[1]*step;
  if(wall(x,y))break;
  const type=events.get(K(x,y))||(K(x,y)===K(...m.exit)?'stairs':null);
  if(type)found.push({x,y,type,distance:step});
 }
 return found;
}
function spendInspectHunger(){
 const cost=2;g.hunger=Math.max(0,Math.round((g.hunger-cost)*100)/100);
 say('Inspection costs '+cost+' hunger.');
 autoEatIfNeeded();
 if(g.hunger===0){const damage=Math.ceil(healthCap()*.1);g.hp=Math.max(0,g.hp-damage);say('Starving during inspection: '+damage+' HP lost.');if(!g.hp){die();return false}}
 return true;
}
function inspectFloor(){
 if(mode!=='explore'||!spendInspectHunger()){render();return;}if(campSites.has(K(g.x,g.y)))say('Inspection: This room offers a sheltered camping position. Ambush risk is greatly reduced, but not zero.');
 const [dx,dy]=D[g.dir],x=g.x+dx,y=g.y+dy,k=K(x,y);
 if(wall(x,y)){
  const door=doorFaces().find(d=>d.x===x&&d.y===y&&d.cx===g.x&&d.cy===g.y);
  say(door?'Inspection: A reinforced door is set into the wall ahead. It is locked; search the adjoining passage to reach its lock.':'Inspection: Solid '+currentBiome().name.toLowerCase()+' wall ahead. No opening or visible mechanism.');
 }else{
  const found=visibleAhead(5),first=found[0];
  if(!first)say('Inspection: The passage is clear for the next five tiles, or until the first wall.');
  else if(first.type==='trap'){
   if(first.distance===1){g.scouted=k;say('Inspection: A concealed trap lies directly ahead. Approach to disarm or avoid it.')}
   else say('Inspection: The passage continues ahead. Nothing unusual is visible at this distance.');
  }else{
   const labels={door:'a locked door',enemy:'a hostile creature',merchant:'a wandering merchant',chest:'a treasure chest',supplies:'a supply cache',shrine:'a shrine',altar:'an altar',mystery:'a mysterious stranger',vault:'a treasure vault',fountain:'a fountain',secret:'an unusual recess',workbench:'a crafting workbench',stairs:'a portal arch'};
   say('Inspection: '+(labels[first.type]||'an unusual object')+' '+first.distance+' tile'+(first.distance===1?'':'s')+' ahead.');
  }
 }
 render();
}

function disarm(){if(mode!=='trap')return;if(g.equipment.trinket?.disarm)wearSlot('trinket',1);wearSlot('gloves',.5);if(Math.random()<Math.min(.9,.48+g.level*.045+passiveValue('disarm')+gearStat('disarm')+(g.baseClass==='Rogue'?.25:0))){g.traps++;foodDrop(.65,'Salvaged adventurer supplies');g.gold+=6+R(12);g.scrap+=2;g.xp+=8;say('Trap disarmed; salvage collected.')}else{triggerHazard()}if(mode!=='dead'){mode='explore';levelCheck()}render()}
function chestTier(){return g.chestTier||'Common'}
function migrateChestState(){if(!['chest','vault'].includes(mode))return;if(!['Common','Magic','Rare','Epic'].includes(g.chestTier)){prepareChest(mode==='vault');say('Older chest encounter migrated to the current treasure system.')}else if(typeof g.chestLocked!=='boolean')g.chestLocked=mode==='vault'||g.chestTier==='Epic';}
function canUnlockSpell(){return g.baseClass==='Mage'||g.baseClass==='Alchemist'||(g.classPath||[]).some(x=>/Arcane|Spell|Elemental|Battlemage/.test(x.name))}
function canDetectMimic(){return g.baseClass==='Rogue'||g.baseClass==='Ranger'||passiveValue('detect')>0}
function inspectChest(){
 if(!['chest','vault'].includes(mode)||!spendInspectHunger()){render();return;}
 g.chestInspected=true;
 say('Inspection: '+chestTier()+' chest; '+(g.chestLocked?'the latch is locked.':'the latch is unlocked.'));
 if(g.chestMimic){if(canDetectMimic()){g.mimicKnown=true;say('MIMIC DETECTED: The chest shifts and breathes. You can offer it food or leave.')}else say('Something about the chest seems odd, but you cannot identify it.')}
 else if(g.chestTrapped){if(trapDetection()){g.chestTrapKnown=true;say('TRAP DETECTED: A concealed trigger is attached to the latch.')}else say('The latch has unusual scratches; the danger is uncertain.')}
 else say('No obvious warning signs. Inspection cannot guarantee safety.');
 render();
}
function feedMimic(){
 if(!['chest','vault'].includes(mode)||!g.chestMimic||!g.mimicKnown||g.rations<1)return;
 g.rations--;say('You offer the mimic one ration.');
 if(Math.random()<.5){say('The mimic accepts the ration and becomes docile. You retreat safely; no treasure is awarded.');g.chestMimic=false;g.chestTier=null;mode='explore';render();return}
 spawnMimic(true);
}
function useChestKey(){
 if(!['chest','vault'].includes(mode)||!g.chestLocked||g.chestKeys<1)return;
 g.chestKeys--;g.chestLocked=false;say('Used one universal chest key. The lock opens; any trap or mimic remains dangerous.');render();
}
function prepareChest(vault=false){
 const roll=Math.random(),floor=g.floor;
 g.chestTier=vault?'Epic':roll<Math.min(.06+floor*.009,.22)?'Epic':roll<Math.min(.23+floor*.014,.52)?'Rare':roll<.64?'Magic':'Common';
 g.chestLocked=vault||g.chestTier==='Epic'||g.chestTier==='Rare'&&Math.random()<.7||g.chestTier==='Magic'&&Math.random()<.2;
 g.chestMimic=Math.random()<.035;g.chestTrapped=!g.chestMimic&&Math.random()<Math.min(.12+.025*g.floor,.4);g.chestInspected=false;g.mimicKnown=false;g.chestTrapKnown=false;
 say('A '+g.chestTier+' chest awaits. Its lock and any hidden dangers are unknown until examined.');
}
function pickChance(tier){return Math.min(.96,.42+g.level*.012+passiveValue('disarm')+gearStat('disarm')+(g.baseClass==='Rogue'?.28:0)+tier.bonus)}
function chestPick(type='basic'){const tier=lockpickTiers.find(t=>t.id===type);if(!tier||!g.chestLocked||!['chest','vault'].includes(mode)||!ensurePicks()[type])return;ensurePicks()[type]--;
 const chance=pickChance(tier);
 wearSlot('gloves',.5);
 if(Math.random()<chance){g.chestLocked=false;say(tier.name+' lockpick succeeded (1 consumed).');render();return}
 chestFailure(tier.name+' lockpick broke (1 consumed).');
}
function chestSpell(){
 const cost=5;if(!['chest','vault'].includes(mode)||!canUnlockSpell()||g.mp<cost)return;
 g.mp-=cost;wearSlot('ring',1);
 if(Math.random()<Math.min(.96,.68+gearStat('spell')+g.level*.01)){g.chestLocked=false;say('Unlocking magic opens the chest.');render();return}
 chestFailure('The unlocking spell backfires.');
}
function chestFailure(reason){
 say(reason);
 if(g.chestMimic&&Math.random()<.5){spawnMimic();return}
 if(g.chestTrapped&&Math.random()<.5){const damage=4+g.floor*2+R(5);g.hp=Math.max(0,g.hp-damage);g.chestTrapped=false;say('The lock trap fires: '+damage+' damage.');if(!g.hp)die()}
 else say('The chest remains locked.');render();
}
function disarmChestTrap(){
 if(!['chest','vault'].includes(mode)||!g.chestTrapped||!g.chestTrapKnown)return;
 if(Math.random()<Math.min(.95,.45+g.level*.025+passiveValue('disarm')+gearStat('disarm')+(g.baseClass==='Rogue'?.25:0))){g.chestTrapped=false;g.traps++;say('Chest trap safely disarmed.')}
 else{const damage=4+g.floor*2+R(5);g.hp=Math.max(0,g.hp-damage);g.chestTrapped=false;say('Disarm failed! Trap deals '+damage+' damage.');if(!g.hp)die()}
 render();
}
function spawnMimic(berserk=false){
 const scale=1+Math.max(0,g.floor-1)*.18;
 enemy={n:berserk?'Enraged Treasure Mimic':'Treasure Mimic',hp:Math.round(34*scale*(berserk?1.2:1)),maxhp:Math.round(34*scale*(berserk?1.2:1)),atk:Math.round(9*scale*(berserk?1.25:1)),xp:Math.round(28*scale),armor:1+Math.floor(g.floor/5),special:'rage',model:'mimic',mimic:true,visualSeed:Math.floor(Math.random()*1000000)};
 g.chestTier=null;g.chestLocked=false;mode='combat';say(berserk?'BERSERK MIMIC! The rejected ration enrages it (+25% ATK, +20% HP)!':'MIMIC! The chest unfolds into a hungry monster!');render();
}
function openChest(){
 if(g.chestLocked){say('The '+chestTier()+' chest is locked.');render();return}
 // Danger is rolled when the chest appears, not when it opens.
 if(g.chestMimic){spawnMimic();return}
 if(g.chestTrapped){const damage=4+g.floor*2+R(5);g.hp=Math.max(0,g.hp-damage);say('Hidden chest trap springs! '+damage+' damage.');g.chestTrapped=false;if(!g.hp){die();render();return}}
 loot();
}
function loot(){collectTreasure();if(Math.random()<.42){ensurePicks().basic+=1+R(2);say('Found basic lockpicks (total '+ensurePicks().basic+').')}if(Math.random()<.035){g.chestKeys=(g.chestKeys||0)+1;say('Rare find: universal chest key!')}const tier=chestTier(),ranges={Common:[4,12],Magic:[10,24],Rare:[20,45],Epic:[35,80]},[lo,hi]=ranges[tier]||ranges.Common;const rations=1+R(tier==='Epic'?4:tier==='Rare'?3:2);g.rations+=rations;say(tier+' chest: +'+rations+' food rations (total '+g.rations+').');g.chestTier=null;g.chestLocked=false;let n=12+R(24)*g.floor;g.gold+=n;g.chests++;g.xp+=7;receiveGear();if(Math.random()<.2){g.potions++;say('You discover '+n+' gold and a potion.')}else say('You collect '+n+' gold.');mode='explore';levelCheck();render()}
function usePotion(){if(!g.potions||g.hp>=healthCap())return;g.potions--;g.hp=Math.min(healthCap(),g.hp+24);say('You recover health.');render()}
function descend(){if(m.sideArea){if(['stairs','explore'].includes(mode)&&K(g.x,g.y)===K(...m.exit))leaveSideArea();return}if(!['stairs','explore'].includes(mode)||K(g.x,g.y)!==K(...m.exit))return;if(!m.exitBossDefeated){if(!m.exitBoss)m.exitBoss=makeGuardian();enemy=m.exitBoss;mode='combat';say('The portal guardian bars your way. Retreat preserves its remaining HP.');render();return}if(g.pendingRewards?.length){say('Choose your earned reward before travelling.');openRewards();return}g.floor++;g.hp=Math.min(healthCap(),g.hp+5);g.mp=Math.min(manaCap(),g.mp+4);generate(m.destination);say('Stage '+g.floor+' — '+currentBiome().name);render()}
function makeGuardian(){const level=Math.max(g.floor,g.level),e=makeEnemy(level);e.scaledAtLevel=g.level;e.scaledAtStage=g.floor;e.powerSnapshot=powerEstimate();e.n=currentBiome().name+' Guardian';e.hp=e.maxhp=Math.round(e.maxhp*1.8);e.atk=Math.round(e.atk*1.12);e.xp*=2;e.boss=true;e.exitGuardian=true;e.model='minotaur';e.intent='heavy';return e}
function challengeElite(){if(mode!=='elite')return;enemy=makeEnemy();enemy.hp=enemy.maxhp=Math.round(enemy.maxhp*1.4);enemy.atk=Math.round(enemy.atk*1.15);enemy.xp=Math.round(enemy.xp*1.5);enemy.elite=true;enemy.intent='heavy';mode='combat';render()}

function die(){if(mode==='dead')return;mode='dead';g.earned=Math.max(1,Math.floor(g.kills*1.2+g.traps*2+g.chests*2+g.bosses*12+(g.floor-1)*8+g.gold/15));legacy+=g.earned;persist();say('Your hero falls. '+g.earned+' Legacy Points earned.')}
globalThis.PocketCrawQuickState=()=>({hp:g.potions||0,mp:g.manaTonics||0,food:g.rations||0,canHp:!!g.potions&&g.hp<healthCap(),canMp:!!g.manaTonics&&canUseConsumable('manaTonics'),canFood:!!g.rations&&g.hunger<hungerCap(),mode});
globalThis.PocketCrawQuickUse=kind=>{if(kind==='hp'){if(mode==='combat')fight('potion');else usePotion()}else if(kind==='mp')useConsumable('manaTonics');else if(kind==='food')eat()};
let quickUseOpen=false;
let legacyReturn='explore';
function showLegacy(){if(!g||mode==='legacy')return;legacyReturn=mode;mode='legacy';render()}
function button(t,fn,disabled=false){let b=document.createElement('button');b.textContent=t;b.disabled=disabled;b.onclick=fn;return b}
function renderActions(){let a=$('actions');a.replaceChildren();if(g.pendingRewards?.length&&gearAllowed())a.appendChild(button('Choose earned reward ('+g.pendingRewards.length+')',openRewards));let add=(t,fn,disabled)=>a.appendChild(button(t,fn,disabled));if(mode==='explore'&&K(g.x,g.y)===K(...m.exit)&&(m.exitBossDefeated||m.sideArea))add(m.sideArea?'Return through portal':'Travel onward',descend);$('actionTitle').textContent=mode==='supplies'?supplyName():mode==='trap'?hazardHere()[0]:mode==='fountain'?({sewer:'Filtered cistern',ice:'Warm spring',ruins:'Root spring'}[m.biome]||'Healing fountain'):(encounterRegistry[mode]?.name||mode).toUpperCase();$('description').textContent=mode==='camp'?campPreview():mode==='combat'?enemy.n+' · '+Math.max(0,enemy.hp)+'/'+enemy.maxhp+' HP · ATK '+enemy.atk+' · Armor '+Math.round(resistance(enemy.armor,g.level)*100)+'% · Ward '+Math.round(resistance(enemy.ward||0,g.level)*100)+'% · '+(enemy.special||'normal attacks'):mode==='dead'?'Legacy earned: '+g.earned+' · Total: '+legacy+' · Final hits: '+(g.damageLog||[]).map(x=>x.source+' '+x.damage+' ('+x.intent+')').join('; ')+' · Food '+g.rations+' · MP '+g.mp:mode==='legacy'?'Available Legacy Points: '+legacy+(g.hp<=0?' · Create a new hero before spending.':' · Purchases apply to this hero immediately where applicable.'):mode==='chest'||mode==='vault'?chestTier()+' chest · '+(g.chestInspected?(g.chestLocked?'Locked':'Unlocked'):'Lock unknown')+'. Inspect to investigate traps and mimics; magic requires an eligible class.':mode==='corpse'?'Defeated '+(g.corpse?.n||'enemy')+' · Search the remains once for extra supplies.':mode==='class'?'Level '+nextClassLevel()+': choose your '+(g.cls?'class advancement.':'first class.'):'';
if(mode==='combat'){add('⚔ Attack',()=>fight('attack'));add('🛡 Defend · reduce next hit',()=>fight('guard'));add('💥 Power Strike · '+powerCost()+' MP',()=>fight('power'));if(gearWorks(g.equipment.ring)&&g.equipment.ring.channelHeal)add('Channel ring · 3 MP',()=>fight('ring'),g.mp<3||g.hp>=healthCap());if(g.cls)add('✨ '+g.skill+' · '+skillCost()+' MP',()=>fight('skill'));add('🏃 Flee',()=>fight('flee'))}
else if(mode==='resource'){add('Collect '+biomeSpecials[m.biome].cache,collectBiomeResource);add('Leave',()=>{mode='explore';render()})}
else if(mode==='elite'){add('Challenge elite · stronger enemy, choice of reward',challengeElite);add('Leave',()=>{mode='explore';render()})}
else if(mode==='class'){classOptions().forEach(c=>add(c+' · '+choiceInfo(c),()=>classPick(c)))}
else if(mode==='trap'){add('Avoid trap · no reward',()=>{mode='explore';render()});add('🛠 Disarm',disarm);add('🏃 Risk crossing',()=>{triggerHazard();if(mode!=='dead')mode='explore';render()})}
else if(mode==='merchant'){merchantPanel(a)}
else if(mode==='workbench'){workbenchPanel(a)}
else if(mode==='camp'){if(workbenchOpen){workbenchRecipes(a)}else{add('Rest · 1 ration',rest,g.rations<1||!campData());add('Camp meal · 3 food',campMeal,g.rations<3||g.hp>=healthCap()&&g.mp>=manaCap());add('⚒ Craft',()=>openCrafting());add('Continue exploring',()=>{workbenchOpen=false;mode='explore';render()})}}
else if(mode==='corpse'){if(canScavenge())add('🔎 Scavenge remains',scavengeCorpse);add('Continue',()=>{g.corpse=null;mode='explore';render()})}
else if(mode==='supplies'){add('Investigate supplies',searchSupplies);add('Leave',()=>{mode='explore';render()})}
else if(mode==='chest'||mode==='vault'){add('Inspect chest · 2 hunger',inspectChest);if(g.chestTrapKnown&&g.chestTrapped)add('🛠 Disarm detected chest trap',disarmChestTrap);if(g.mimicKnown)add('🍞 Offer mimic 1 ration · risky',feedMimic,g.rations<1);if(g.chestLocked){for(const tier of lockpickTiers)add('Pick · '+tier.name+' ×'+ensurePicks()[tier.id]+' · '+Math.round(pickChance(tier)*100)+'%',()=>chestPick(tier.id),!ensurePicks()[tier.id]);add('✨ Unlock spell · 5 MP · mage',chestSpell,!canUnlockSpell()||g.mp<5);add('🗝 Universal key · '+(g.chestKeys||0),useChestKey,!g.chestKeys)}else add('Open treasure',()=>{if(mode==='vault')g.gold+=40;openChest()});add('Leave',()=>{mode='explore';render()})}
else if(mode==='shrine'){add('Pray',()=>{let n=R(3);if(n===0){g.hp=healthCap();say('Wounds healed.')}else if(n===1){g.atk+=2;say('Strength increased.')}else{g.hp=Math.max(1,g.hp-9);g.gold+=30;say('Blood exchanged for gold.')}mode='explore';render()});add('Leave',()=>{mode='explore';render()})}
else if(mode==='altar'){add('Sacrifice 10 HP',()=>{if(g.hp<=10)return;g.hp-=10;g.atk+=3;mode='explore';render()});add('Leave',()=>{mode='explore';render()})}
else if(mode==='door'){add('Disarm lock / pick',()=>{if(Math.random()<Math.min(.9,.45+passiveValue('disarm')+gearStat('disarm')+(g.baseClass==='Rogue'?.3:0))){mode='vault';prepareChest(true);say('The lock opens. An Epic treasure vault waits beyond the door.')}else{say('The trapped lock fires!');triggerHazard();if(mode!=='dead')mode='explore'}render()});add('Force · 8 HP',()=>{if(g.hp<=8)return;g.hp-=8;mode='vault';prepareChest(true);say('The door gives way, revealing an Epic treasure vault.');render()},g.hp<=8);add('Leave',()=>{mode='explore';render()})}
else if(mode==='mystery'){add('Wager 15g · win 55g · d100 51–100 wins',playWager,g.gold<15);add('Decline',()=>{mode='explore';render()})}
else if(mode==='fountain'){add('Drink',()=>{g.hp=healthCap();g.mp=manaCap();mode='explore';render()})}
else if(mode==='secret'){if(m.sideEntrance===K(g.x,g.y)){add('Enter '+biomeSpecials[m.biome].side,enterSideArea);add('Leave',()=>{events.set(K(g.x,g.y),'secret');mode='explore';render()});return}add('Search',()=>{g.gold+=45;g.xp+=20;if(m.biome==='cave'){g.mp=Math.min(manaCap(),g.mp+8);say('Resonant minerals restore 8 MP.')}else if(m.biome==='ruins'){g.potions++;say('Medicinal roots yield a potion.')}else if(m.biome==='forge'){g.scrap+=5;say('Recovered 5 scrap from the tool cache.')}mode='explore';levelCheck();render()})}
else if(mode==='stairs'){add(m.sideArea?'Return through portal':m.exitBossDefeated?'Travel onward · Stage '+(g.floor+1):'Challenge portal guardian'+(m.exitBoss?' · '+m.exitBoss.hp+'/'+m.exitBoss.maxhp+' HP':''),descend);if(!m.sideArea){const next=document.createElement('p');next.textContent='Destination: '+(biomes[m.destination]?.name||'Uncharted region');a.append(next)}add('Explore more',()=>{mode='explore';render()})}
else if(mode==='dead'){add('🏛 Spend Legacy & start adventure',()=>{newRun();showLegacy()});add('🔄 New adventure · keep Legacy',newRun);add('⌂ Main menu',()=>{document.getElementById('game').hidden=true;document.getElementById('splash').hidden=false;saveGame();mode='splash'})}
else if(mode==='legacy'){unlocksList.forEach(([n,c])=>add((unlocks.has(n)?'✓ ':'')+n+' · '+c+' LP',()=>{if(g.hp<=0)return;legacy-=c;unlocks.add(n);applyLegacyUnlock(n);persist();say('Unlocked '+n+' for '+g.name+'.');render()},unlocks.has(n)||legacy<c||g.hp<=0));add('Return',()=>{mode=g.hp<=0?'dead':legacyReturn;render()})}
else{add('🔍 Inspect ahead',inspectFloor);add('⛺ Camp · preview recovery',()=>{mode='camp';render()},!g.rations||!campData());

 }}
// Cached, deterministic materials sampled at the world-space ray intersection.
const wallMaterials=new Map();
function wallMaterial(biomeId,variant=0){
 const id=Object.hasOwn(biomes,biomeId)?biomeId:'keep',key=id+':'+variant;if(wallMaterials.has(key))return wallMaterials.get(key);
 const tile=document.createElement('canvas');tile.width=tile.height=128;const c=tile.getContext('2d');
 let seed=97+variant*7919;for(const ch of id)seed=(seed*31+ch.charCodeAt(0))>>>0;
 const rnd=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296};
 const palette={keep:[139,133,122],sewer:[104,105,77],crypt:[119,117,132],cave:[122,116,104],ruins:[119,131,96],ice:[126,185,205],forge:[93,72,65],abyss:[67,49,86]}[id];
 const color=(offset,alpha=1)=>`rgba(${palette.map(v=>Math.max(0,Math.min(255,Math.round(v+offset)))).join(',')},${alpha})`;
 c.fillStyle=color(0);c.fillRect(0,0,128,128);
 // Grain and mineral variation; no repeating horizontal stripe overlay.
 for(let y=0;y<128;y+=2)for(let x=0;x<128;x+=2){const wave=Math.sin(x*.11+Math.sin(y*.08)*2)*5;c.fillStyle=color((rnd()-.5)*30+wave);c.fillRect(x,y,2,2)}
 function stroke(points,col,width){c.strokeStyle=col;c.lineWidth=width;c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.stroke()}
 if(['keep','sewer','crypt','ruins','forge'].includes(id)){
  const rowHeight=id==='sewer'?16:id==='crypt'?32: id==='forge'?32:32,blockWidth=id==='sewer'?32:id==='crypt'?64:64;
  for(let row=0;row<128/rowHeight;row++){
   const offset=(row%2)*blockWidth/2;
   for(let x=-blockWidth;x<128;x+=blockWidth){const left=x+offset,y=row*rowHeight;c.fillStyle=color((rnd()-.5)*22,.45);c.fillRect(left+2,y+2,blockWidth-3,rowHeight-3);stroke([[left,y+rowHeight],[left,y],[left+blockWidth,y]],'#272b29',2);stroke([[left+2,y+rowHeight-2],[left+2,y+2],[left+blockWidth-2,y+2]],color(35,.5),1)}
  }
 }
 if(id==='cave'||id==='abyss'){
  // Irregular facets and branching fissures, rather than constructed brickwork.
  for(let i=0;i<24;i++){const x=rnd()*128,y=rnd()*128;c.fillStyle=color((rnd()-.5)*45,.38);c.beginPath();c.moveTo(x,y);c.lineTo(x+12+rnd()*20,y-6);c.lineTo(x+20,y+20);c.lineTo(x-8,y+26);c.closePath();c.fill();stroke([[x-8,y+26],[x,y],[x+12,y-6]],color(-43,.7),1.5)}
 }
 if(id==='keep'||id==='crypt'||id==='ruins')for(let i=0;i<6;i++){const x=rnd()*128,y=rnd()*128;stroke([[x,y],[x+3,y+7],[x-2,y+12],[x+6,y+19]],'#33332f99',1)}
 if(id==='sewer'||id==='ruins'){
  for(let i=0;i<65;i++){const x=rnd()*128,y=rnd()*128;c.fillStyle=id==='sewer'?'#30462b77':'#456b2b99';c.beginPath();c.ellipse(x,y,2+rnd()*9,1+rnd()*6,0,0,Math.PI*2);c.fill()}
  if(id==='sewer')for(let i=0;i<10;i++){const x=rnd()*128;stroke([[x,0],[x+2,22+rnd()*65]],'#b3d1ad33',1)}
  else for(let i=0;i<3;i++){const x=rnd()*128;stroke([[x,0],[x+7,27],[x-4,58],[x+8,95],[x+5,128]],'#51432c',4);stroke([[x-4,58],[x-20,73],[x-28,90]],'#766342',2)}
 }
 if(id==='crypt'){
  // Inset burial plaques with shallow inscriptions.
  c.fillStyle='#53505e';c.fillRect(43,39,39,48);c.strokeStyle='#b4adbd';c.lineWidth=1;c.strokeRect(45,41,35,44);for(let y=51;y<79;y+=7)stroke([[51,y],[73-(y%3)*3,y]],'#a6a0af',1);
 }
 if(id==='ice'){
  for(let i=0;i<14;i++){const x=rnd()*128,y=rnd()*128;stroke([[x-8,y-25],[x+2,y],[x-3,y+16],[x+12,y+38]],'#e0faff99',2);stroke([[x+2,y],[x+19,y-9]],'#a1e6ff99',1)}
  for(let i=0;i<40;i++){const x=rnd()*128,y=rnd()*128;c.fillStyle='#e1f9ff88';c.fillRect(x,y,2,2)}
 }
 if(id==='forge'||id==='abyss'){
  const col=id==='forge'?'#ef772d':'#a971dc';for(let i=0;i<3;i++){const x=rnd()*128,y=rnd()*96,pts=[[x,y],[x+7,y+12],[x-3,y+23],[x+6,y+39]];stroke(pts,id==='forge'?'#6e2818':'#392247',6);stroke(pts,col,1.5)}
  if(id==='abyss'){stroke([[52,28],[73,42],[52,59],[52,28],[66,70]],'#bd8ce2',2);stroke([[46,82],[76,82]],'#9166b9',1)}
 }
 wallMaterials.set(key,tile);return tile;
}


const facingNames=['North','East','South','West'];
function doorFaces(){
 if(!Array.isArray(m.doorFaces))m.doorFaces=[];
 const candidates=[...events].filter(([key,type])=>type==='door').map(([key])=>key.split(',').map(Number));
 if(mode==='door')candidates.push([g.x,g.y]);
 for(const [x,y]of candidates){if(m.doorFaces.some(d=>d.cx===x&&d.cy===y))continue;for(let dir=0;dir<4;dir++){const [dx,dy]=D[dir];if(wall(x+dx,y+dy)){m.doorFaces.push({x:x+dx,y:y+dy,cx:x,cy:y,dir});break}}}
 return m.doorFaces;
}
const doorTiles=new Map();
function doorMaterial(id){if(doorTiles.has(id))return doorTiles.get(id);const c=document.createElement('canvas');c.width=c.height=128;const t=c.getContext('2d');t.drawImage(wallMaterial(id,0),0,0);
 t.fillStyle='#171412';t.fillRect(17,5,94,123);t.fillStyle='#a2947a';t.fillRect(17,5,9,123);t.fillRect(102,5,9,123);t.fillRect(17,5,94,9);
 t.fillStyle='#67472d';t.fillRect(26,14,76,114);for(let x=27;x<102;x+=13){t.fillStyle=(x%2)?'#825b37':'#725032';t.fillRect(x,15,11,112);t.fillStyle='#332316';t.fillRect(x+11,15,2,112)}
 for(const y of [32,91]){t.fillStyle='#30343b';t.fillRect(26,y,76,8);t.fillStyle='#b3b6b9';for(const x of [31,94])t.fillRect(x,y+2,3,3)}t.fillStyle='#dbb961';t.fillRect(83,62,9,13);t.fillStyle='#191715';t.fillRect(86,66,3,6);doorTiles.set(id,c);return c;
}
function drawHeading(ctx,w){ctx.save();ctx.fillStyle='#211b14eb';ctx.fillRect(w/2-135,7,270,30);ctx.font='bold 18px system-ui';ctx.textAlign='center';ctx.fillStyle='#ffe3a0';ctx.fillText('Facing '+facingNames[g.dir]+' · '+g.x+','+g.y,w/2,28);ctx.restore();const el=document.getElementById('heading');if(el)el.textContent='Facing '+facingNames[g.dir]+' · Map north stays up';for(const [id,blocked] of Object.entries({up:wall(g.x+D[g.dir][0],g.y+D[g.dir][1]),down:wall(g.x-D[g.dir][0],g.y-D[g.dir][1])})){const b=document.getElementById('view-'+id);if(b)b.disabled=!canNavigate()||blocked}for(const id of ['left','right','sl','sr']){const b=document.getElementById('view-'+id);if(b)b.disabled=!canNavigate()}}

// A recessed pressure plate projected onto the floor beneath the player's view.
function drawFloorTrap(ctx,w,h){
 const detected=trapDetection(),known=detected||g.scouted===aheadTrap()&&!!aheadTrap()||mode==='trap';
 ctx.save();ctx.lineWidth=Math.max(1,w/450);ctx.strokeStyle=detected?'#ffe28a':known?'#aaa58b':'#141a1b';ctx.globalAlpha=detected?.95:known?.6:.23;
 const points=[[w*.43,h*.72],[w*.57,h*.72],[w*.64,h*.91],[w*.36,h*.91]];
 ctx.beginPath();points.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.closePath();ctx.stroke();
 for(let i=0;i<5;i++){const x=w*(.43+i*.035);ctx.beginPath();ctx.moveTo(x,h*.81);ctx.lineTo(x+w*.015,h*.82);ctx.stroke()}
 if(detected){ctx.globalAlpha=1;ctx.fillStyle='#ffe28a';ctx.textAlign='center';ctx.font='bold '+Math.max(12,h*.025)+'px system-ui';ctx.fillText('DETECTED TRAP',w/2,h*.69)}
 ctx.restore();
}
function drawEncounter(ctx,type,w,h){if(type==='resource')type='supplies';
 if(!['supplies','chest','vault','trap','merchant','mystery','shrine','altar','fountain','stairs','secret','workbench','dead'].includes(type))return;
 if(type==='trap'){drawFloorTrap(ctx,w,h);return}
 ctx.save();ctx.translate(w/2,h*.82);ctx.scale(h/440,h/440);ctx.lineWidth=3;ctx.strokeStyle='#17151a';ctx.lineJoin='round';
 const accent=currentBiome().accent;
 function poly(points,color){ctx.fillStyle=color;ctx.beginPath();points.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y));ctx.closePath();ctx.fill();ctx.stroke()}
 function box(x,y,w,h,color){ctx.fillStyle=color;ctx.fillRect(x,y,w,h);ctx.strokeRect(x,y,w,h)}
 function oval(x,y,rx,ry,color){ctx.fillStyle=color;ctx.beginPath();ctx.ellipse(x,y,rx,ry,0,0,Math.PI*2);ctx.fill();ctx.stroke()}
 oval(0,5,110,19,'#080a14b0');
 if(type==='supplies'){
  poly([[-100,6],[-67,-14],[-31,-4],[7,-21],[70,-12],[101,9]],'#44413a');
  poly([[-40,5],[-48,-43],[-28,-63],[23,-62],[47,-38],[39,7]],'#6d624b');
  poly([[-48,-43],[47,-38],[31,-18],[-32,-23]],'#99876a');
  box(-9,-57,12,63,'#4e4434');box(-12,-24,18,12,'#b4a17b');
  poly([[53,9],[51,-16],[87,-25],[96,0]],'#79634b');
 }else if(type==='chest'||type==='vault'||type==='secret'){
  const gold=type==='vault',wood=gold?'#78552b':'#865332',metal=gold?'#ecc65d':'#89919b';
  poly([[-85,-70],[65,-70],[88,-90],[-61,-90]],'#ad7847');poly([[65,-70],[88,-90],[88,-12],[65,8]],'#51351f');box(-85,-70,150,78,wood);
  poly([[-85,-70],[-85,-95],[-69,-116],[49,-116],[65,-95],[65,-70]],'#a77342');
  for(const x of [-58,31]){box(x,-113,12,121,metal)}for(const y of [-63,-8])box(-85,y,150,7,metal);
  for(const x of [-51,38])for(const y of [-104,-76,-48,-17])oval(x,y,2,2,'#e0d7b8');
  box(-17,-65,25,30,metal);oval(-5,-53,4,4,'#28272a');box(-7,-52,4,10,'#28272a');
  if(gold){poly([[-5,-105],[5,-95],[-5,-85],[-15,-95]],accent);for(const x of [-110,104])oval(x,-4,10,5,'#e5bf51')}
 }else if(type==='stairs'){
  const active=m.exitBossDefeated||m.sideArea,glow=biomes[m.destination]?.accent||accent;
  ctx.fillStyle=active?glow:'#18202d';ctx.globalAlpha=active?.55:1;ctx.beginPath();ctx.moveTo(-60,0);ctx.lineTo(-60,-125);ctx.bezierCurveTo(-60,-215,60,-215,60,-125);ctx.lineTo(60,0);ctx.closePath();ctx.fill();ctx.globalAlpha=1;
  ctx.lineWidth=22;ctx.strokeStyle='#65707d';ctx.beginPath();ctx.moveTo(-77,5);ctx.lineTo(-77,-125);ctx.bezierCurveTo(-77,-240,77,-240,77,-125);ctx.lineTo(77,5);ctx.stroke();ctx.lineWidth=4;ctx.strokeStyle=active?glow:'#384451';ctx.stroke();
  for(const x of [-77,77])for(let y=-20;y>=-120;y-=28){ctx.fillStyle=active?glow:'#9297a0';ctx.fillRect(x-5,y,10,10)}box(-97,0,194,14,'#555d69');if(active){ctx.strokeStyle='#ecffff';ctx.lineWidth=2;for(let i=0;i<3;i++){ctx.beginPath();ctx.ellipse(0,-95,25+i*10,45+i*12,.3,0,Math.PI*2);ctx.stroke()}}
 }else if(type==='fountain'){
  box(-23,-115,46,95,'#757f8c');oval(0,-120,44,13,'#b0bdc8');oval(0,-13,91,33,'#8997a3');oval(0,-20,76,22,'#286b88');oval(0,-22,59,12,'#65cbdc');ctx.strokeStyle='#a8eff5';ctx.beginPath();ctx.moveTo(0,-116);ctx.quadraticCurveTo(-56,-85,-58,-23);ctx.moveTo(5,-116);ctx.quadraticCurveTo(52,-79,53,-23);ctx.stroke();
 }else if(type==='shrine'||type==='altar'){
  box(-68,-16,136,23,'#5e616c');poly([[-50,-16],[50,-16],[34,-85],[-34,-85]],'#84818a');box(-67,-94,134,18,'#ada3a0');
  if(type==='shrine')poly([[0,-167],[27,-132],[0,-102],[-27,-132]],accent);else{box(-32,-113,64,17,'#662932');for(const x of [-50,50]){box(x-4,-119,8,25,'#e7cea0');oval(x,-125,4,8,'#ffbd62')}}
 }else if(type==='workbench'){
  box(-101,-61,202,19,'#795736');box(-90,-42,15,51,'#584330');box(75,-42,15,51,'#584330');
  box(-62,-104,92,43,'#47505b');box(-56,-99,80,32,'#798b97');
  poly([[34,-67],[48,-134],[61,-134],[68,-67]],'#8a9298');
  box(29,-73,50,12,'#b4a16f');oval(-71,-62,18,9,'#b3a16c');
 }else if(type==='merchant'||type==='mystery'){
  poly([[-45,-13],[-34,-133],[30,-133],[49,-13]],type==='merchant'?'#637653':'#6a587a');oval(0,-156,24,29,'#b98b66');poly([[-31,-164],[0,-203],[34,-164]],'#6a7958');box(-78,-58,156,45,'#845b35');for(const x of [-55,0,51]){box(x-8,-84,16,25,'#81a3b7');box(x-4,-91,8,7,'#c5b28c')}box(-68,-13,10,20,'#51402b');box(58,-13,10,20,'#51402b');
 }else if(type==='dead'){
  poly([[-48,4],[-41,-88],[-25,-110],[25,-110],[41,-88],[48,4]],'#78808a');box(-5,-88,10,64,'#252c38');box(-24,-72,48,10,'#252c38');
 }
 ctx.restore();
}

function drawFloor(ctx,w,h,horizon){
 const palette={keep:['#49434a','#39343a'],sewer:['#29473b','#19372f'],crypt:['#3b3444','#302838'],cave:['#404547','#303638'],ruins:['#3b4930','#293922'],ice:['#638394','#476b80'],forge:['#50392e','#352b28'],abyss:['#3e294c','#291c36']}[m.biome]||['#444','#333'];
 const angle=g.dir*Math.PI/2-Math.PI/2,dx=Math.cos(angle),dy=Math.sin(angle),step=6;
 for(let y=Math.max(0,Math.floor(horizon)+1);y<h;y+=step){const depth=h/(1.5*(y-horizon));
 for(let x=0;x<w;x+=step){const side=(x/w*2-1)*.68,wx=g.x+.5+depth*(dx-dy*side),wy=g.y+.5+depth*(dy+dx*side),u=wx-Math.floor(wx),v=wy-Math.floor(wy),noise=Math.sin(Math.floor(wx*37)*12.98+Math.floor(wy*37)*78.23)*43758.5;
 ctx.fillStyle=palette[(Math.floor(wx)+Math.floor(wy))&1];ctx.fillRect(x,y,step,step);
 ctx.fillStyle=(u<.035||v<.035)?'#080b1266':noise-Math.floor(noise)<.22?'#ffffff09':'#00000008';ctx.fillRect(x,y,step,step);
 if(m.biome==='ice'&&Math.abs(u-v)<.025||m.biome==='forge'&&v<.02||m.biome==='ruins'&&u<.08){ctx.fillStyle=currentBiome().accent+'45';ctx.fillRect(x,y,step,step)}
 }}
}
// Perspective sprites use the existing procedural encounter and monster renderers.
// Render to transparent offscreen canvases, then clip each vertical slice against
// the wall depth buffer. No event is consumed until the player reaches its tile.
const distantSpriteCache=new Map();
function distantSprite(type,w,h,profileKey=''){
 if(type==='enemy'&&profileKey)type='enemy:'+profileKey;
 const key=type+'|'+m.biome+'|'+g.floor+'|'+w+'x'+h;
 if(distantSpriteCache.has(key))return distantSpriteCache.get(key);
 const canvas=document.createElement('canvas');const scale=Math.min(1,512/Math.max(w,h));canvas.width=Math.max(1,Math.round(w*scale));canvas.height=Math.max(1,Math.round(h*scale));
 const cx=canvas.getContext('2d');cx.scale(scale,scale);
 if(type.startsWith('enemy:')){
  m.enemyProfiles??={};const foe=m.enemyProfiles[type.slice(6)]??=makeEnemy();drawMonster(cx,foe,w,h);
 }else drawEncounter(cx,type==='workbench'?'workbench':type,w,h);
 distantSpriteCache.set(key,canvas);
 if(distantSpriteCache.size>32)distantSpriteCache.delete(distantSpriteCache.keys().next().value);
 return canvas;
}
function clearSight(x,y){let ax=g.x+.5,ay=g.y+.5,bx=x+.5,by=y+.5,steps=Math.ceil(Math.hypot(bx-ax,by-ay)*16);for(let i=1;i<steps;i++){let t=i/steps;if(wall(Math.floor(ax+(bx-ax)*t),Math.floor(ay+(by-ay)*t)))return false}return true}
function drawDistantEncounters(ctx,w,h,wallDepth){
 const forward=D[g.dir],right=D[(g.dir+1)%4],visible=[];
 for(const [key,type] of events){
  if(type==='trap'||type==='secret')continue; // concealed features remain concealed
  const [x,y]=key.split(',').map(Number),dx=x-g.x,dy=y-g.y;
  const depth=dx*forward[0]+dy*forward[1],side=dx*right[0]+dy*right[1];
  if(depth<.55||depth>5.5||Math.abs(side)>depth*.8+.4||!clearSight(x,y))continue;
  visible.push({type,depth,side,key});
 }
 const dx=m.exit[0]-g.x,dy=m.exit[1]-g.y;
 const exitDepth=dx*forward[0]+dy*forward[1],exitSide=dx*right[0]+dy*right[1];
 if(exitDepth>.55&&exitDepth<=5.5&&Math.abs(exitSide)<=exitDepth*.8+.4&&clearSight(m.exit[0],m.exit[1]))visible.push({type:'stairs',depth:exitDepth,side:exitSide});
 visible.sort((a,b)=>b.depth-a.depth);
 for(const e of visible){
  const projectedX=w/2+(e.side/e.depth)*(w/.68/2);
  const scale=1/Math.max(.9,e.depth),spriteW=w*scale,spriteH=h*scale;
  const left=projectedX-spriteW/2,top=h*.5+h/(1.5*e.depth)-spriteH*.94;
  if(left>w||left+spriteW<0)continue;
  const img=distantSprite(e.type,w,h,e.key),start=Math.max(0,Math.floor(left)),end=Math.min(w,Math.ceil(left+spriteW));
  ctx.save();ctx.globalAlpha=Math.max(.48,1-e.depth*.065);
  for(let sx=start;sx<end;sx+=2){
   // Correct for perspective at this screen column, using the wall ray depth.
   const centerDist=Math.hypot(e.depth,e.side);
   if(wallDepth[Math.min(w-1,sx)]<centerDist-.3)continue;
   const srcX=(sx-left)/spriteW*img.width,srcWidth=Math.min(img.width-srcX,2/spriteW*img.width);
   if(srcWidth>0)ctx.drawImage(img,srcX,0,srcWidth,img.height,sx,top,2,spriteH);
  }
  ctx.restore();
 }
}
function drawView(){let c=$('view'),ctx=c.getContext('2d'),w=c.width,h=c.height,gr=ctx.createLinearGradient(0,0,0,h);const biome=currentBiome(),doors=doorFaces(),lookingDown=false,encounterFraming=mode!=='explore'&&mode!=='legacy'?1.5:0;gr.addColorStop(0,biome.ceiling);gr.addColorStop(.49,biome.horizon);gr.addColorStop(.5,biome.floor);gr.addColorStop(1,'#0c0d15');ctx.fillStyle=lookingDown?biome.floor:gr;ctx.fillRect(0,0,w,h);drawFloor(ctx,w,h,h*.5-(lookingDown?h*1.25:0));let angle=g.dir*Math.PI/2-Math.PI/2;const wallDepth=new Float32Array(w);wallDepth.fill(999);for(let i=0;i<360;i++){let ray=angle+Math.atan((i/180-1)*.68),dx=Math.cos(ray),dy=Math.sin(ray),px=g.x+.5,py=g.y+.5,mx=Math.floor(px),my=Math.floor(py),ddx=Math.abs(1/dx),ddy=Math.abs(1/dy),sx=dx<0?-1:1,sy=dy<0?-1:1,tx=(dx<0?px-mx:mx+1-px)*ddx,ty=(dy<0?py-my:my+1-py)*ddy,side=0;for(let k=0;k<64;k++){if(tx<ty){tx+=ddx;mx+=sx;side=0}else{ty+=ddy;my+=sy;side=1}if(wall(mx,my))break}const rayDistance=side?ty-ddy:tx-ddx;for(let col=Math.floor(i*w/360);col<Math.min(w,Math.ceil((i+1)*w/360));col++)wallDepth[col]=rayDistance;const dist=Math.max(.15,(rayDistance+encounterFraming)*Math.cos(ray-angle)),hh=h/(dist*.75),top=(h-hh)/2-(lookingDown?h*1.25:0);
 const hit=side?px+rayDistance*dx:py+rayDistance*dy;let u=hit-Math.floor(hit);if((!side&&dx>0)||(side&&dy<0))u=1-u;
 const variant=((mx*13+my*7)%3+3)%3,texture=doors.some(d=>d.x===mx&&d.y===my&&(side?d.cx===mx&&((dy>0&&d.cy===my-1)||(dy<0&&d.cy===my+1)):d.cy===my&&((dx>0&&d.cx===mx-1)||(dx<0&&d.cx===mx+1))))?doorMaterial(m.biome):wallMaterial(m.biome,variant),screenX=i*w/360,sliceWidth=Math.ceil(w/360);
 ctx.drawImage(texture,Math.min(texture.width-1,Math.floor(u*texture.width)),0,1,texture.height,screenX,top,sliceWidth,hh);
 const shade=Math.min(.88,.12+dist*.075+(side?.16:0));ctx.fillStyle=`rgba(4,7,13,${shade})`;ctx.fillRect(screenX,top,sliceWidth,hh);
 }if(mode==='explore')drawDistantEncounters(ctx,w,h,wallDepth);if(mode==='explore'&&aheadTrap())drawFloorTrap(ctx,w,h);drawEncounter(ctx,mode==='legacy'?legacyReturn:mode,w,h);if(enemy&&(mode==='combat'||mode==='legacy'&&legacyReturn==='combat'))drawMonster(ctx,enemy,w,h);ctx.strokeStyle=biome.accent;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(w/2-8,h/2);ctx.lineTo(w/2+8,h/2);ctx.moveTo(w/2,h/2-8);ctx.lineTo(w/2,h/2+8);ctx.stroke();drawHeading(ctx,w)}
const MAP_ZOOMS=[7,9,11,15,19];
let mapZoomIndex=2;
try{const z=Number(localStorage.getItem('pocketCrawMapZoom'));if(Number.isInteger(z)&&z>=0&&z<MAP_ZOOMS.length)mapZoomIndex=z}catch(e){}
function mapZoom(delta){mapZoomIndex=Math.max(0,Math.min(MAP_ZOOMS.length-1,mapZoomIndex+delta));try{localStorage.setItem('pocketCrawMapZoom',String(mapZoomIndex))}catch(e){}drawMap();return MAP_ZOOMS[mapZoomIndex]}
globalThis.PocketCrawMapZoom=mapZoom;
const encounterRegistry={stairs:{name:'Portal arch',icon:'Ω'},enemy:{name:'Enemy',icon:'!'},elite:{name:'Elite challenge',icon:'E'},merchant:{name:'Trader',icon:'$'},trap:{name:'Trap',icon:'▲'},chest:{name:'Chest',icon:'◆'},vault:{name:'Vault',icon:'V'},shrine:{name:'Shrine',icon:'S'},altar:{name:'Altar',icon:'A'},mystery:{name:'Wager',icon:'W'},fountain:{name:'Fountain',icon:'+'},secret:{name:'Discovery',icon:'?'},supplies:{name:'Supplies',icon:'P'},resource:{name:'Resource cache',icon:'R'},door:{name:'Locked door',icon:'D'},workbench:{name:'Supplies',icon:'P'}};
function encounterMark(type){return encounterRegistry[type]?.icon||'?'}

function drawMap(){
 if(!g||!m)return;
 const canvas=$('map'),ctx=canvas.getContext('2d'),size=400;
 canvas.width=canvas.height=size;ctx.fillStyle='#241e17';ctx.fillRect(0,0,size,size);
 const full=!!canvas.closest('.map-full'),span=full?Math.max(19,MAP_ZOOMS[mapZoomIndex]):MAP_ZOOMS[mapZoomIndex];
 const tile=size/span,offX=size/2-(g.x+.5)*tile,offY=size/2-(g.y+.5)*tile;
 for(let y=0;y<19;y++)for(let x=0;x<19;x++){
  if(!seen.has(K(x,y)))continue;
  const px=offX+x*tile,py=offY+y*tile;if(px>size||py>size||px+tile<0||py+tile<0)continue;
  ctx.fillStyle=m.a[y][x]?'#514736':'#baaa88';ctx.fillRect(px,py,Math.ceil(tile)-1,Math.ceil(tile)-1);
  const raw=events.get(K(x,y)),e=raw==='trap'&&!trapDetection()&&g.scouted!==K(x,y)?null:raw;
  const mark=K(x,y)===K(...m.exit)?(m.sideArea?'↩':m.exitBossDefeated?'Ω':'B'):e?encounterMark(e):campSites.has(K(x,y))?'⌂':null;
  if(mark){ctx.fillStyle=e==='enemy'?'#ff9a9a':e==='merchant'?'#9affd7':'#ffdd82';ctx.font='bold '+Math.max(12,Math.min(25,tile*.58))+'px system-ui';ctx.textAlign='center';ctx.fillText(mark,px+tile/2,py+tile*.73)}
 }
 const cx=size/2,cy=size/2,[dx,dy]=D[g.dir],rx=-dy,ry=dx,r=Math.max(7,Math.min(18,tile*.3));
 ctx.fillStyle='#fff3af';ctx.strokeStyle='#111827';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(cx+dx*r,cy+dy*r);ctx.lineTo(cx-dx*r*.65+rx*r*.65,cy-dy*r*.65+ry*r*.65);ctx.lineTo(cx-dx*r*.65-rx*r*.65,cy-dy*r*.65-ry*r*.65);ctx.closePath();ctx.fill();ctx.stroke();
 const indicator=$('mapZoomLabel');if(indicator)indicator.textContent=span+' tiles';
}

function render(){setHunger(g.hunger);if($('game')?.dataset)$('game').dataset.mode=mode;$('name').textContent=g.name;$('role').textContent=g.race+' · '+(g.cls||'Unclassed')+' · Level '+g.level;$('floor').textContent='Stage '+g.floor+' · '+currentBiome().name;$('biomeInfo').textContent=currentBiome().text;$('hp').textContent=g.hp+'/'+healthCap();$('mp').textContent=g.mp+'/'+manaCap();$('xp').textContent=g.xp+'/'+g.need;$('hpbar').value=100*g.hp/healthCap();$('mpbar').value=100*g.mp/manaCap();$('xpbar').value=100*g.xp/g.need;$('money').textContent='🪙 '+g.gold+' · 🧪 '+g.potions+' · Food '+g.rations+' · Keys '+(g.chestKeys||0)+' · Hunger '+formatNumber(g.hunger)+'/'+hungerCap()+((g.effects||[]).length?' · '+g.effects.map(e=>e.kind+' '+e.turns).join(', '):'');$('stats').textContent='ATK '+atk()+' · DEF '+def()+' · Skill points '+g.points+' · Kills '+g.kills+' · Traps '+g.traps+' · Relics: '+((g.relics||[]).map(id=>relicCatalog.find(r=>r.id===id)?.name||id).join(', ')||'none');$('log').textContent=notes.join('\n');const feed=$('actionFeed');if(feed&&feed.textContent!==notes.join('\n')){feed.textContent=notes.join('\n');feed.scrollTop=0;}refreshPanels();renderActions();if(!globalThis.PocketCrawScreen||globalThis.PocketCrawScreen==='explore'){drawView();drawMap()}saveGame()}

function refreshPanels(){if(!g)return;const screen=globalThis.PocketCrawScreen; if(!screen||screen==='gear'){refreshInventory();}if(!screen||screen==='hero')renderCharacterBenefits();if(!screen||screen==='menu')renderEnhancements();if(!screen||screen==='skills'){renderPassives();renderClassTree()}}
globalThis.PocketCrawRefreshScreen=screen=>{globalThis.PocketCrawScreen=screen;refreshPanels();if(g&&screen==='explore'){drawView();drawMap()}};

const SAVE_KEY='pocketCrawSaveV1';
function saveStatus(message){const el=$('saveStatus');if(el)el.textContent=message}
const DIAG_KEY='pocketCrawDiagnosticsV1',BACKUP_KEY='pocketCrawPreMigrationBackupV1';
function reportError(operation,error){const message=String(error?.message||error||'Unknown error');const record={at:new Date().toISOString(),operation,message,gameVersion:GAME_VERSION};try{const previous=JSON.parse(localStorage.getItem(DIAG_KEY)||'[]');localStorage.setItem(DIAG_KEY,JSON.stringify([...previous.slice(-39),record]))}catch(_){}let bar=document.getElementById('pcErrorBar');if(!bar){bar=document.createElement('div');bar.id='pcErrorBar';bar.setAttribute('role','alert');bar.style.cssText='position:fixed;bottom:52px;left:8px;right:8px;z-index:99999;background:#54262d;color:#fff;padding:12px;border:1px solid #fa9b9b;border-radius:8px;font:13px sans-serif;max-height:35vh;overflow:auto';document.body.appendChild(bar)}bar.replaceChildren();const msg=document.createElement('div');msg.textContent=operation+': '+message;const btn=document.createElement('button');btn.textContent='Dismiss';btn.onclick=()=>bar.remove();bar.append(msg,btn);saveStatus(operation+': '+message);return record}
window.addEventListener('error',e=>reportError('JavaScript error',e.error||e.message));window.addEventListener('unhandledrejection',e=>reportError('Unhandled action',e.reason));
function showDiagnostics(){let rows=[];try{rows=JSON.parse(localStorage.getItem(DIAG_KEY)||'[]')}catch(_){}const report=JSON.stringify(rows,null,2);const pane=document.createElement('dialog');pane.style.cssText='max-width:94vw;max-height:80vh;background:#172133;color:white;border:1px solid #8ca3bd;border-radius:8px';const title=document.createElement('h3');title.textContent='Pocket Craw Error Log';const pre=document.createElement('pre');pre.style.cssText='white-space:pre-wrap;overflow:auto;max-height:50vh;font-size:12px';pre.textContent=report||'No errors recorded.';const copy=document.createElement('button');copy.textContent='Copy diagnostics';copy.onclick=()=>navigator.clipboard?.writeText(report).catch(e=>reportError('Copy diagnostics',e));const close=document.createElement('button');close.textContent='Close';close.onclick=()=>pane.remove();pane.append(title,pre,copy,close);document.body.appendChild(pane);pane.showModal()}
window.PocketCrawShowDiagnostics=showDiagnostics;
function refundLegacySkills(l){if(l.progressionVersion===160)return 0;let refund=0;for(const [id,rank]of Object.entries(l.skillEnhancements||{})){if(!skillLabel(id)||!Number.isInteger(rank)||rank<0||rank>5)throw Error('Invalid Legacy enhancement');refund+=5*rank*(rank+1)/2;}l.points=(Number(l.points)||0)+refund;l.skillEnhancements={};l.learnedSkills=[];l.progressionVersion=160;return refund}
function migrateProgression(v){const h=v.hero;if(h.progressionVersion!==160){for(const id of h.passives||[]){const n=retiredPassiveNodes[id];if(!n)throw Error('Unknown retired passive');const rank=h.enhancements?.['passive:'+id]||0,e={...n.effect};if(rank){if(n.keystone){e.atk=(e.atk||0)+2*rank;e.maxhp=(e.maxhp||0)+5*rank}else for(const key of Object.keys(e)){if(key==='discount')e[key]+=rank;else if(['atk','def','maxhp','maxmp','onKill'].includes(key))e[key]+=rank*Math.ceil(n.effect[key]*.2);else e[key]*=1+.2*rank}}for(const k of ['atk','def','maxhp','maxmp'])h[k]=Math.max(k==='maxhp'||k==='maxmp'?1:0,h[k]-(e[k]||0));}h.passives=[];h.enhancements={};h.points=earnedPoints(h.level);h.freeRespec=true;h.progressionVersion=160;v.selectedPassive='origin';h.hp=Math.min(h.hp,h.maxhp+Object.values(h.equipment).reduce((n,i)=>n+(i?.life||0),0));h.mp=Math.min(h.mp,h.maxmp+Object.values(h.equipment).reduce((n,i)=>n+(i?.mana||0),0));}refundLegacySkills(v.legacy);h.cargo??=[];h.relics??=[];h.pendingRewards??=[];h.damageLog??=[];if(v.mode==='corpse'&&h.corpse){h.cargo.push({id:'old-corpse',kind:'corpse',n:h.corpse.n,type:'unknown',value:4,food:1,materials:{bone:2},qty:1});h.corpse=null;v.mode='explore';}}

function migrateSave(input){if(!input||typeof input!=='object'||input.format!=='PocketCraw')throw Error('Unrecognized save format');if(input.version!==1)throw Error('Unsupported save format '+input.version);const v=JSON.parse(JSON.stringify(input));let changes=[];if(!v.hero||!v.maze)throw Error('Missing hero or dungeon data');if(!v.legacy||typeof v.legacy!=='object'){v.legacy={points:legacy,unlocks:[...unlocks],learnedSkills:[...learnedSkills],skillEnhancements:{...skillEnhancements}};changes.push('Legacy metadata')}if(!Array.isArray(v.legacy.learnedSkills)){v.legacy.learnedSkills=[];changes.push('learned skills list')}if(!v.legacy.skillEnhancements){v.legacy.skillEnhancements={};changes.push('skill enhancements')}if(!Array.isArray(v.legacy.unlocks)){v.legacy.unlocks=[];changes.push('unlock list')}if(!Array.isArray(v.hero.effects)){v.hero.effects=[];changes.push('status effects')}if(!v.hero.enhancements){v.hero.enhancements={};changes.push('hero enhancements')}if(!Array.isArray(v.hero.classPath)){v.hero.classPath=[];changes.push('class path')}if(!Array.isArray(v.hero.passives)){v.hero.passives=[];changes.push('passives')}if(v.hero.cls===undefined){v.hero.cls=null;changes.push('class')}if(v.hero.baseClass===undefined){v.hero.baseClass=null;changes.push('base class')}if(v.legacyReturn===undefined){v.legacyReturn='explore';changes.push('return mode')}if(!v.selectedPassive||!passiveNodes[v.selectedPassive]){v.selectedPassive='origin';changes.push('skill selection')}if(!Array.isArray(v.notes)){v.notes=[];changes.push('event notes')}if(!Array.isArray(v.stock)){v.stock=[];changes.push('merchant stock')}if(!Array.isArray(v.events)){v.events=[];changes.push('encounters')}if(!Array.isArray(v.seen)){v.seen=[];changes.push('exploration map')}if(v.hero.progressionVersion!==160||v.legacy.progressionVersion!==160){migrateProgression(v);changes.push('passive web refund and Legacy simplification')}if(!v.hero.equipmentRules27){v.hero.equipmentRules27=true;changes.push('class equipment tags and hand rules')}return {save:v,changes}}
function loadAndMigrate(raw){const parsed=JSON.parse(raw);const {save,changes}=migrateSave(parsed);validateSave(save);if(changes.length){try{localStorage.setItem(BACKUP_KEY,raw)}catch(e){throw Error('Could not preserve original save backup: '+e.message)}}return {save,changes}}

function snapshot(){return {format:'PocketCraw',version:1,gameVersion:GAME_VERSION,testRun:devMode,savedAt:new Date().toISOString(),hero:g,maze:m,seen:[...seen],events:[...events],enemy,mode,notes,stock,legacyReturn,selectedPassive,legacy:{progressionVersion:160,points:legacy,unlocks:[...unlocks],learnedSkills:[...learnedSkills],skillEnhancements,modernRanks:{...legacyModernRanks}}}}
function saveGame(manual=false){if(!g)return false;if(devMode){saveStatus("TEST MODE — progress is not saved.");return true;}try{localStorage.setItem(SAVE_KEY,JSON.stringify(snapshot()));$('continueBtn').disabled=false;saveStatus(manual?'Game saved.':'Progress saved automatically.');return true}catch(e){reportError('Save failed',e);return false}}
function validateSave(v){
 const bad=()=>{throw Error('Invalid or incompatible Pocket Craw save file.')},obj=x=>x&&typeof x==='object'&&!Array.isArray(x),num=x=>Number.isFinite(x)&&x>=0,arr=x=>Array.isArray(x),str=x=>typeof x==='string',ints=x=>Number.isInteger(x)&&x>=0;
 if(!obj(v)||v.format!=='PocketCraw'||v.version!==1||!obj(v.hero)||!obj(v.maze)||!obj(v.legacy))bad();
 for(const k of ['chestMimic','chestTrapped','chestInspected','mimicKnown','chestTrapKnown'])if(v.hero[k]!==undefined&&typeof v.hero[k]!=='boolean')bad();
 if(v.hero.chestTier!==undefined&&v.hero.chestTier!==null&&!['Common','Magic','Rare','Epic'].includes(v.hero.chestTier))bad();if(v.hero.chestLocked!==undefined&&typeof v.hero.chestLocked!=='boolean')bad();if(v.hero.autoEquip!==undefined&&typeof v.hero.autoEquip!=='boolean')bad();
 if(v.maze.destination!==undefined&&!Object.hasOwn(biomes,v.maze.destination))bad();if(v.maze.biome!==undefined&&!Object.hasOwn(biomes,v.maze.biome))bad();
 if(v.hero.effects!==undefined&&(!arr(v.hero.effects)||v.hero.effects.length>5||v.hero.effects.some(e=>!obj(e)||!['Poison','Bleeding','Burn','Frostbite','Curse'].includes(e.kind)||!Number.isInteger(e.turns)||e.turns<1||e.turns>5||!Number.isInteger(e.damage)||e.damage<1||e.damage>20)))bad();
 if(v.hero.scouted!==undefined&&v.hero.scouted!==null&&(!str(v.hero.scouted)||!/^\d{1,2},\d{1,2}$/.test(v.hero.scouted)))bad();
 if(v.hero.hungerMax!==undefined&&(!Number.isInteger(v.hero.hungerMax)||v.hero.hungerMax<100||v.hero.hungerMax>175))bad();if(v.hero.hunger!==undefined&&(!num(v.hero.hunger)||v.hero.hunger>(v.hero.hungerMax??100)))bad();
 if(v.testRun)throw Error('Developer test saves cannot replace legitimate progress.');
 const h=v.hero,states=SAVE_STATES;
 if(v.legacy.modernRanks!==undefined&&(!obj(v.legacy.modernRanks)||Object.entries(v.legacy.modernRanks).some(([id,n])=>!legacyModern.some(i=>i.id===id&&ints(n)&&n<=i.cap))))bad();
 if(h.lockpicks!==undefined&&(!obj(h.lockpicks)||['basic','fine','magic'].some(k=>!ints(h.lockpicks[k])||h.lockpicks[k]>100000)))bad();
 if(!states.includes(v.mode)||!states.includes(v.legacyReturn)||v.legacyReturn==='legacy'||!passiveNodes[v.selectedPassive])bad();
 for(const k of ['level','xp','need','hp','maxhp','mp','maxmp','atk','def','gold','potions','floor','kills','traps','chests','bosses','points','x','y','dir'])if(!num(h[k]))bad();
 if(!ints(h.x)||!ints(h.y)||!ints(h.dir)||h.x>=19||h.y>=19||h.dir>3||h.level<1||h.need<1||h.maxhp<1||h.maxmp<1||h.hp>h.maxhp+Object.values(h.equipment||{}).reduce((n,i)=>n+(i?.life||0),0)||h.mp>h.maxmp+Object.values(h.equipment||{}).reduce((n,i)=>n+(i?.mana||0),0)||!str(h.name)||!str(h.race)||!str(h.skill))bad();
 if(h.cls!==null&&!classNodes[h.cls]||h.baseClass!==null&&!classRoots[h.baseClass])bad();
 if(!arr(h.passives)||h.passives.some(id=>id==='origin'||!passiveNodes[id])||new Set(h.passives).size!==h.passives.length||!arr(h.classPath)||h.classPath.some(x=>!obj(x)||!str(x.name)||!num(x.level)))bad();
 const ranks=x=>obj(x)&&Object.entries(x).every(([id,n])=>skillLabel(id)&&ints(n)&&n<=5);
 if(!ranks(h.enhancements)||!ranks(v.legacy.skillEnhancements)||!num(v.legacy.points)||!arr(v.legacy.unlocks)||v.legacy.unlocks.some(x=>!unlocksList.some(([n])=>n===x))||!arr(v.legacy.learnedSkills)||v.legacy.learnedSkills.some(x=>!str(x)||!skillLabel(x)))bad();
 const durabilityValid=x=>(x.maxDurability===undefined&&x.durability===undefined)||(Number.isInteger(x.maxDurability)&&x.maxDurability>=1&&x.maxDurability<=300&&num(x.durability)&&x.durability<=x.maxDurability);
 const item=x=>obj(x)&&(x.baseType===undefined||x.baseType===null||gearBases.some(b=>b[0]===x.baseType))&&(x.classTag===undefined||['Universal',...Object.keys(classRoots)].includes(x.classTag))&&(x.hands===undefined||[1,2].includes(x.hands))&&durabilityValid(x)&&(x.hungerSave===undefined||num(x.hungerSave)&&x.hungerSave<=1)&&(x.sustainingMod===undefined||typeof x.sustainingMod==='boolean')&&str(x.n)&&gearSlots.includes(x.slot)&&['atk','def','price','life','mana','crit','evade','spell','disarm'].every(k=>x[k]===undefined||num(x[k]))&&(x.upgrade===undefined||ints(x.upgrade)&&x.upgrade<=3)&&(x.rarity===undefined||['Common','Magic','Rare','Epic'].includes(x.rarity));
 if(h.materials!==undefined&&(!obj(h.materials)||Object.entries(h.materials).some(([k,n])=>!materialKeys.includes(k)||!ints(n)||n>100000)))bad();
 if(!arr(h.inventory)||!h.inventory.every(item)||!obj(h.equipment)||!['weapon','armor','trinket'].every(k=>h.equipment[k]===null||item(h.equipment[k])))bad();
 if(gearSlots.some(k=>h.equipment[k]!==undefined&&h.equipment[k]!==null&&(!item(h.equipment[k])||(h.equipment[k].slot!==k&&!(k==='offhand'&&h.equipment[k].slot==='weapon'&&['Dagger','Dirk','Worn Dagger'].includes(h.equipment[k].baseType))))))bad();for(const k of ['chestKeys','rations','scrap','merchantPotions','merchantRations','manaTonics','antidotes','bandages','merchantMana','merchantAntidotes','merchantBandages'])if(h[k]!==undefined&&!ints(h[k]))bad();
 if(h.cargo!==undefined&&(!arr(h.cargo)||h.cargo.some(i=>!obj(i)||!str(i.id)||!str(i.n)||!['corpse','treasure'].includes(i.kind)||!ints(i.value)||!ints(i.food)||!obj(i.materials)||Object.entries(i.materials).some(([k,n])=>!materialKeys.includes(k)||!ints(n)))))bad();
 if(h.relics!==undefined&&(!arr(h.relics)||h.relics.some(id=>!relicCatalog.some(r=>r.id===id))||new Set(h.relics).size!==h.relics.length))bad();
 if(h.pendingRewards!==undefined&&(!arr(h.pendingRewards)||h.pendingRewards.some(row=>!arr(row)||row.some(r=>!obj(r)||!['gear','relic','gold','food'].includes(r.kind)||r.kind==='gear'&&!item(r.item)||r.kind==='relic'&&!relicCatalog.some(x=>x.id===r.id)||['gold','food'].includes(r.kind)&&!ints(r.amount)))))bad();
 if(h.progressionVersion===160&&(h.passives.length+h.points>earnedPoints(h.level)||h.passives.some(id=>passiveNodes[id].mastery&&h.passives.filter(k=>passiveNodes[k].mastery&&passiveNodes[k].cluster===passiveNodes[id].cluster).length>1)))bad();
 if(v.maze.merchants!==undefined&&(!obj(v.maze.merchants)||Object.values(v.maze.merchants).some(t=>!obj(t)||!['food','general'].includes(t.kind)||!arr(t.gear)||!t.gear.every(item)||!obj(t.supplies)||Object.entries(t.supplies).some(([k,n])=>!Object.hasOwn(tradePrices,k)||!ints(n)))))bad();
 if(v.maze.exitBoss&&!['hp','maxhp','atk','xp','armor'].every(k=>num(v.maze.exitBoss[k])))bad();
 const coord=x=>arr(x)&&x.length===2&&x.every(n=>ints(n)&&n<19),key=x=>str(x)&&/^(?:[0-9]|1[0-8]),(?:[0-9]|1[0-8])$/.test(x);
 if(!arr(v.maze.a)||v.maze.a.length!==19||v.maze.a.some(row=>!arr(row)||row.length!==19||row.some(n=>n!==0&&n!==1))||v.maze.a[h.y][h.x]!==0||!arr(v.maze.cells)||!v.maze.cells.every(coord)||!coord(v.maze.exit))bad();
 if(!arr(v.seen)||!v.seen.every(key)||!arr(v.events)||v.events.some(e=>!arr(e)||e.length!==2||!key(e[0])||!['enemy','elite','trap','chest','merchant','shrine','altar','door','mystery','vault','fountain','secret','supplies','workbench','resource'].includes(e[1])))bad();
 if(!arr(v.notes)||!v.notes.every(str)||!arr(v.stock)||!v.stock.every(item))bad();
 const active=v.mode==='legacy'?v.legacyReturn:v.mode;
 if(active==='combat'&&(!obj(v.enemy)||!str(v.enemy.n)||!['hp','maxhp','atk','xp','armor'].every(k=>num(v.enemy[k]))||v.enemy.hp<=0))bad();
 if(active==='dead'&&(h.hp!==0||!num(h.earned)))bad();if(active!=='dead'&&h.hp<=0)bad();
 if(v.maze.parent)validateAreaBundle(v.maze.parent,v);if(v.maze.sidePocket)validateAreaBundle(v.maze.sidePocket,v);return v;
}
function restoreSave(v){v=migrateSave(v).save;validateSave(v);distantSpriteCache.clear();workbenchOpen=false;v=JSON.parse(JSON.stringify(v));const oldGear=v.hero.equipment.offhand===undefined;for(const key of gearSlots)if(v.hero.equipment[key]===undefined)v.hero.equipment[key]=null;for(const key of ['chestKeys','rations','scrap','merchantPotions','merchantRations','manaTonics','antidotes','bandages','merchantMana','merchantAntidotes','merchantBandages'])if(v.hero[key]===undefined)v.hero[key]=0;if(oldGear)v.hero.inventory=v.hero.inventory.filter(i=>!Object.values(v.hero.equipment).some(e=>e&&JSON.stringify(e)===JSON.stringify(i)));if(v.hero.autoEquip===undefined)v.hero.autoEquip=autoEquipPreference();if(v.hero.materials===undefined)v.hero.materials={};if(!v.hero.equipment.camp&&!v.hero.inventory.some(i=>i.slot==='camp'))v.hero.equipment.camp={n:'Basic Bedroll',slot:'camp',rarity:'Common',campTier:0,price:8};g=v.hero;g.hungerMax??=100;g.hunger??=g.hungerMax;setHunger(g.hunger);for(const i of [...g.inventory,...Object.values(g.equipment),...v.stock])if(i)initDurability(i);g.effects??=[];ensurePicks();g.scouted??=null;m=v.maze;campSites=new Set(Array.isArray(m.campSites)?m.campSites:[]);if(!Array.isArray(m.campSites)){for(const [x,y] of m.cells||[])if(!wall(x,y)&&D.filter(([dx,dy])=>wall(x+dx,y+dy)).length>=2){campSites.add(K(x,y));break}m.campSites=[...campSites]}seen=new Set(v.seen);events=new Map(v.events.map(([key,t])=>[key,t==='workbench'?'supplies':t]));if(mode==='workbench')mode='explore';if(g.floor<=3){let traps=0;for(const [key,type]of events)if(type==='door'||type==='trap'&&++traps>1)events.delete(key);if(v.mode==='door')v.mode='chest';if(v.legacyReturn==='door')v.legacyReturn='chest'}enemy=v.enemy;if(enemy?.exitGuardian)m.exitBoss=enemy;mode=v.mode==='workbench'?'explore':v.mode;g.chestTier??=null;g.chestLocked??=false;g.chestKeys??=0;g.chestMimic??=false;g.chestTrapped??=false;g.chestInspected??=false;g.mimicKnown??=false;g.chestTrapKnown??=false;if(['chest','vault'].includes(mode)&&!v.hero.chestTier){g.chestTier=null;migrateChestState()}notes=v.notes;stock=v.stock;legacyReturn=v.legacyReturn;selectedPassive=v.selectedPassive;legacy=v.legacy.points;unlocks=new Set(v.legacy.unlocks);learnedSkills.clear();v.legacy.learnedSkills.forEach(id=>learnedSkills.add(id));Object.keys(skillEnhancements).forEach(id=>delete skillEnhancements[id]);Object.assign(skillEnhancements,v.legacy.skillEnhancements);if(v.legacy.modernRanks!==undefined)legacyModernRanks={...v.legacy.modernRanks};const moved=reconcileEquipment();if(moved)say('Class equipment rules: '+moved+' items moved to inventory; nothing discarded.');persist();$('splash').hidden=true;$('game').hidden=false;render()}
function loadGame(){if(devMode){saveStatus('Exit developer mode before loading a real save.');return false}try{const raw=localStorage.getItem(SAVE_KEY);if(!raw){saveStatus('No saved game yet.');return false}const {save,changes}=loadAndMigrate(raw);const ledger=JSON.parse(localStorage.getItem('labyrinthLegacyV1')||'null');if(ledger)save.legacy={...save.legacy,...ledger,modernRanks:{...legacyModernRanks}};if(g&&mode!=='splash'&&!confirm('Load your saved game and replace the current progress?'))return false;restoreSave(save);saveStatus(changes.length?'Save upgraded and loaded ('+changes.join(', ')+'). Original backup preserved.':'Saved game loaded.');return true}catch(e){reportError('Continue Save failed',e);return false}}
function exportSave(){if(devMode){saveStatus('Exit developer mode before exporting legitimate progress.');return false}if(!g){saveStatus('Start or continue a game before exporting.');return}const blob=new Blob([JSON.stringify(snapshot(),null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download='Pocket-Craw-save-'+new Date().toISOString().slice(0,10)+'.json';document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);saveStatus('Save file download requested.')}
$('saveBtn').onclick=()=>saveGame(true);$('loadBtn').onclick=loadGame;$('continueBtn').onclick=()=>{if(devMode&&menuTestSnapshot){mode=menuTestSnapshot.mode;menuTestSnapshot=null;$('splash').hidden=true;$('game').hidden=false;render();return true}return loadGame()};$('exportBtn').onclick=exportSave;$('importBtn').onclick=()=>$('importSave').click();
$('importSave').onchange=async e=>{const file=e.target.files[0];if(!file)return;if(devMode){saveStatus('Exit developer mode before importing saves.');e.target.value='';return;}try{if(file.size>2000000)throw Error('Too large');const {save:v,changes}=loadAndMigrate(await file.text());if(!confirm('Import this save? It replaces the current run AND Legacy points, unlocks and enhancements.'))return;restoreSave(v);saveStatus(changes.length?'Save imported and upgraded: '+changes.join(', '):'Save file imported.')}catch(err){reportError('Import Save failed',err)}finally{e.target.value=''}};
try{$('continueBtn').disabled=!localStorage.getItem(SAVE_KEY)}catch(e){$('continueBtn').disabled=true}

$('up').onclick=()=>move(1);$('down').onclick=()=>move(-1);$('left').onclick=()=>turn(-1);$('right').onclick=()=>turn(1);$('sl').onclick=()=>move(0,-1);$('sr').onclick=()=>move(0,1);$('legacyBtn').onclick=showLegacy;document.addEventListener('keydown',e=>{if(e.target?.closest('#passiveGraph,summary,input,select,textarea'))return;if(!canNavigate()||document.querySelector('dialog[open]')||$('game').dataset.screen!=='explore')return;let k=e.key.toLowerCase();if(!['w','a','s','d','q','e','arrowup','arrowdown','arrowleft','arrowright'].includes(k))return;e.preventDefault();if(k==='w'||k==='arrowup')move(1);if(k==='s'||k==='arrowdown')move(-1);if(k==='a'||k==='arrowleft')turn(-1);if(k==='d'||k==='arrowright')turn(1);if(k==='q')move(0,-1);if(k==='e')move(0,1)});$('startBtn').onclick=()=>{if(mode!=='splash')return;try{if(localStorage.getItem(SAVE_KEY)&&!confirm('Start a new hero? This replaces the saved run, but keeps your Legacy progress.'))return}catch(e){}newRun();$('splash').hidden=true;$('game').hidden=false;$('up').focus()};
// Inventory cargo and run-specific rewards.
function cargoId(){g.cargoSerial=(g.cargoSerial||0)+1;return 'cargo-'+g.floor+'-'+g.cargoSerial}
function collectCorpse(e){g.cargo??=[];g.cargo.push({id:cargoId(),kind:'corpse',n:e.n+' remains',type:e.model||monsterKind(e.n),qty:1,value:Math.max(2,2+g.floor),food:1+Math.floor(g.floor/4),materials:{bone:2,leather:1}});say('Collected '+e.n+' remains. Process or trade them from Items.');}
function collectTreasure(){g.cargo??=[];const t=P([{n:'Broken mechanism',materials:{metal:3,mechanical:1}},{n:'Gem-studded idol',materials:{gem:2,dust:2}},{n:'Ancient textile',materials:{cloth:4,essence:1}}]);g.cargo.push({id:cargoId(),kind:'treasure',n:t.n,type:'treasure',qty:1,value:8+g.floor*3,food:0,materials:t.materials});say('Collected '+t.n+': sell or dismantle.');}
function processCargo(id,quiet=false){if(!gearAllowed())return false;const i=g.cargo?.find(x=>x.id===id);if(!i||i.kind==='corpse'&&!canScavenge())return false;g.cargo.splice(g.cargo.indexOf(i),1);for(const [k,n]of Object.entries(i.materials))materialBag()[k]+=n;if(i.kind==='corpse')g.rations+=i.food;say('Processed '+i.n+'.');if(!quiet)render();return true}
function renderCargo(){const bag=$('inventory');if(!bag)return;for(const kind of ['corpse','treasure']){const items=(g.cargo||[]).filter(i=>i.kind===kind);const section=document.createElement('section');section.className='pc-item-group';section.dataset.inventoryCategory=kind;const title=document.createElement('h3');title.textContent=(kind==='corpse'?'Corpses':'Treasures')+' ('+items.length+')';section.append(title);for(const i of items){const row=document.createElement('div');row.className='cargo-row';row.dataset.inventorySearch=i.n.toLowerCase();const text=document.createElement('p');text.textContent=i.n+' · sell '+i.value+'g · yields '+Object.entries(i.materials).map(([k,n])=>n+' '+materialNames[k]).join(', ')+(kind==='corpse'?' + '+i.food+' food':'');row.append(text,button(kind==='corpse'?'Scavenge corpse':'Dismantle treasure',()=>processCargo(i.id),!gearAllowed()||kind==='corpse'&&!canScavenge()));section.append(row)}if(!items.length){const empty=document.createElement('p');empty.textContent='None carried.';section.append(empty)}bag.append(section)}}

const relicCatalog=[{id:'emberglass',name:'Emberglass',desc:'Class hits add a small burn.',effect:{ignite:2}},{id:'wardstone',name:'Wardstone',desc:'Mana absorbs 25% of incoming damage.',effect:{manaShield:1}},{id:'fang',name:'Twin Fang Token',desc:'Every third dual-dagger attack gains +40%.',effect:{twin:1}},{id:'salvager',name:'Salvager Lens',desc:'Scavenge corpses and recover +1 primary salvage material.',effect:{detect:1,salvage:1}},{id:'mending',name:'Mending Knot',desc:'Recover 2 HP after each victory.',effect:{onKill:2}}];
function queueRewards(){g.pendingRewards??=[];const available=relicCatalog.filter(r=>!g.relics.includes(r.id));g.pendingRewards.push([{kind:'gear',item:rollGear(g.floor,2)},{kind:'gold',amount:30+g.floor*8},available.length?{kind:'relic',id:P(available).id}:{kind:'food',amount:8}]);}
function rewardLabel(r){return r.kind==='gear'?r.item.n+' — '+gearText(r.item):r.kind==='relic'?relicCatalog.find(x=>x.id===r.id).name+' — '+relicCatalog.find(x=>x.id===r.id).desc:r.amount+' '+r.kind}
function chooseReward(index){if(!g?.pendingRewards?.length||!gearAllowed())return false;const rewards=g.pendingRewards[0],r=rewards[index];if(!r)return false;g.pendingRewards.shift();if(r.kind==='gear')acquireGear(r.item);else if(r.kind==='relic'){if(!g.relics.includes(r.id))g.relics.push(r.id)}else if(r.kind==='gold')g.gold+=r.amount;else g.rations+=r.amount;const d=$('pcRewards');if(d?.open)d.close();say('Reward: '+rewardLabel(r));render();return true}
function openRewards(){if(!g.pendingRewards?.length||!gearAllowed())return;let d=$('pcRewards');if(!d){d=document.createElement('dialog');d.id='pcRewards';d.className='pc-modal';document.body.append(d)}d.replaceChildren();const h=document.createElement('h2');h.textContent='Choose one reward';d.append(h);g.pendingRewards[0].forEach((r,n)=>d.append(button(rewardLabel(r),()=>chooseReward(n))));d.append(button('Choose later',()=>d.close()));if(K(g.x,g.y)===K(...m.exit)&&m.exitBossDefeated)d.append(button('Travel onward · choose reward first',()=>descend()));if(!d.open)d.showModal();}
// Each merchant owns a persistent stock record for this floor.
let tradeCart=new Map(),tradeTab='buy',tradeMessage='';
function currentTrader(){return m.merchants?.[K(g.x,g.y)]}
function visitMerchant(){m.merchants??={};const key=K(g.x,g.y);if(!m.merchants[key]){const food=m.traderKinds?.[key]==='food'||(!m.traderKinds?.[key]&&Math.random()<.06);m.merchants[key]={kind:food?'food':'general',name:food?'Provisions & Game Trader':'Dungeon Outfitter',supplies:{rations:10+R(31),potions:2+R(4),manaTonics:2+R(4),bandages:2+R(4),antidotes:1+R(3),basic:3+R(6),fine:1+R(3),magic:R(3)},gear:food?[]:Array.from({length:6},()=>rollGear()),revision:0};}g.lastMerchantTile=key;stock=currentTrader().gear;tradeCart.clear();tradeMessage='';openMerchant();}
const tradePrices={rations:12,potions:18,manaTonics:20,bandages:10,antidotes:12,basic:6,fine:24,magic:55};
const tradeNames={rations:'Ration packs',potions:'Healing potions',manaTonics:'Mana tonics',bandages:'Bandages',antidotes:'Antidotes',basic:'Basic lockpicks',fine:'Fine lockpicks',magic:'Magic lockpicks'};
function supplyAmount(key){return ['basic','fine','magic'].includes(key)?ensurePicks()[key]:g[key]||0}
function changeSupply(key,n){if(['basic','fine','magic'].includes(key))ensurePicks()[key]+=n;else g[key]=(g[key]||0)+n}
function tradeOffers(){const t=currentTrader();if(!t)return [];const rows=[];for(const key of Object.keys(tradePrices)){if(t.kind==='food'&&key!=='rations')continue;rows.push({id:'buy:'+key,side:'buy',kind:'supply',key,n:tradeNames[key],max:t.supplies[key]||0,price:tradePrices[key],food:0});rows.push({id:'sell:'+key,side:'sell',kind:'supply',key,n:tradeNames[key],max:supplyAmount(key),price:Math.max(1,Math.floor(tradePrices[key]*.25)),food:0});}if(t.kind==='general'){t.gear.forEach((item,n)=>rows.push({id:'buygear:'+n,side:'buy',kind:'gear',item,n:item.n+' · '+gearText(item),max:1,price:item.price||12,food:0}));g.inventory.forEach((item,n)=>{if(!item.protected)rows.push({id:'sellgear:'+n,side:'sell',kind:'gear',item,n:item.n,max:1,price:Math.max(1,Math.floor((item.price||12)*.4)),food:0})});}for(const i of g.cargo||[]){const edible=['rat','spider','goblin','troll','treant'].includes(i.type);if(t.kind==='food'&&(i.kind!=='corpse'||!edible))continue;rows.push({id:'cargo:'+i.id,side:'sell',kind:'cargo',item:i,n:i.n,max:1,price:t.kind==='food'?0:i.value,food:t.kind==='food'?i.food:0})}return rows;}
function basketQuote(){const offers=tradeOffers(),rows=[];let cost=0,credit=0,food=0;for(const [id,q]of tradeCart){const o=offers.find(x=>x.id===id);if(!o||!Number.isInteger(q)||q<1||q>o.max)return {ok:false,message:'Stock changed. Clear or adjust your basket.'};rows.push({...o,q});if(o.side==='buy')cost+=o.price*q;else{credit+=o.price*q;food+=o.food*q}}return {ok:rows.length>0&&g.gold+credit>=cost,rows,cost,credit,food,message:rows.length===0?'Basket is empty.':g.gold+credit<cost?'Not enough gold.':'Ready to trade.'}}
function checkoutTrade(){if(mode!=='merchant'||!currentTrader())return false;const q=basketQuote();if(!q.ok){tradeMessage=q.message;renderMerchant();return false}const t=currentTrader();
 // Validate all rows and total first, then mutate once. No confirm per item.
 for(const o of q.rows){if(o.kind==='supply'){if(o.side==='buy'){t.supplies[o.key]-=o.q;changeSupply(o.key,o.q)}else{changeSupply(o.key,-o.q);t.supplies[o.key]=(t.supplies[o.key]||0)+o.q}}else if(o.kind==='gear'){if(o.side==='buy'){t.gear.splice(t.gear.indexOf(o.item),1);g.inventory.push(o.item)}else{g.inventory.splice(g.inventory.indexOf(o.item),1);t.gear.push(o.item)}}else g.cargo.splice(g.cargo.indexOf(o.item),1);}
 g.gold+=q.credit-q.cost;g.rations+=q.food;t.revision++;stock=t.gear;tradeCart.clear();tradeMessage='Trade complete: spent '+q.cost+'g, received '+q.credit+'g'+(q.food?' and '+q.food+' food':'')+'.';say(tradeMessage);render();renderMerchant();return true;
}
function setBasket(id,n){const o=tradeOffers().find(x=>x.id===id);if(!o)return;n=Math.max(0,Math.min(o.max,Math.floor(Number(n)||0)));if(n)tradeCart.set(id,n);else tradeCart.delete(id);refreshTradeTotals()}
function refreshTradeTotals(){const el=$('pcTradeTotal');if(!el)return;const q=basketQuote();el.textContent=g.gold+'g · Net '+((q.cost||0)-(q.credit||0))+'g'+(q.food?' · +'+q.food+' food':'')+(!q.ok?' · '+q.message:'');const pay=$('pcTradePay');if(pay)pay.disabled=!q.ok;}
function openMerchant(){if(mode!=='merchant')return;let d=$('pcMerchant');if(!d){d=document.createElement('dialog');d.id='pcMerchant';d.className='pc-modal pc-merchant';document.body.append(d);d.addEventListener('cancel',e=>{e.preventDefault();closeMerchant()})}renderMerchant();if(!d.open)d.showModal()}
function closeMerchant(){tradeCart.clear();$('pcMerchant')?.close();if(mode==='merchant')mode='explore';render()}
function renderMerchant(){const d=$('pcMerchant'),t=currentTrader();if(!d||!t)return;d.replaceChildren();const h=document.createElement('h2');h.textContent=t.name;const sub=document.createElement('p');sub.textContent=t.kind==='food'?'Buys and sells food. Trades edible rat, spider, goblin, troll and root-guardian remains for rations.':'Equipment, consumables and finite lockpick stock. Add quantities to Buy and Sell, then pay once.';d.append(h,sub);const nav=document.createElement('div');nav.className='trade-tabs';for(const tab of ['buy','sell']){const b=button(tab==='buy'?'Buy wares':'Sell inventory',()=>{tradeTab=tab;renderMerchant()});b.setAttribute('aria-pressed',String(tradeTab===tab));nav.append(b)}nav.append(button('Clear basket',()=>{tradeCart.clear();renderMerchant()}),button('Leave trader',closeMerchant));d.append(nav);const list=document.createElement('div');list.className='trade-list';for(const o of tradeOffers().filter(o=>o.side===tradeTab&&o.max>0)){const row=document.createElement('div');row.className='trade-row';const label=document.createElement('label');const input=document.createElement('input');input.type='number';input.min=0;input.max=o.max;input.step=1;input.value=tradeCart.get(o.id)||0;input.setAttribute('aria-label',o.side+' '+o.n+' quantity');input.oninput=()=>setBasket(o.id,input.value);label.textContent=o.n+' · '+(o.food?o.food+' food':o.price+'g')+' each · '+o.max+' available';row.append(label,input,button('+1',()=>{input.value=Math.min(o.max,(tradeCart.get(o.id)||0)+1);setBasket(o.id,input.value)}),button('+5',()=>{input.value=Math.min(o.max,(tradeCart.get(o.id)||0)+5);setBasket(o.id,input.value)}));list.append(row)}if(!list.children.length)list.textContent='No items in this category.';d.append(list);const footer=document.createElement('div');footer.className='trade-footer';const total=document.createElement('p');total.id='pcTradeTotal';const message=document.createElement('p');message.textContent=tradeMessage;const pay=button('Pay & complete trade',checkoutTrade);pay.id='pcTradePay';footer.append(total,message,pay);d.append(footer);refreshTradeTotals()}
function merchantPanel(a){const t=currentTrader();a.append(button(t?'Open '+t.name:'Open trader',()=>{if(!currentTrader())visitMerchant();else openMerchant()}));a.append(button('Leave trader',closeMerchant));}
// Passive web is shared, searchable, and explorable before spending points.
let webSearch='',webZoom=.4,webOpened=false;
function renderPassives(){
 $('passivePoints').textContent=g.points+' points · '+g.passives.length+'/104 learned · budget '+earnedPoints()+'/70';const graph=$('passiveGraph');graph.replaceChildren();graph.style.width='1600px';graph.style.height='1600px';graph.style.zoom=String(webZoom);
 const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 1600 1600');svg.setAttribute('aria-hidden','true');svg.style.width='1600px';svg.style.height='1600px';
 const path=plannedPath(selectedPassive);for(const [id,n]of Object.entries(passiveNodes))for(const other of n.links){const end=passiveNodes[other];if(!end)continue;const line=document.createElementNS('http://www.w3.org/2000/svg','line');for(const [k,v]of Object.entries({x1:n.x,y1:n.y,x2:end.x,y2:end.y,stroke:g.passives.includes(id)?'#754521':path.includes(id)?'#a65b30':'#9b8766','stroke-width':3}))line.setAttribute(k,v);svg.append(line)}graph.append(svg);
 for(const [id,n]of Object.entries(passiveNodes)){const owned=id==='origin'||g.passives.includes(id),b=button(id==='origin'?'Origin':n.keystone?'★':n.mastery?'M':n.notable?'◆':'●',()=>{selectedPassive=id;renderPassives()});b.className='passive-node '+(owned?'allocated':passiveAvailable(id)?'available':'locked')+(n.keystone?' keystone':'')+(selectedPassive===id?' selected':'');b.style.left=n.x+'px';b.style.top=n.y+'px';b.dataset.node=id;b.title=n.name+' — '+n.desc;b.setAttribute('aria-label',n.name+' — '+n.desc);const lane=n.cluster;const emblem=['might','resolve','arcana','cunning','arcana','arcana','resolve','cunning'][lane];if(emblem&&window.PocketCrawArtData?.[emblem]){const icon=new Image();icon.src=PocketCrawArtData[emblem];icon.alt='';icon.className='skill-emblem';b.replaceChildren(icon);if(n.keystone||n.mastery||n.notable){const mark=document.createElement('span');mark.className='skill-rank';mark.textContent=n.keystone?'K':n.mastery?'M':'+';b.append(mark)}}b.setAttribute('aria-pressed',String(owned));if(webSearch&&!((n.name+' '+n.desc).toLowerCase().includes(webSearch.toLowerCase())))b.style.opacity='.2';graph.append(b)}
 for(let i=0;i<webClusters.length;i++){const label=document.createElement('span');label.className='skill-cluster-label';label.textContent=webClusters[i][0];label.style.left=(800+Math.cos(2*Math.PI*i/8)*500)+'px';label.style.top=(800+Math.sin(2*Math.PI*i/8)*500)+'px';graph.append(label)}const n=passiveNodes[selectedPassive]||passiveNodes.origin;const reason=passiveLockReason(selectedPassive);$('passiveDetail').textContent=n.name+' — '+n.desc+' · Route: '+path.map(id=>passiveNodes[id].name).join(' → ')+' · '+(reason||'Spend 1 point.');$('learnPassive').disabled=!!reason;$('learnPassive').onclick=()=>allocatePassive(selectedPassive);
 const reset=$('pcRespec');if(reset){reset.textContent='Reset points · '+respecCost()+'g';reset.disabled=!g.passives.length||g.gold<respecCost()||!['camp','class','explore'].includes(mode)||g.level>=5&&!g.freeRespec&&mode!=='camp';}
}
globalThis.PocketCrawWeb={open(){if(webOpened)return;webOpened=true;const graph=$('passiveGraph'),box=graph.parentElement;webZoom=Math.max(.2,Math.min(.5,(box.clientWidth-16)/1600,(box.clientHeight-16)/1600));renderPassives();requestAnimationFrame(()=>globalThis.PocketCrawWeb.center());},search(q){webSearch=q;renderPassives();const n=Object.entries(passiveNodes).find(([,n])=>(n.name+' '+n.desc).toLowerCase().includes(q.toLowerCase()));if(n&&q){selectedPassive=n[0];renderPassives();$('passiveGraph').querySelector('[data-node="'+n[0]+'"]').scrollIntoView({block:'center',inline:'center'});}},zoom(d){webZoom=Math.max(.2,Math.min(1.5,webZoom+d));renderPassives()},center(){const n=$('passiveGraph').querySelector('[data-node="origin"]');n?.scrollIntoView({block:'center',inline:'center'})},reset:respecPassives};

globalThis.PocketCrawResize=()=>{if(!g)return;const box=document.getElementById('viewport');if(!box||!box.clientWidth||!box.clientHeight)return;const c=$('view'),w=Math.round(box.clientWidth*2),h=Math.round(box.clientHeight*2);if(c.width!==w||c.height!==h){c.width=w;c.height=h}drawView();drawMap()};
globalThis.PocketCrawDev={
 get active(){return devMode},
 enter(){if(devMode)return true;if(!confirm('Start an isolated test run? Your saved character and Legacy will not be modified. Reloading returns to your normal save.'))return false;devMode=true;newRun();$('splash').hidden=true;$('game').hidden=false;render();return true},
 level(n){if(!devMode)return false;const target=Math.max(1,Math.min(50,Math.floor(n)));while(g.level<target){g.level++;g.need=Math.floor(g.need*1.35);g.maxhp+=6;g.maxmp+=3;g.atk++;if(g.level%2===0)g.def++;g.points=Math.max(0,earnedPoints()-g.passives.length)}g.hp=healthCap();g.mp=manaCap();if(g.level>=nextClassLevel())mode='class';render();return true},
 mimic(){if(!devMode)return false;mode='chest';g.chestTier='Rare';g.chestLocked=false;g.chestMimic=true;g.chestTrapped=false;g.chestInspected=false;g.mimicKnown=false;g.chestTrapKnown=false;say('TEST: This chest contains a mimic. Inspect it, feed it, or open it.');render();return true},
 floor(n){if(!devMode)return false;g.floor=Math.max(1,Math.min(30,Math.floor(n)));generate();render();return true},
 supplies(){if(!devMode)return false;g.hp=healthCap();g.mp=manaCap();g.hunger=hungerCap();g.rations+=25;g.gold+=500;g.potions+=20;render();return true},
 density(n){if(!devMode||!Number.isFinite(Number(n)))return false;devDensity=Math.max(50,Math.min(250,Math.round(Number(n)/10)*10));return devDensity},
 get monsterDensity(){return devDensity},
 regenerate(){if(!devMode)return false;generate();say('TEST: floor regenerated at '+devDensity+'% monster density.');render();return true},
 exit(){if(!devMode)return;location.reload()}

};
if(saved.progressionVersion!==160){try{const original=localStorage.getItem('labyrinthLegacyV1');if(original)localStorage.setItem('pocketCrawLegacyBefore160',original);refundLegacySkills(saved);legacy=Number(saved.points)||0;learnedSkills.clear();for(const k of Object.keys(skillEnhancements))delete skillEnhancements[k];persist()}catch(e){reportError('Legacy migration',e)}}

const inventoryIds=new WeakMap(),inventoryExpanded=new Set();let inventorySerial=0,inventoryFilter='gear',inventoryQuery='';
function inventoryCandidates(kind){return kind==='gear'?g.inventory.filter(i=>!i.protected):(g.cargo||[]).filter(i=>(kind==='all'||i.kind===kind)&&(i.kind!=='corpse'||canScavenge()));}
function bulkInventory(kind){if(!gearAllowed())return;const items=inventoryCandidates(kind).slice();if(!items.length)return;let d=$('pcBulkSalvage');if(!d){d=document.createElement('dialog');d.id='pcBulkSalvage';d.className='pc-modal';document.body.append(d)}d.replaceChildren();const h=document.createElement('h2');h.textContent=kind==='gear'?'Salvage unprotected gear':'Process carried materials';const info=document.createElement('p');info.textContent=items.length+' items. '+(kind==='gear'?'Equipped and protected gear are excluded.':'Corpses require scavenging ability. Processed corpses and treasures cannot also be sold.');const list=document.createElement('p');list.textContent=items.map(i=>i.n).join(', ')+' · Guaranteed yield: '+formatMaterials(bulkYields(items,kind))+(kind==='gear'?' (rare bonus may add more)':'');d.append(h,info,list,button('Cancel',()=>d.close()),button('Process '+items.length+' items',()=>{if(!gearAllowed()){d.close();return}const before={...materialBag(),scrap:g.scrap,food:g.rations};let count=0;for(const i of items){if(kind==='gear'){if(g.inventory.includes(i)&&!i.protected){salvageGear(i,true);count++}}else if(processCargo(i.id,true))count++;}d.close();const after={...materialBag(),scrap:g.scrap,food:g.rations};const delta=Object.fromEntries(Object.entries(after).map(([k,n])=>[k,n-(before[k]||0)]).filter(([,n])=>n));g.lastSalvage='Processed '+count+' items: '+formatMaterials(delta);say(g.lastSalvage);render();}));d.showModal();}
function applyInventoryFilter(){for(const section of $('inventory').querySelectorAll('[data-inventory-category]')){const category=section.dataset.inventoryCategory;section.hidden=inventoryFilter!=='all'&&inventoryFilter!==category;for(const row of section.querySelectorAll('.pc-item-row,.cargo-row'))row.hidden=!!inventoryQuery&&!row.textContent.toLowerCase().includes(inventoryQuery);} $('gearSlots').hidden=!['all','equipped'].includes(inventoryFilter);}
function refreshInventory(){const bag=$('inventory');for(const row of document.querySelectorAll('[data-inventory-id]')){if(row.open)inventoryExpanded.add(row.dataset.inventoryId);else inventoryExpanded.delete(row.dataset.inventoryId)}const scrolls=[];for(let node=bag;node;node=node.parentElement)scrolls.push([node,node.scrollTop]);renderGear();renderCargo();let bar=$('inventoryToolbar');if(!bar){bar=document.createElement('div');bar.id='inventoryToolbar';$('gearSlots').before(bar)}bar.replaceChildren();const select=document.createElement('select');select.setAttribute('aria-label','Inventory category');for(const [value,label] of [['all','All items'],['gear','Backpack gear'],['equipped','Equipped gear'],['corpse','Corpses'],['treasure','Treasures'],['supplies','Supplies & materials']]){const o=document.createElement('option');o.value=value;o.textContent=label;select.append(o)}select.value=inventoryFilter;select.onchange=()=>{inventoryFilter=select.value;applyInventoryFilter()};const search=document.createElement('input');search.type='search';search.placeholder='Find an item…';search.setAttribute('aria-label','Search inventory');search.value=inventoryQuery;search.oninput=()=>{inventoryQuery=search.value.toLowerCase();applyInventoryFilter()};bar.append(select,search);bar.append(button('Salvage…',openSalvageMenu,!gearAllowed()),button('?',()=>showHelp('Inventory','Choose a category or search. Tap equipment to compare it. Protected and equipped gear cannot be bulk salvaged. Bulk actions include all eligible carried items, regardless of filters.')));const note=document.createElement('small');note.textContent='Bulk actions include every eligible carried item, regardless of the search/filter. Protect gear to keep it. Equipped gear is always excluded.';if(g.lastSalvage){const result=document.createElement('p');result.textContent=g.lastSalvage;result.setAttribute('role','status');bar.append(result)}applyInventoryFilter();for(const [node,top]of scrolls)node.scrollTop=top;}

function formatMaterials(values){return Object.entries(values).filter(([,n])=>n).map(([k,n])=>n+' '+(materialNames[k]||k)).join(' · ')||'none'}
function salvageScrap(i){if(i.crafted)return 0;return ({Common:1,Magic:2,Rare:4,Epic:6})[i.rarity]||1}
function bulkYields(items,kind){const out={};for(const i of items){const yields=kind==='gear'?{...salvagePreview(i),scrap:salvageScrap(i)}:{...i.materials,food:i.kind==='corpse'?i.food:0};for(const [k,n]of Object.entries(yields))out[k]=(out[k]||0)+n;}return out;}
let rollBusy=false,craftCategory='all',craftSelection='lockpick',craftQuality='basic';
function showRoll(title,value,message){if(rollBusy)return Promise.resolve();rollBusy=true;let d=$('pcRoll');if(!d){d=document.createElement('dialog');d.id='pcRoll';d.className='pc-modal';document.body.append(d)}d.replaceChildren();const h=document.createElement('h2');h.textContent=title;const die=document.createElement('div');die.className='roll-die rolling';die.setAttribute('aria-label','Rolling d100');die.textContent='…';const result=document.createElement('p');result.setAttribute('role','status');result.textContent='Rolling d100…';const close=button('Reveal now',finish);d.append(h,die,result,close);let timer,frames,done=false,ticks=0;function finish(){if(done){d.close();return}done=true;clearInterval(frames);clearTimeout(timer);die.classList.remove('rolling');die.textContent=String(value);die.setAttribute('aria-label','d100 result '+value);result.textContent=message;close.textContent='Continue';rollBusy=false;}
 d.oncancel=e=>{if(!done){e.preventDefault();finish()}};d.showModal();frames=setInterval(()=>{die.textContent=String(1+(++ticks*17)%100)},65);timer=setTimeout(finish,matchMedia('(prefers-reduced-motion: reduce)').matches?0:900);return Promise.resolve();}
function playWager(){if(rollBusy||mode!=='mystery'||g.gold<15)return;const roll=1+R(100),before=g.gold,won=roll>50;g.gold-=15;if(won)g.gold+=55;g.lastWager={roll,won,before,after:g.gold};mode='explore';const text='Rolled '+roll+'/100 — '+(won?'WON: 55g payout, net +40g.':'LOST: −15g.')+' Gold '+before+' → '+g.gold;say(text);render();showRoll('Wager · 51–100 wins',roll,text);}
function craftingRecipes(){return craftRecipes.filter(r=>(r.base==='lockpick'||eligibleBase(r.base))&&(!g.baseClass||!gearRules[r.base]||gearRules[r.base][0]===g.baseClass));}
function recipeCategory(r){if(r.base==='lockpick')return 'tools';const slot=gearBases.find(b=>b[0]===r.base)?.[1];return ['weapon','offhand'].includes(slot)?'weapons':['head','armor','gloves','boots'].includes(slot)?'armor':slot==='camp'?'camp':'accessories'}
function openCrafting(){if(mode!=='camp'||rollBusy)return;let d=$('pcCrafting');if(!d){d=document.createElement('dialog');d.id='pcCrafting';d.className='pc-modal';document.body.append(d)}renderCrafting();if(!d.open)d.showModal();}
function renderCrafting(){const d=$('pcCrafting');if(!d)return;d.replaceChildren();const h=document.createElement('h2');h.textContent='Camp workshop';const intro=document.createElement('p');intro.textContent='Choose a recipe and quality. Equipment rolls d100: 76–100 adds one rarity and modifier. Costs are fixed.';const close=button('Back to camp',()=>d.close());d.append(h,intro,close);const controls=document.createElement('div');controls.className='craft-controls';const category=document.createElement('select');category.setAttribute('aria-label','Recipe category');for(const [id,label]of [['all','All recipes'],['weapons','Weapons & offhands'],['armor','Armor'],['accessories','Accessories'],['camp','Camping'],['tools','Tools']]){const o=document.createElement('option');o.value=id;o.textContent=label;category.append(o)}category.value=craftCategory;category.onchange=()=>{craftCategory=category.value;renderCrafting()};const recipes=craftingRecipes().filter(r=>craftCategory==='all'||recipeCategory(r)===craftCategory);if(!recipes.some(r=>r.base===craftSelection))craftSelection=recipes[0]?.base;const select=document.createElement('select');select.setAttribute('aria-label','Recipe');for(const r of recipes){const o=document.createElement('option');o.value=r.base;o.textContent=r.name;select.append(o)}select.value=craftSelection;select.onchange=()=>{craftSelection=select.value;renderCrafting()};const recipe=recipes.find(r=>r.base===craftSelection);controls.append(category,select);d.append(controls);if(!recipe){d.append(document.createTextNode('No recipes available in this category.'));return}const quality=document.createElement('select');quality.setAttribute('aria-label','Craft quality');const qualities=recipe.base==='lockpick'||g.level<5||!g.baseClass?['basic']:['basic','refined','masterwork'];if(!qualities.includes(craftQuality))craftQuality='basic';for(const q of qualities){const o=document.createElement('option');o.value=q;o.textContent=q+' — '+({basic:'Common',refined:'Magic',masterwork:'Rare'}[q])+' base';quality.append(o)}quality.value=craftQuality;quality.onchange=()=>{craftQuality=quality.value;renderCrafting()};controls.append(quality);const body=document.createElement('div');body.className='craft-body';const cost=recipeCost(recipe,craftQuality),table=document.createElement('table');const caption=document.createElement('caption');caption.textContent='Materials required / owned / missing';table.append(caption);for(const [k,n]of Object.entries(cost)){const tr=document.createElement('tr');for(const text of [materialNames[k],n,materialBag()[k],Math.max(0,n-materialBag()[k])]){const td=document.createElement('td');td.textContent=String(text);tr.append(td)}table.append(tr)}body.append(table);const conversion=document.createElement('div');conversion.className='craft-conversions';const ch=document.createElement('h3');ch.textContent='Convert materials · '+g.scrap+' scrap';conversion.append(ch);for(const key of ['metal','wood','leather','cloth'])conversion.append(button('1 scrap → 2 '+materialNames[key],()=>{convertScrap(key);renderCrafting()},g.scrap<1));conversion.append(button('4 dust → 1 essence',()=>{refineMaterials();renderCrafting()},materialBag().dust<4));body.append(conversion);const result=document.createElement('section');result.id='pcCraftResult';result.setAttribute('aria-live','polite');const last=g.lastCraft;result.textContent=last?'Last craft: '+last.name+' · '+last.text+(last.roll?' · Rolled '+last.roll+'/100 · '+(last.affixes?.join(', ')||'no modifiers'):''):'Your crafted result will appear here.';if(last?.item){const equipped=g.equipment[last.item.slot],comparison=document.createElement('p');comparison.textContent='Currently equipped: '+(equipped?equipped.n+' · '+gearText(equipped):'empty slot');result.append(comparison)}body.prepend(result);d.append(body);const footer=document.createElement('div');footer.className='craft-footer';footer.append(button(g.pinnedRecipe===recipe.base?'Unpin recipe':'Pin recipe',()=>{g.pinnedRecipe=g.pinnedRecipe===recipe.base?null:recipe.base;render();renderCrafting()}));const craft=button('Craft '+recipe.name,()=>{if(rollBusy||mode!=='camp'||!canCraft(recipe,craftQuality))return;craftGear(recipe,craftQuality);renderCrafting();if(g.lastCraft?.roll)showRoll('Crafting d100',g.lastCraft.roll,g.lastCraft.name+' · '+g.lastCraft.text);},!canCraft(recipe,craftQuality));craft.id='pcCraftCommit';footer.append(craft);if(!canCraft(recipe,craftQuality)){const reason=document.createElement('p');reason.textContent=g.level<(recipe.minFloor||1)?'Requires level '+recipe.minFloor:'Missing materials — collect salvage or convert scrap above.';footer.append(reason)}d.append(footer);}
function resetAllLegacy(){if(devMode)return false;try{localStorage.setItem('labyrinthLegacyV1',JSON.stringify({progressionVersion:160,points:0,unlocks:[],learnedSkills:[],skillEnhancements:{}}));localStorage.setItem('pocketCrawLegacyRanksV1','{}');localStorage.removeItem(SAVE_KEY);}catch(e){reportError('Legacy reset failed',e);return false}legacy=0;unlocks.clear();learnedSkills.clear();for(const k of Object.keys(skillEnhancements))delete skillEnhancements[k];legacyModernRanks={};g=undefined;enemy=null;mode='splash';webOpened=false;for(const d of document.querySelectorAll('dialog[open]'))d.close();$('game').hidden=true;$('splash').hidden=false;$('continueBtn').disabled=true;globalThis.PocketCrawResetView?.();return true;}
function requestLegacyReset(){if(devMode)return;let d=$('pcResetLegacy');if(!d){d=document.createElement('dialog');d.id='pcResetLegacy';d.className='pc-modal';document.body.append(d)}d.replaceChildren();const h=document.createElement('h2');h.textContent='Reset all Legacy and current run?';const p=document.createElement('p');p.textContent='Erases all Legacy points, unlocks, ranks and your current character so the next run starts clean. Settings and the installed update stay. Export a save first if you want to keep this progression. This cannot be undone here.';d.append(h,p,button('Cancel',()=>d.close()),button('Erase Legacy and current run',resetAllLegacy));d.showModal();}
const resetStart=button('Reset all Legacy & current run',requestLegacyReset);resetStart.id='resetLegacyStart';$('splash').querySelector('.splash-card').append(resetStart);const resetMenu=button('Reset all Legacy & current run',requestLegacyReset);resetMenu.id='resetLegacyMenu';document.querySelector('.save-tools').append(resetMenu);

const biomeSpecials={
 keep:{cache:'Armory locker',materials:{metal:4,leather:2},side:'Abandoned Armory',treasure:'Discarded fittings'},sewer:{cache:'Scavenger stash',materials:{cloth:3,metal:2},side:'Smuggler Cistern',treasure:'Reclaimed fittings'},crypt:{cache:'Burial offerings',materials:{bone:4,dust:2},side:'Sealed Ossuary',treasure:'Funerary ornament'},cave:{cache:'Mineral seam',materials:{metal:3,gem:2},side:'Crystal Grotto',treasure:'Mineral cluster'},ruins:{cache:'Overgrown supplies',materials:{wood:4,cloth:2},side:'Overgrown Storehouse',treasure:'Carved wooden relic'},ice:{cache:'Lost expedition cache',materials:{cloth:3,gem:2},side:'Frozen Shelter',treasure:'Preserved expedition gear'},forge:{cache:'Machinery cache',materials:{metal:4,mechanical:2},side:'Abandoned Foundry',treasure:'Broken machine assembly'},abyss:{cache:'Occult remnants',materials:{dust:3,essence:1},side:'Sealed Sanctuary',treasure:'Occult vessel'}};
function powerEstimate(){return Math.round(atk()*3+def()*2+healthCap()*.25+manaCap()*.15+Math.min(30,g.passives.length));}
function prepareStage(){m.destination=biomeForFloor(g.floor+1,m.biome);m.guardianPower=powerEstimate();m.exitBoss=makeGuardian();m.layoutVariant=['rooms','loops','caves'][g.floor%3];
 const queue=[[1,1]],prev=new Map([[K(1,1),null]]);for(let n=0;n<queue.length;n++){const [x,y]=queue[n];for(const [dx,dy]of D){const nx=x+dx,ny=y+dy,k=K(nx,ny);if(!wall(nx,ny)&&!prev.has(k)){prev.set(k,[x,y]);queue.push([nx,ny])}}}const route=[];let point=m.exit;while(point){route.push(point);point=prev.get(K(...point))}for(const [key,type]of [...events])if(type==='merchant')events.delete(key);m.traderKinds={};const general=route[Math.min(2,route.length-2)]||route[1];if(general){const key=K(...general);events.set(key,'merchant');m.traderKinds[key]='general';delete m.enemyProfiles[key];campSites.delete(key)}if(g.floor%3===0){const food=route[Math.min(4,route.length-2)];if(food&&K(...food)!==K(...general)){const key=K(...food);events.set(key,'merchant');m.traderKinds[key]='food';delete m.enemyProfiles[key];campSites.delete(key)}}
 for(const type of ['altar','chest']){const slot=[...events].find(([,t])=>t===type);if(slot)events.set(slot[0],'resource');}
 if(g.floor%3===0){const site=[...events].find(([,t])=>t==='mystery');if(site){m.sideEntrance=site[0];events.set(site[0],'secret')}}m.campSites=[...campSites];}
function collectBiomeResource(){if(mode!=='resource')return;const spec=biomeSpecials[m.biome];for(const [k,n]of Object.entries(spec.materials))materialBag()[k]+=n;if(['ruins','sewer','ice'].includes(m.biome))g.rations+=2;say(spec.cache+': '+formatMaterials(spec.materials));mode='explore';render();}
function collectTreasure(){g.cargo??=[];const spec=biomeSpecials[m.biome]||biomeSpecials.keep;const t=Math.random()<.75?{n:spec.treasure,materials:{...spec.materials}}:P([{n:'Travel supplies',materials:{wood:2,cloth:2}},{n:'Metal fittings',materials:{metal:3,leather:1}}]);g.cargo.push({id:cargoId(),kind:'treasure',n:t.n,type:'treasure',qty:1,value:8+g.floor*3,food:0,materials:t.materials});say('Collected '+t.n+'.');}
function collectCorpse(e){g.cargo??=[];const type=e.model||monsterKind(e.n),construct=['golem','crystal'].includes(type),spirit=['wraith','stalker'].includes(type);g.cargo.push({id:cargoId(),kind:construct||spirit?'treasure':'corpse',n:e.n+(construct?' components':spirit?' essence':' remains'),type,qty:1,value:Math.max(2,2+g.floor),food:construct||spirit||type==='skeleton'?0:1+Math.floor(g.floor/4),materials:construct?{metal:3,mechanical:1}:spirit?{dust:2,essence:1}:type==='skeleton'?{bone:3}:{bone:2,leather:1}});say('Collected '+g.cargo.at(-1).n+'.');}
function areaBundle(){return {maze:m,seen:[...seen],events:[...events],stock,position:{x:g.x,y:g.y,dir:g.dir}}}
function setArea(bundle){m=bundle.maze;seen=new Set(bundle.seen);events=new Map(bundle.events);stock=bundle.stock;Object.assign(g,bundle.position);campSites=new Set(m.campSites||[]);enemy=null;mode='explore';distantSpriteCache.clear();}
function enterSideArea(){if(mode!=='secret'||m.sideArea||m.sideEntrance!==K(g.x,g.y))return;const parent=areaBundle(),cached=m.sidePocket;delete m.sidePocket;if(cached){setArea(cached);m.parent=parent;g.x=1;g.y=1;g.dir=1;}else{const biome=m.biome;const a=Array.from({length:19},()=>Array(19).fill(1));for(let y=1;y<=5;y++)for(let x=1;x<=7;x++)if(y===1||y===3||y===5||x===1||x===4||x===7)a[y][x]=0;m={a,cells:[],exit:[1,1],biome,sideArea:true,parent,campSites:[],exitBossDefeated:true};for(let y=1;y<18;y++)for(let x=1;x<18;x++)if(!a[y][x])m.cells.push([x,y]);seen=new Set();events=new Map([['4,1','enemy'],['7,3','elite'],['4,5','resource'],['7,5','chest']]);m.enemyProfiles={'4,1':makeEnemy()};stock=[];g.x=1;g.y=1;g.dir=1;campSites=new Set();enemy=null;mode='explore';}reveal();say('Entered '+biomeSpecials[m.biome].side+'. Return portal is at the entrance.');render();}
function leaveSideArea(){if(!m.sideArea||!m.parent)return;const parent=m.parent;delete m.parent;const pocket=areaBundle();setArea(parent);m.sidePocket=pocket;events.set(m.sideEntrance,'secret');say('Returned to '+currentBiome().name+'.');render();}
function validateAreaBundle(bundle,v){if(!bundle||typeof bundle!=='object'||!bundle.position||!bundle.maze||bundle.maze.parent||bundle.maze.sidePocket)throw Error('Invalid side area state');validateSave({...v,maze:bundle.maze,hero:{...v.hero,...bundle.position},seen:bundle.seen,events:bundle.events,stock:bundle.stock,mode:v.hero.hp<=0?'dead':'explore',enemy:null});}
function campMeal(){if(mode!=='camp'||g.rations<3||g.hp>=healthCap()&&g.mp>=manaCap())return;g.rations-=3;g.hp=Math.min(healthCap(),g.hp+Math.ceil(healthCap()*.3));g.mp=Math.min(manaCap(),g.mp+Math.ceil(manaCap()*.3));setHunger(g.hunger+40);say('Camp meal: 3 food, recovered 30% HP/MP and 40 hunger.');render();}
function foodCommission(){const t=currentTrader();if(mode!=='merchant'||!t||t.commissionDone||g.rations<10)return;t.commissionDone=true;g.rations-=10;g.gold+=40;say('Food order delivered: 10 rations for 40 gold.');render();renderMerchant();}
function showHelp(title,text){let d=$('pcHelp');if(!d){d=document.createElement('dialog');d.id='pcHelp';d.className='pc-modal';document.body.append(d)}d.replaceChildren();const h=document.createElement('h2');h.textContent=title;const p=document.createElement('p');p.textContent=text;d.append(h,p,button('Close help',()=>d.close()));if(!d.open)d.showModal();}
function openSalvageMenu(){let d=$('pcSalvageMenu');if(!d){d=document.createElement('dialog');d.id='pcSalvageMenu';d.className='pc-modal';document.body.append(d)}d.replaceChildren();const h=document.createElement('h2');h.textContent='Salvage carried items';d.append(h);for(const [kind,label]of [['corpse','Scavenge all corpses'],['treasure','Dismantle all treasures'],['gear','Salvage all unprotected gear']]){const n=inventoryCandidates(kind).length;d.append(button(label+' ('+n+')',()=>{d.close();bulkInventory(kind)},!n||!gearAllowed()))}d.append(button('Cancel',()=>d.close()));d.showModal();}

let traderCategory='all',foodReserve=10;
function modalHeader(d,title,onClose,help){const header=document.createElement('header');header.className='compact-modal-header';const h=document.createElement('h2');h.textContent=title;header.append(h,button('?',()=>showHelp(title,help)),button('Close',onClose));d.append(header)}
function renderMerchant(){const d=$('pcMerchant'),t=currentTrader();if(!d||!t)return;d.replaceChildren();modalHeader(d,t.kind==='food'?'Food trader':'Merchant',closeMerchant,'Buy or sell with quantities, then pay once. Stock is finite. Sell surplus keeps your chosen food reserve. Food orders are available once per trader. Protected equipment is excluded.');const tabs=document.createElement('div');tabs.className='trade-tabs';for(const tab of ['buy','sell','food']){const b=button(tab==='buy'?'Buy':tab==='sell'?'Sell':'Food orders',()=>{tradeTab=tab;renderMerchant()});b.setAttribute('aria-pressed',String(tradeTab===tab));tabs.append(b)}d.append(tabs);const list=document.createElement('div');list.className='trade-list';if(tradeTab==='food'){const p=document.createElement('p');p.textContent='Rations: '+g.rations;const label=document.createElement('label');label.textContent='Keep rations ';const input=document.createElement('input');input.type='number';input.min=0;input.max=99999;input.value=foodReserve;input.setAttribute('aria-label','Food reserve');input.onchange=()=>{foodReserve=Math.max(0,Math.min(99999,Math.floor(Number(input.value)||0)))};label.append(input);list.append(p,label,button('Add surplus food to sale',()=>{setBasket('sell:rations',Math.max(0,g.rations-foodReserve));tradeTab='sell';renderMerchant()}),button(t.commissionDone?'Food order completed':'Deliver 10 food · earn 40 gold',foodCommission,t.commissionDone||g.rations<10));}else{for(const o of tradeOffers().filter(o=>o.side===tradeTab&&o.max>0)){const row=document.createElement('div');row.className='trade-row';const label=document.createElement('div');const name=document.createElement('strong');name.textContent=o.kind==='gear'?o.item.n:o.n;const meta=document.createElement('small');meta.textContent=(o.food?o.food+' food':o.price+'g')+' · '+o.max+' available';label.append(name,meta);if(o.kind==='gear')label.append(button('Details',()=>showHelp(o.item.n,gearText(o.item))));const input=document.createElement('input');input.type='number';input.min=0;input.max=o.max;input.step=1;input.value=tradeCart.get(o.id)||0;input.setAttribute('aria-label',o.side+' '+o.n+' quantity');input.oninput=()=>setBasket(o.id,input.value);row.append(label,input,button('+1',()=>{input.value=Math.min(o.max,(tradeCart.get(o.id)||0)+1);setBasket(o.id,input.value)}),button('+5',()=>{input.value=Math.min(o.max,(tradeCart.get(o.id)||0)+5);setBasket(o.id,input.value)}));list.append(row)}if(!list.children.length)list.textContent='Nothing available.'}d.append(list);const footer=document.createElement('div');footer.className='trade-footer';const total=document.createElement('p');total.id='pcTradeTotal';const pay=button('Pay',checkoutTrade);pay.id='pcTradePay';footer.append(total,button('Clear',()=>{tradeCart.clear();renderMerchant()}),pay);d.append(footer);refreshTradeTotals();}
let workshopTab='recipes',workshopDetail=false;
function renderCrafting(){const d=$('pcCrafting');if(!d)return;d.replaceChildren();modalHeader(d,'Workshop',()=>d.close(),'Select a recipe, then its quality. Costs are fixed. Equipment rolls d100: 76–100 adds a rarity/modifier. Materials converts scrap; Last craft retains the result. Crafted salvage returns half paid materials and no scrap.');const tabs=document.createElement('div');tabs.className='trade-tabs';for(const [id,label]of [['recipes','Recipes'],['materials','Materials'],['result','Last craft']]){const b=button(label,()=>{workshopTab=id;workshopDetail=false;renderCrafting()});b.setAttribute('aria-pressed',String(workshopTab===id));tabs.append(b)}d.append(tabs);const body=document.createElement('div');body.className='craft-body';d.append(body);
 if(workshopTab==='materials'){const p=document.createElement('p');p.textContent='Scrap: '+g.scrap;body.append(p);for(const key of ['metal','wood','leather','cloth'])body.append(button('1 scrap → 2 '+materialNames[key]+' · owned '+materialBag()[key],()=>{convertScrap(key);renderCrafting()},g.scrap<1));body.append(button('4 dust → 1 essence',()=>{refineMaterials();renderCrafting()},materialBag().dust<4));return}
 if(workshopTab==='result'){const result=document.createElement('section');result.id='pcCraftResult';const last=g.lastCraft;result.textContent=last?last.name+' · '+last.text+(last.roll?' · Rolled '+last.roll+'/100 · '+(last.affixes?.join(', ')||'no modifiers'):''):'Nothing crafted yet.';if(last?.item){const p=document.createElement('p'),equipped=g.equipment[last.item.slot];p.textContent='Equipped: '+(equipped?equipped.n+' · '+gearText(equipped):'empty');result.append(p)}body.append(result);return}
 const recipes=craftingRecipes();if(!recipes.some(r=>r.base===craftSelection))craftSelection=recipes[0]?.base;
 if(!workshopDetail){const category=document.createElement('select');category.setAttribute('aria-label','Recipe category');for(const [id,label]of [['all','All recipes'],['weapons','Weapons'],['armor','Armor'],['accessories','Accessories'],['camp','Camping'],['tools','Tools']]){const o=document.createElement('option');o.value=id;o.textContent=label;category.append(o)}category.value=craftCategory;category.onchange=()=>{craftCategory=category.value;renderCrafting()};body.append(category);for(const r of recipes.filter(r=>craftCategory==='all'||recipeCategory(r)===craftCategory)){const b=button(r.name+(canCraft(r,'basic')?' · Ready':' · Missing materials'),()=>{craftSelection=r.base;workshopDetail=true;renderCrafting()});b.dataset.recipe=r.base;body.append(b)}return}
 const recipe=recipes.find(r=>r.base===craftSelection);if(!recipe)return;body.append(button('‹ Recipes',()=>{workshopDetail=false;renderCrafting()}));const title=document.createElement('h3');title.textContent=recipe.name;body.append(title);const quality=document.createElement('select');quality.setAttribute('aria-label','Craft quality');const qualities=recipe.base==='lockpick'||g.level<5||!g.baseClass?['basic']:['basic','refined','masterwork'];if(!qualities.includes(craftQuality))craftQuality='basic';for(const q of qualities){const o=document.createElement('option');o.value=q;o.textContent=q;quality.append(o)}quality.value=craftQuality;quality.onchange=()=>{craftQuality=quality.value;renderCrafting()};body.append(quality);const table=document.createElement('table');const tr=document.createElement('tr');for(const text of ['Material','Need','Have','Missing']){const th=document.createElement('th');th.textContent=text;tr.append(th)}table.append(tr);for(const [k,n]of Object.entries(recipeCost(recipe,craftQuality))){const row=document.createElement('tr');for(const text of [materialNames[k],n,materialBag()[k],Math.max(0,n-materialBag()[k])]){const td=document.createElement('td');td.textContent=String(text);row.append(td)}table.append(row)}body.append(table);const footer=document.createElement('div');footer.className='craft-footer';footer.append(button(g.pinnedRecipe===recipe.base?'Unpin':'Pin',()=>{g.pinnedRecipe=g.pinnedRecipe===recipe.base?null:recipe.base;render();renderCrafting()}));const commit=button('Craft',()=>{if(rollBusy||mode!=='camp'||!canCraft(recipe,craftQuality))return;craftGear(recipe,craftQuality);workshopTab='result';renderCrafting();if(g.lastCraft?.roll)showRoll('Crafting',g.lastCraft.roll,g.lastCraft.name+' · '+g.lastCraft.text)},!canCraft(recipe,craftQuality));commit.id='pcCraftCommit';footer.append(commit);d.append(footer);}
// Compact auto-equip without reducing its touch target.
const autoLabel=$('autoEquip')?.closest('label');if(autoLabel){for(const child of [...autoLabel.childNodes])if(child.nodeType===3)child.textContent=' Auto-equip';autoLabel.title='Equip newly acquired gear into empty slots';}

// Visual approval slice. Simulation and storage are unchanged.
const artImages={},artTiles={},artBounds={};let artLoaded=false,fallenStandee=null,artFrame=0;
const oldMonster=drawMonster,oldEncounter=drawEncounter,oldWall=wallMaterial,oldDoor=doorMaterial,oldFloor=drawFloor,oldView=drawView;
function paintedStandee(ctx,id,w,h,fall=0){
 const im=artImages[id],bounds=artBounds[id];if(!im||!bounds)return false;
 const low=['rat','sewer_slime','chest','vault','altar','fountain','camp','trap','supplies'].includes(id)||id.startsWith('resource_')||id.startsWith('hazard_');
 const maxH=h*(low?.52:.77),maxW=w*.76,scale=Math.min(maxH/bounds.h,maxW/bounds.w),ih=bounds.h*scale,iw=bounds.w*scale;
 const ground=h*.94;
 ctx.save();ctx.translate(w/2,ground);
 ctx.fillStyle='#100b08aa';ctx.beginPath();ctx.ellipse(0,-1,iw*.40,Math.max(3,h*(.008+.035*fall)),0,0,Math.PI*2);ctx.fill();
 ctx.transform(1,fall*.04,0,1-fall*.85,0,0);ctx.rotate(fall*.025);
 ctx.drawImage(im,bounds.x,bounds.y,bounds.w,bounds.h,-iw/2,-ih,iw,ih);
 ctx.restore();return true;
}
const encounterArt={merchant:'merchant',chest:'chest',vault:'vault',stairs:'portal',shrine:'shrine',altar:'altar',fountain:'fountain',mystery:'wager',camp:'camp',trap:'trap',secret:'sidearch',supplies:'supplies',workbench:'supplies',door:'lockeddoor',dead:'grave',elite:'challenge'};
function hazardArtId(x=g.x,y=g.y){return 'hazard_'+(Object.keys(hazards).indexOf(m.biome)*2+(x*7+y*3+g.floor)%2)}
function encounterArtId(type){return type==='resource'?'resource_'+m.biome:type==='trap'?hazardArtId():encounterArt[type]}

function monsterArtId(foe){if(foe.exitGuardian)return 'guardian';if(foe.n==='Sewer Slime')return 'sewer_slime';if(foe.n==='Bog Troll')return 'bog_troll';const id=foe.model||monsterKind(foe.n);return ['skeleton','goblin','rat','mimic'].includes(id)?id:null}
drawMonster=function(ctx,foe,w,h){const id=monsterArtId(foe);if(artLoaded&&id&&artImages[id])return paintedStandee(ctx,id,w,h);return oldMonster(ctx,foe,w,h)};
drawEncounter=function(ctx,type,w,h){
 const id=encounterArtId(type);
 if(artLoaded&&id&&artImages[id])return paintedStandee(ctx,id,w,h);
 return oldEncounter(ctx,type,w,h);
};

const oldFloorTrap=drawFloorTrap;drawFloorTrap=function(ctx,w,h){const key=aheadTrap(),known=trapDetection()||g.scouted===key;if(artLoaded&&key&&known){const [x,y]=key.split(',').map(Number);return paintedStandee(ctx,hazardArtId(x,y),w,h)}return oldFloorTrap(ctx,w,h)};
wallMaterial=function(id,v){return artLoaded&&id==='sewer'?artTiles.sewer_wall:artLoaded&&id==='keep'?artTiles.wall:oldWall(id,v)};
doorMaterial=function(id){return artLoaded&&['keep','sewer'].includes(id)?artTiles.door:oldDoor(id)};
drawFloor=function(ctx,w,h,horizon){
 if(!artLoaded||!['keep','sewer'].includes(m.biome))return oldFloor(ctx,w,h,horizon);
 const tile=m.biome==='sewer'?artTiles.sewer_floor:artTiles.floor,ceiling=m.biome==='sewer'?artTiles.sewer_wall:artTiles.wall,angle=g.dir*Math.PI/2-Math.PI/2,dx=Math.cos(angle),dy=Math.sin(angle),step=3;
 for(let y=Math.max(0,Math.floor(horizon)+1);y<h;y+=step){const depth=h/(1.5*(y-horizon));
 for(let x=0;x<w;x+=step){const side=(x/w*2-1)*.68,wx=g.x+.5+depth*(dx-dy*side),wy=g.y+.5+depth*(dy+dx*side),u=wx-Math.floor(wx),v=wy-Math.floor(wy);
 ctx.drawImage(tile,Math.floor(u*255),Math.floor(v*255),1,1,x,y,step,step);
 if(horizon===h*.5)ctx.drawImage(ceiling,Math.floor(u*255),Math.floor(v*255),1,1,x,h-y-step,step,step);
 }ctx.fillStyle=`rgba(8,6,4,${Math.min(.85,depth*.075)})`;ctx.fillRect(0,y,w,step);if(horizon===h*.5)ctx.fillRect(0,h-y-step,w,step);
 }
};
function drawFall(){if(!fallenStandee)return;const f=fallenStandee;
 if(!g||g!==f.hero||g.x!==f.x||g.y!==f.y||g.dir!==f.dir||mode!=='explore'){fallenStandee=null;return}
 const ctx=$('view').getContext('2d'),w=$('view').width,h=$('view').height;
 const t=matchMedia('(prefers-reduced-motion: reduce)').matches?1:Math.min(1,(performance.now()-f.start)/420);
 paintedStandee(ctx,f.id,w,h,1-Math.pow(1-t,3));if(t<1)artFrame=requestAnimationFrame(()=>drawView());
}
drawView=function(){cancelAnimationFrame(artFrame);oldView();drawFall()};
const artFight=fight;fight=function(action){const previous=enemy&&{...enemy},killsBefore=g.kills;artFight(action);if(previous&&!enemy&&g.hp>0&&g.kills>killsBefore&&artImages[monsterArtId(previous)]){fallenStandee={hero:g,id:monsterArtId(previous),x:g.x,y:g.y,dir:g.dir,start:performance.now()};drawView()}};
function itemArt(item){if(!item)return null;const n=item.n.toLowerCase();return /sword/.test(n)?'sword':/shield|buckler/.test(n)?'shield':null}
function paintedItem(item){const id=itemArt(item);if(!id||!artLoaded)return null;const im=new Image();im.src=PocketCrawArtData[id];im.alt='';im.className='painted-item';return im}
Promise.all(Object.entries(window.PocketCrawArtData||{}).map(([id,src])=>new Promise((resolve,reject)=>{const im=new Image();im.onload=()=>{artImages[id]=im;
 const canvas=document.createElement('canvas');canvas.width=im.width;canvas.height=im.height;
 const cx=canvas.getContext('2d',{willReadFrequently:true});cx.drawImage(im,0,0);const pixels=cx.getImageData(0,0,im.width,im.height).data;
 let x0=im.width,y0=im.height,x1=0,y1=0;
 for(let y=0;y<im.height;y++)for(let x=0;x<im.width;x++)if(pixels[(y*im.width+x)*4+3]>48){x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y)}
 artBounds[id]={x:x0,y:y0,w:Math.max(1,x1-x0+1),h:Math.max(1,y1-y0+1)};resolve()};im.onerror=()=>reject(Error('Artwork failed: '+id));im.src=src}))).then(()=>{
 for(const id of ['wall','floor','door','sewer_wall','sewer_floor']){const c=document.createElement('canvas');c.width=c.height=256;c.getContext('2d').drawImage(artImages[id],0,0,256,256);artTiles[id]=c}
 document.documentElement.style.setProperty('--painted-paper',`url("${PocketCrawArtData.paper}")`);
 artLoaded=true;distantSpriteCache.clear();wallMaterials.clear();doorTiles.clear();if(g)render();
 globalThis.PocketCrawArtReady=true;
}).catch(e=>{globalThis.PocketCrawArtError=e.message;const el=document.createElement('p');el.textContent='Artwork could not load. Reopen the game before reviewing visuals.';document.body.append(el)});

let menuTestSnapshot=null;
globalThis.PocketCrawMainMenu=()=>{
 if(!g||mode==='splash')return true;
 if(!saveGame(true))return false;
 menuTestSnapshot=devMode?snapshot():null;
 for(const dialog of document.querySelectorAll('dialog[open]'))dialog.close();
 $('game').hidden=true;$('splash').hidden=false;mode='splash';
 $('continueBtn').disabled=false;$('continueBtn').textContent=devMode?'Continue test run':'Continue saved game';
 $('continueBtn').focus();return true;
};
globalThis.PocketCrawReady=true;
})();
