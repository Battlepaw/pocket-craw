# Pocket Craw v1.9.0 — resilient imports and IndexedDB storage

Play: https://pocket-craw-beta.onrender.com

## What changed
- Imported packages now live in IndexedDB. Character saves and Legacy retain their existing localStorage keys and formats.
- Existing schema-1 imports migrate automatically, with a verified write before the old package record is replaced by a storage marker. Your installed version remains selected.
- Schema-2 update JSON uses gzip compression and SHA-256 integrity checks. All game art remains embedded and available offline; no external image hosting is required.
- Import limits are now 16 MiB per file and 32 MiB decoded HTML. Decompression is bounded and malformed or corrupt packages are rejected.
- A candidate must report its matching version, startup readiness and artwork readiness before becoming the installed package. Failure restores the previous package and pre-import saves. A durable recovery record handles a reload during installation.
- Keep one previous package for rollback, export the installed update, remove the previous package without deleting saves, view browser storage usage, or request persistent offline storage.

## Installing
This compressed JSON requires the v1.9.0 host (importer 2). Refresh the Render page online after its host deployment and check App for “Host 1.9.0 / importer 2.” The old host cannot install schema 2. Existing uncompressed JSON remains supported by the new host. Use App → Import update to load Pocket_Craw_v1.9.0_IMPORT.json; use Continue to resume. If you already have an imported version, host migration preserves that selection until you import or explicitly select the bundled game.

Routine future releases remain JSON imports. This release includes a user-authorized one-time host deployment. Deployment completion is recorded separately in the deployment receipt; this source archive alone does not claim a successful deployment.

## Verification
See IMPORTER_RESULTS_190.json for migration, compressed install, rollback, >3 MiB package, corruption rejection, failed-start save restoration, interrupted import recovery, offline reload, storage-quota failure and bounded-decompression tests. TEST_RESULTS_170.json contains the current 21 grouped gameplay checks, despite its historical filename. MENU_RESULTS_185.json contains rerun menu/audio checks. CAMPAIGNS_170.json contains campaign simulation results. JavaScript syntax checks also apply to every current runtime script.
Tests use isolated Chromium/mobile emulation, not a physical Android device or the user's real save. SHA-256 detects corruption; it is not a signature proving authorship. Continue importing only trusted project updates. Browser persistence is optional and browser-controlled; exported saves remain an independent backup. Avoid editing the same run in multiple tabs.

## Source provenance and preserved scope
Development baseline: verified Library Pocket_Craw_v1.8.5_SOURCE.zip, SHA-256 d9c801868b237aa992545c039666888a04bb964d6b1acb3dd466ec183850518f. GitHub and Render are delivery surfaces, not source authority. Original artwork, optimized assets, runtime code, generation scripts, tests and earlier release evidence remain included. No image-quality reduction, gameplay rebalance or new art was performed in v1.9.0. The 17 remaining named monster placeholders and six unfinished biome environments from the previous audit remain outstanding.

## Render compatibility package
The existing Render build command unpacks a fixed legacy ZIP filename and folder. The v1.9.0 RENDER ZIP therefore contains the current runtime under the compatibility folder Pocket_Craw_v1.7.1, and is uploaded to that legacy filename in GitHub. Every runtime version is 1.9.0. This is a deployment adapter, not the development source. The original old ZIP remains in Git history and a backups path. The complete source archive uses the correct Pocket_Craw_v1.9.0 directory.
